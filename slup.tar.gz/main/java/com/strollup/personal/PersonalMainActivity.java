package com.strollup.personal;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;

import com.github.florent37.materialviewpager.MaterialViewPager;
import com.strollup.main.DisplaySavedPlans;
import com.strollup.utility.Constants;

import in.strollup.android.R;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class PersonalMainActivity extends AppCompatActivity {

    private MaterialViewPager mViewPager;
	private PersonalSectionAdapter mSectionsPagerAdapter;
	private static final String TAG = PersonalMainActivity.class.getSimpleName();

	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);
		SharedPreferences prefs = this.getSharedPreferences("basicProfile", 0);
		String name = prefs.getString("name", "Profile");
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		setContentView(R.layout.sliding_tabs_layout);
        getSupportActionBar().setTitle(name);
		mSectionsPagerAdapter = new PersonalSectionAdapter(getSupportFragmentManager());
        mViewPager = (MaterialViewPager)findViewById(R.id.pager);
        mViewPager.getViewPager().setAdapter(mSectionsPagerAdapter);
        mViewPager.getPagerTitleStrip().setViewPager(mViewPager.getViewPager());
        Typeface font = Typeface.createFromAsset(this.getAssets(), Constants.BASE_FONT);
        mViewPager.getPagerTitleStrip().setTypeface(font,0);
        mViewPager.getViewPager().setOffscreenPageLimit(3);
        mViewPager.getViewPager().setCurrentItem(getIntent().getIntExtra("tabbedPosition", 0));
	}

	public class PersonalSectionAdapter extends FragmentPagerAdapter {

		public PersonalSectionAdapter(FragmentManager fm) {
			super(fm);
		}

		@Override
		public Fragment getItem(int position) {
			Fragment fragment = new Fragment();
			switch (position) {
			case 0:
				fragment = new PersonalizeFragment();
				break;
			case 1:
				fragment = new DisplaySavedLocations();
				break;
			case 2:
				fragment = new DisplaySavedPlans();
				break;
			}
			return fragment;
		}

		@Override
		public int getCount() {
			return 3;
		}

		@Override
		public CharSequence getPageTitle(int position) {
			switch (position) {
			case 0:
				return "Personalize";
			case 1:
				return "Saved Places";
			case 2:
				return "Saved Plans";
			}
			return "Personal";
		}
	}

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}