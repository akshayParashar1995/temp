package com.strollup.personal;

import java.util.List;

public class UserPersonalisedResponse {
	
	private List<PersonalizedString> personalizedTags;

	public List<PersonalizedString> getPersonalizedTags() {
		return personalizedTags;
	}

	public void setPersonalizedTags(List<PersonalizedString> personalizedTags) {
		this.personalizedTags = personalizedTags;
	}




}
