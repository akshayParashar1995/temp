package com.strollup.personal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.koushikdutta.ion.Ion;
import com.strollup.plan.MobilePlan;
import com.strollup.utility.Globals;

import java.util.List;

import in.strollup.android.R;

public class DisplayPlansAdapter extends ArrayAdapter<MobilePlan> {

    private Context context;
    private ListView listView;
    private final LayoutInflater inflater;
    private RelativeLayout layout;
    private List<MobilePlan> mobilePlans;

    public DisplayPlansAdapter(Context context, int resource, List<MobilePlan> objects, ListView gv) {
        super(context, resource, objects);
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.listView = listView;
        this.context = context;
        this.mobilePlans = objects;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // return super.getView(position, convertView, parent);
        convertView = null;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.display_saved_plans, null);
        }
        final MobilePlan mobilePlan = Globals.savedPlans.getPlans().get(position);
        LinearLayout layout = (LinearLayout) convertView.findViewById(R.id.single_plan_layout);
        layout.setWeightSum((float) (mobilePlan.getPlanDetails().size() + 0.1 * (mobilePlan.getPlanDetails().size() - 1)));
        for (int i = 0; i < mobilePlan.getPlanDetails().size(); i++) {
            View childView = new View(context);
            LayoutInflater vi = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            childView = vi.inflate(R.layout.single_plan_item, null);
            ImageView imageView = (ImageView) childView.findViewById(R.id.single_plan_image_saved);
            TextView name = (TextView) childView.findViewById(R.id.single_plan_name_saved);
            name.setText(mobilePlan.getPlanDetails().get(i).getLocation().getName());

            imageView.setScaleType(ScaleType.FIT_XY);

            Ion.with(imageView)
                    .placeholder(R.drawable.preloader)
                    .error(R.drawable.error_image)
                    .load(mobilePlan.getPlanDetails().get(i).getLocation().getImage());

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
            params.weight = 1;
            params.setMargins(15, 20, 15, 20);
            layout.addView(childView, params);
            View seperatorVew = new View(context);
            seperatorVew = vi.inflate(R.layout.single_plan_seperator, null);
            params = new LayoutParams(0, android.view.ViewGroup.LayoutParams.MATCH_PARENT);
            params.weight = (float) 0.1;
            layout.addView(seperatorVew, params);

        }
        return convertView;
    }

}
