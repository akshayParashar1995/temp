package com.strollup.personal;

import android.widget.Button;

public class ButtonToPersonalizedTag {
	
	public Button button;
	
	public int id;

}
