package com.strollup.personal;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.strollup.save.SavedMobileLocationDto;
import com.strollup.utility.Globals;

import java.util.List;

import in.strollup.android.R;

public class DisplaySavedLocations extends Fragment {

	List<SavedMobileLocationDto> savedOuterList;
	RelativeLayout layout;
	Button getPlacesbutton;
	
	@Override
	public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		View v = inflater.inflate(R.layout.display_saved_locations_layout, null);
		layout=(RelativeLayout) v.findViewById(R.id.no_saved_places_layout);
		getPlacesbutton=(Button) v.findViewById(R.id.get_places_button);
		savedOuterList = Globals.savedLoacations;
		if (savedOuterList.size() == 0) {
			TextView noText = (TextView) v.findViewById(R.id.no_save_text);
			layout.setVisibility(View.VISIBLE);
			getPlacesbutton.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
//					Intent i=new Intent(getActivity(),NavigationAndTabs.class);
//					startActivity(i);
					getActivity().finish();
				}
			});

		} else {
			final GridView gv = (GridView) v.findViewById(R.id.saved_places_grid_view);
			DisplayLocationsAdapter adapter = new DisplayLocationsAdapter(getActivity(), 0, savedOuterList, gv);
			gv.setAdapter(adapter);
		}
		return v;

	}

}
