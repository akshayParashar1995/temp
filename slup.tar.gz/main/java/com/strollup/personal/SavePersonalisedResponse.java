package com.strollup.personal;

public class SavePersonalisedResponse {
	
	private boolean savePersonalizationResponse;

	public boolean isSavePersonalizationResponse() {
		return savePersonalizationResponse;
	}

	public void setSavePersonalizationResponse(boolean savePersonalizationResponse) {
		this.savePersonalizationResponse = savePersonalizationResponse;
	}

}
