package com.strollup.personal;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.Cache;
import com.android.volley.Cache.Entry;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.google.gson.Gson;
import com.strollup.main.AppController;
import com.strollup.request.BaseRequest;
import com.strollup.request.UserPersonalRequest;
import com.strollup.utility.Constants;
import com.strollup.utility.GsonRequest;
import com.strollup.utility.Utils;

import java.util.ArrayList;
import java.util.List;

import in.strollup.android.R;

public class PersonalizeFragment extends android.support.v4.app.Fragment {
    private List<PersonalizedString> personalizedTags;
    private boolean flags[];
    GsonRequest<UserResponse> myReq;
    private PersonalizeAdapter adapter;
    private View v;
    private String url1;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        UserPersonalRequest userPersonalRequest = new UserPersonalRequest(getActivity().getApplicationContext());
        v = inflater.inflate(R.layout.personalization, null);
        String url = Constants.BASE_SERVER_URL + "fetchPersonalization?baseRequestString="
                + new Gson().toJson(userPersonalRequest);
        url1 = url;
        loadContent(url);
        return v;
    }

    private void onSuccess(UserResponse userResult) {
        personalizedTags = new ArrayList<PersonalizedString>();
        personalizedTags = userResult.getUserPersonalizationString().getPersonalizedTags();
        flags = new boolean[personalizedTags.size()];
        for (int i = 0; i < personalizedTags.size(); i++) {
            flags[i] = personalizedTags.get(i).isSelected();
        }

        GridView gv = (GridView) v.findViewById((int) R.id.personaliseGrid);
        adapter = new PersonalizeAdapter(getActivity(), 0, personalizedTags, gv);
        gv.setAdapter(adapter);

        gv.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> gv, View view, int position, long arg3) {
                AppController.getInstance().getRequestQueue().getCache().remove(url1);
                int id = position;
                if (flags[id] == true) {
                    TextView tv = (TextView) view.findViewById(R.id.textValue);
                    LinearLayout ll = (LinearLayout) view.findViewById(R.id.personalLayout);
                    ll.setBackgroundResource(R.drawable.button_white);
                    tv.setTextColor(getActivity().getApplicationContext().getResources().getColor(R.color.green));
                    pingUserChoice(personalizedTags.get(id).getId(), false);
                    flags[id] = false;

                } else if (flags[id] == false) {
                    TextView tv = (TextView) view.findViewById(R.id.textValue);
                    LinearLayout ll = (LinearLayout) view.findViewById(R.id.personalLayout);
                    ll.setBackgroundResource(R.drawable.button_green);
                    tv.setTextColor(getActivity().getApplicationContext().getResources().getColor(R.color.white));
                    pingUserChoice(personalizedTags.get(id).getId(), true);
                    flags[id] = true;

                }
            }
        });
    }

    private void loadContent(String url) {
        // mProgressBar.setVisibility(View.VISIBLE);
        Cache cache = AppController.getInstance().getRequestQueue().getCache();
        Entry entry = cache.get(url);
        if (entry != null && entry.serverDate + Constants.CACHE_EXPIRY_TIME > System.currentTimeMillis()) {
            try {
                String data = new String(entry.data, "UTF-8");
                UserResponse userResult = (UserResponse) Utils.getCachedResponse(UserResponse.class, data);
                onSuccess(userResult);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            AppController.getInstance().getRequestQueue().getCache().invalidate(url, true);
            myReq = new GsonRequest<UserResponse>(Request.Method.GET, url, UserResponse.class,
                    createMyReqSuccessListener(), createMyReqErrorListener());
            AppController.getInstance().getRequestQueue().add(myReq);
        }

    }

    private Listener<UserResponse> createMyReqSuccessListener() {
        return new Response.Listener<UserResponse>() {
            @Override
            public void onResponse(UserResponse userResult) {
                onSuccess(userResult);
            }
        };
    }

    private ErrorListener createMyReqErrorListener() {
        return new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Error: ", "Error occurred while calling backend", error.getCause());
            }
        };
    }

    private void pingUserChoice(int optionId, boolean state) {
        UserPersonalisedResponse userResponse = new UserPersonalisedResponse();
        List<PersonalizedString> personalString = new ArrayList<PersonalizedString>();
        PersonalizedString object = new PersonalizedString();
        object.setId(optionId);
        object.setSelected(state);
        personalString.add(object);
        userResponse.setPersonalizedTags(personalString);
        BaseRequest baseRequest = new BaseRequest(getActivity().getApplicationContext());
        String url = Constants.BASE_SERVER_URL + "savePersonalization?baseRequestString="
                + new Gson().toJson(baseRequest) + "&userPersonalizationString=" + new Gson().toJson(userResponse);
        loadUserPing(url);
    }

    private void loadUserPing(String url) {
        GsonRequest<SavePersonalisedResponse> myReq = new GsonRequest<SavePersonalisedResponse>(Request.Method.GET,
                url, SavePersonalisedResponse.class, createMyUserSuccessListener(), createMyUserErrorListener());
        AppController.getInstance().getRequestQueue().add(myReq);
    }

    private Listener<SavePersonalisedResponse> createMyUserSuccessListener() {
        return new Response.Listener<SavePersonalisedResponse>() {
            @Override
            public void onResponse(SavePersonalisedResponse arg0) {
            }
        };
    }

    private ErrorListener createMyUserErrorListener() {
        return new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Error: ", "Error occurred while calling backend", error.getCause());
            }
        };
    }

}
