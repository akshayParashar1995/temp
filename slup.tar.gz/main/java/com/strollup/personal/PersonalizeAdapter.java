package com.strollup.personal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import in.strollup.android.R;

public class PersonalizeAdapter extends ArrayAdapter<PersonalizedString> {

    private final LayoutInflater inflater;
    private Context mContext;
    public PersonalizeAdapter(Context context, int resource, List<PersonalizedString> objects, GridView gridView) {
        super(context, resource, objects);
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mContext=context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.personalisation_single_item, null);
        }
        TextView tv = (TextView) convertView.findViewById(R.id.textValue);
        LinearLayout ll=(LinearLayout)convertView.findViewById(R.id.personalLayout);
        String string = getItem(position).getName();
        tv.setText(string);
        tv.setTextColor(mContext.getResources().getColor(R.color.green));
        boolean isSelected=getItem(position).isSelected();
        if(isSelected){
            ll.setBackgroundResource(R.drawable.button_green);
            tv.setTextColor(mContext.getResources().getColor(R.color.white));
        } else {
            ll.setBackgroundResource(R.drawable.button_white);
            tv.setTextColor(mContext.getResources().getColor(R.color.green));
        }
        return convertView;
    }
}