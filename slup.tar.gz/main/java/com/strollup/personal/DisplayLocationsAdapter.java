package com.strollup.personal;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.koushikdutta.ion.Ion;
import com.strollup.model.location.LocationDto;
import com.strollup.place.PlaceDetailActivity;
import com.strollup.save.SavedMobileLocationDto;

import java.util.List;

import in.strollup.android.R;

public class DisplayLocationsAdapter extends ArrayAdapter<SavedMobileLocationDto> {

    private Context context;
    private GridView gridView;
    private final LayoutInflater inflater;
    private RelativeLayout layout;

    public DisplayLocationsAdapter(Context context, int resource, List<SavedMobileLocationDto> objects, GridView gv) {
        super(context, resource, objects);
        // TODO Auto-generated constructor stub
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.gridView = gridView;
        this.context = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        //return super.getView(position, convertView, parent);
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.display_saved_locations, null);

        }

        final SavedMobileLocationDto outerLocation = getItem(position);
        LocationDto location = outerLocation.getLocation();
        String date = outerLocation.getSavedDate();

        TextView placeAreaTv = (TextView) convertView.findViewById(R.id.place_area);
        TextView placeCostTv = (TextView) convertView.findViewById(R.id.place_cost);
        TextView placeNameTv = (TextView) convertView.findViewById(R.id.place_name);
        TextView placeDate = (TextView) convertView.findViewById(R.id.saved_date);
        TextView ratingTv = (TextView) convertView.findViewById(R.id.place_rating2);
        ImageView placeImage = (ImageView) convertView.findViewById(R.id.activity_image);
        placeImage.setScaleType(ScaleType.FIT_XY);
        layout = (RelativeLayout) convertView.findViewById(R.id.place_image);

        Ion.with(placeImage)
                .placeholder(R.drawable.preloader)
                .error(R.drawable.error_image)
                .load(location.getImage());

        placeAreaTv.setText(location.getRegion());
        placeCostTv.setText(location.getCostText());
        placeNameTv.setText(location.getName());
        ratingTv.setText(location.getRating());
        placeDate.setText(date);
        convertView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent i = new Intent(context, PlaceDetailActivity.class);
                i.putExtra("activity_id", outerLocation.getLocation().getActivityId());
                i.putExtra("location_detail_id", outerLocation.getLocation().getId());
                context.startActivity(i);
            }
        });

        return convertView;

    }

}
