package com.strollup.personal;

public class UserResponse {
	
	private UserPersonalisedResponse userPersonalizationString;

	public UserPersonalisedResponse getUserPersonalizationString() {
		return userPersonalizationString;
	}

	public void setUserPersonalizationString(UserPersonalisedResponse userPersonalizationString) {
		this.userPersonalizationString = userPersonalizationString;
	}

}
