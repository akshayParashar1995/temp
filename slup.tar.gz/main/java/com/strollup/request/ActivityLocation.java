package com.strollup.request;

public class ActivityLocation {

	private int locationDetailId;
	private int activityId;

	public ActivityLocation(int locationDetailId, int activityId) {
		super();
		this.locationDetailId = locationDetailId;
		this.activityId = activityId;
	}

	public int getLocationDetailId() {
		return locationDetailId;
	}

	public int getActivityId() {
		return activityId;
	}

	@Override
	public boolean equals(Object obj) {
		ActivityLocation location = (ActivityLocation) obj;
        if(this == null && obj == null) {
            return true;
        }
        if((this == null && obj != null) || (this != null && obj == null)) {
            return false;
        }
		if (this.getActivityId() == location.getActivityId()
				&& this.getLocationDetailId() == location.getLocationDetailId()) {
			return true;
		}
		return false;
	}
}
