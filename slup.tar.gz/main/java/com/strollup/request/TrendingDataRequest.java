package com.strollup.request;

import android.content.Context;

public class TrendingDataRequest extends BaseRequest {

	public TrendingDataRequest(Context context, int tableNameId, int tableRowId) {
		super(context);
		this.tableNameId = tableNameId;
		this.tableRowId = tableRowId;
		// TODO Auto-generated constructor stub
	}

	private int tableNameId;
	private int tableRowId;

	public int getTableNameId() {
		return tableNameId;
	}

	public void setTableNameId(int tableNameId) {
		this.tableNameId = tableNameId;
	}

	public int getTableRowId() {
		return tableRowId;
	}

	public void setTableRowId(int tableRowId) {
		this.tableRowId = tableRowId;
	}

}
