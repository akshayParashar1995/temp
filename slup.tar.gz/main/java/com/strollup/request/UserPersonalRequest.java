package com.strollup.request;

import android.content.Context;

public class UserPersonalRequest extends BaseRequest{

	public UserPersonalRequest(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

}
