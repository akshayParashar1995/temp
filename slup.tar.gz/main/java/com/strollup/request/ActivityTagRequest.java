package com.strollup.request;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;

public class ActivityTagRequest extends BaseRequest {
	private List<Integer> activityTypeIds;

	public ActivityTagRequest(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	public List<Integer> getActivityTypeIds() {
		return activityTypeIds;
	}

	public void setActivityTypeIds(List<Integer> activityTypeIds) {
		this.activityTypeIds = activityTypeIds;
	}
	public void addActivityTypeIds(int activityTypeId) {
		if (activityTypeIds == null) {
			activityTypeIds = new ArrayList<Integer>();
		}
		activityTypeIds.add(activityTypeId);
	}
}
