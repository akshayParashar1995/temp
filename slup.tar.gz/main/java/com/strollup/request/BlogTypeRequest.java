package com.strollup.request;

import android.content.Context;

public class BlogTypeRequest extends BaseRequest {

	public BlogTypeRequest(Context context) {
		super(context);
	}
}
