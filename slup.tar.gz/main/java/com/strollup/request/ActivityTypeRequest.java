package com.strollup.request;

import android.content.Context;

public class ActivityTypeRequest extends BaseRequest {

	public ActivityTypeRequest(Context context) {
		super(context);
	}
}
