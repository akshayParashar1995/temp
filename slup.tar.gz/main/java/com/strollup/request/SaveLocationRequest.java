package com.strollup.request;

import android.content.Context;

public class SaveLocationRequest extends BaseRequest {

	private ActivityLocation activityLocation;
	private boolean isSaved;

	public SaveLocationRequest(Context context,  boolean isSaved, ActivityLocation activityLocation) {
		super(context);
		this.isSaved = isSaved;
		this.activityLocation = activityLocation;
	}

	public ActivityLocation getActivityLocation() {
		return activityLocation;
	}

	public void setActivityLocation(ActivityLocation activityLocation) {
		this.activityLocation = activityLocation;
	}

	public boolean isSaved() {
		return isSaved;
	}

	public void setSaved(boolean isSaved) {
		this.isSaved = isSaved;
	}
}
