package com.strollup.request;

import android.content.Context;

public class ShowPlansRequest extends BaseRequest {

	private ActivityAtLocation activityAtLocation;
	private boolean isFilterApplied;

	public ShowPlansRequest(Context context, ActivityAtLocation activityAtLocation, boolean isFilterApplied) {
		super(context);
		this.isFilterApplied = isFilterApplied;
		this.activityAtLocation = activityAtLocation;
		// TODO Auto-generated constructor stub
	}

	public ActivityAtLocation getActivityAtLocation() {
		return activityAtLocation;
	}

	public void setActivityAtLocation(ActivityAtLocation activityAtLocation) {
		this.activityAtLocation = activityAtLocation;
	}

	public boolean isFilterApplied() {
		return isFilterApplied;
	}

	public void setFilterApplied(boolean isFilterApplied) {
		this.isFilterApplied = isFilterApplied;
	}

}
