package com.strollup.request;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;

public class ListingSearchRequest extends BaseRequest {

	private List<Integer> activityTypeIds;
	private int pageNo;

    public int getContext() {
        return context;
    }

    public void setContext(int context) {
        this.context = context;
    }

    private int context;
	public ListingSearchRequest(Context context) {
		super(context);
	}
    private String searchString;
	public List<Integer> getActivityTypeIds() {
		return activityTypeIds;
	}

	public void setActivityTypeIds(List<Integer> activityTypeIds) {
		this.activityTypeIds = activityTypeIds;
	}

	public void addActivityTypeIds(int activityTypeId) {
		if (activityTypeIds == null) {
			activityTypeIds = new ArrayList<Integer>();
		}
		activityTypeIds.add(activityTypeId);
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

    public String getSearchString(){return searchString;}

    public void setSearchString(String searchString)
    {
        this.searchString=searchString;
    }
}
