package com.strollup.request;

import android.content.Context;

public class SavedLocationRequest extends BaseRequest {

	private int limit = 1000;
	private int pageNo = 1;
	
	public SavedLocationRequest(Context context) {
		super(context);
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

}
