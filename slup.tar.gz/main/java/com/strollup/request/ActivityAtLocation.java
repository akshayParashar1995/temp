package com.strollup.request;

public class ActivityAtLocation extends ActivityLocation {

	private int locationNumber;

	public ActivityAtLocation(int locationDetailId, int activityId, int locationNumber) {
		super(locationDetailId, activityId);
		this.locationNumber = locationNumber;
	}

	public int getLocationNumber() {
		return locationNumber;
	}

	public void setLocationNumber(int locationNumber) {
		this.locationNumber = locationNumber;
	}
}
