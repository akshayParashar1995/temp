package com.strollup.request;

import android.content.Context;

public class UnsaveUserPlanRequest extends BaseRequest {

	private int planInfoId;

	public UnsaveUserPlanRequest(Context context, int planInfoId) {
		super(context);
		this.planInfoId = planInfoId;
	}

	public int getPlanInfoId() {
		return planInfoId;
	}

	public void setPlanInfoId(int planInfoId) {
		this.planInfoId = planInfoId;
	}
}
