package com.strollup.request;

import android.content.Context;

import java.util.List;

public class SaveUserPlanRequest extends BaseRequest {
	private List<ActivityAtLocation> plan;
	private int planSequenceNumber;
	private boolean isSaved;

	public SaveUserPlanRequest(Context context, List<ActivityAtLocation> plan, int planSequenceNumber) {
		super(context);
		this.planSequenceNumber = planSequenceNumber;
		this.isSaved = true;
		this.plan = plan;
		// TODO Auto-generated constructor stub
	}

	public int getPlanSequenceNumber() {
		return planSequenceNumber;
	}

	public void setPlanSequenceNumber(int planSequenceNumber) {
		this.planSequenceNumber = planSequenceNumber;
	}

	public boolean isSaved() {
		return isSaved;
	}

	public void setSaved(boolean isSaved) {
		this.isSaved = isSaved;
	}

	public List<ActivityAtLocation> getPlan() {
		return plan;
	}

	public void setPlan(List<ActivityAtLocation> plan) {
		this.plan = plan;
	}

}
