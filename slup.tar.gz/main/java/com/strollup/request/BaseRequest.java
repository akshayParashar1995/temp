package com.strollup.request;

import android.content.Context;

import com.strollup.filter.Region;
import com.strollup.utility.AppPreferences;
import com.strollup.utility.Utils;

public class BaseRequest {

    private int cityId;
    private int userId;
    private int sourceId = 2;
    private String deviceId;
    private Region region;
    private String version;
    private String name;

    public BaseRequest(Context context) {
        super();
        this.cityId = AppPreferences.getCityId(context);
        this.userId = AppPreferences.getUserId(context);
        this.deviceId = AppPreferences.getDeviceId(context);
        if (Utils.isGpsEnabled(context)) {
            this.region = Utils.getNearByRegion(context);
            this.region.setArea(this.region.getArea().replaceAll(" ", "%20"));
        }
        this.version = String.valueOf(Utils.getCurrentVersionName(context));
        this.name = AppPreferences.getUsername(context).replaceAll(" ", "%20");
    }

    public int getCityId() {
        return cityId;
    }

    public void setCityId(int cityId) {
        this.cityId = cityId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getSourceId() {
        return sourceId;
    }

    public void setSourceId(int sourceId) {
        this.sourceId = sourceId;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public Region getRegion() {
        return region;
    }

    public void setRegion(Region region) {
        this.region = region;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}