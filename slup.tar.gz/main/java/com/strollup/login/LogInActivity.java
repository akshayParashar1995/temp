package com.strollup.login;

import android.content.Context;
import android.content.Intent;
import android.content.IntentSender.SendIntentException;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.toolbox.JsonObjectRequest;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.plus.People.LoadPeopleResult;
import com.google.android.gms.plus.Plus;
import com.google.android.gms.plus.Plus.PlusOptions;
import com.google.android.gms.plus.model.people.Person;
import com.strollup.main.AppController;
import com.strollup.main.CityActivity;
import com.strollup.utility.AppPreferences;
import com.strollup.utility.Constants;
import com.strollup.utility.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;

import in.strollup.android.R;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class LogInActivity extends AppCompatActivity implements OnClickListener, ConnectionCallbacks,
        OnConnectionFailedListener, ResultCallback<LoadPeopleResult> {

    private static final int RC_SIGN_IN = 0;
    private boolean mSignInClicked;
    private boolean mIntentInProgress;
    private static GoogleApiClient mGoogleApiClient;
    private ConnectionResult mConnectionResult;
    private SignInButton googlePlusbutton;
    private EditText email, password;
    private CallbackManager callbackManager;
    private LoginButton facebookLoginButton;
    private float scale = 0.0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        scale = getApplicationContext().getResources().getDisplayMetrics().density;
        setContentView(R.layout.activity_log_in);

        getSupportActionBar().hide();

        googlePlusbutton = (SignInButton) findViewById(R.id.google_signin_button);
        setGooglePlusButtonText(googlePlusbutton, "Sign in with Google");
        googlePlusbutton.setOnClickListener(this);

        FacebookSdk.sdkInitialize(getApplicationContext());
        callbackManager = CallbackManager.Factory.create();
        facebookLoginButton = (LoginButton) findViewById(R.id.facebook_signin_button);
        facebookLoginButton.setReadPermissions(Arrays.asList("email", "public_profile", "user_friends"));
        facebookLoginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                GraphRequest.newMeRequest(
                        loginResult.getAccessToken(), new GraphRequest.GraphJSONObjectCallback() {
                            @Override
                            public void onCompleted(JSONObject json, GraphResponse response) {
                                if (response.getError() != null) {
                                    // handle error
                                } else {
                                    try {
                                        String jsonresult = String.valueOf(json);
                                        System.out.println("JSON Result" + jsonresult);

                                        String email = json.getString("email");
                                        String id = json.getString("id");
                                        String name = json.getString("first_name");
                                        String facebookProfile = (String) json.getString("link");
                                        String photo = "https://graph.facebook.com/" + id + "/picture";
                                        UserDto userDto = new UserDto(id, name, email, photo, facebookProfile);
                                        String url = Utils.getFbLoginUrl(userDto);
                                        fetchUserData(userDto, url, "facebook");
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }

                        }).executeAsync();

            }

            @Override
            public void onCancel() {
            }

            @Override
            public void onError(FacebookException exception) {
            }
        });


        TextView tv1 = (TextView) findViewById(R.id.forgotpassword);
        TextView tv2 = (TextView) findViewById(R.id.notamember);
        Button login = (Button) findViewById(R.id.login);
        email = (EditText) findViewById(R.id.emailedit);
        password = (EditText) findViewById(R.id.passwordedit);

        tv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                i.setClass(getApplicationContext(), ForgotPasswordActivity.class);
                startActivity(i);
            }
        });
        tv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pass = password.getText().toString().trim();
                UserDto userDto = new UserDto(email.getText().toString().trim(), Utils.getMd5Password(pass));
                String url = Utils.getStrollUpLoginUrl(userDto.getEmail(), userDto.getPassword());
                fetchUserData(userDto, url, "StrollUp");
            }
        });

        mGoogleApiClient = new GoogleApiClient.Builder(this).addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this).addApi(Plus.API, PlusOptions.builder().build())
                .addScope(Plus.SCOPE_PLUS_LOGIN).addScope(Plus.SCOPE_PLUS_PROFILE).build();
    }

    protected void setGooglePlusButtonText(SignInButton signInButton, String buttonText) {
        for (int i = 0; i < signInButton.getChildCount(); i++) {
            View v = signInButton.getChildAt(i);
            if (v instanceof TextView) {
                TextView tv = (TextView) v;
                Typeface font = Typeface.createFromAsset(this.getAssets(), Constants.BASE_FONT);
                tv.setTypeface(font);
                tv.setText(buttonText);
                tv.setTextSize(15);
                return;
            }
        }
    }


    @Override
    public void onConnected(Bundle arg0) {
        Plus.PeopleApi.loadVisible(mGoogleApiClient, null).setResultCallback(this);
        mSignInClicked = false;
        if (Plus.PeopleApi.getCurrentPerson(mGoogleApiClient) != null) {
            Person currentPerson = Plus.PeopleApi.getCurrentPerson(mGoogleApiClient);
            String email = Plus.AccountApi.getAccountName(mGoogleApiClient);
            String name = currentPerson.getDisplayName();
            String photo = currentPerson.getImage().getUrl();
            photo = photo.replace("sz=50", "sz=100");
            String googlePlusProfile = currentPerson.getUrl();
            UserDto userDto = new UserDto(null, name, email, photo, googlePlusProfile);
            String url = Utils.getGPlusLoginUrl(userDto);
            fetchUserData(userDto, url, "google");
        }
    }

    public void fetchUserData(UserDto userDto, String url, String tag) {
        AppPreferences.setBasicProfile(getApplicationContext(), userDto.getName(), userDto.getPhoto());
        JsonObjectRequest myReq = new JsonObjectRequest(com.android.volley.Request.Method.GET, url, null,
                createMyReqSuccessListener(tag), createMyReqErrorListener());
        AppController.getInstance().addToRequestQueue(myReq);
    }

    private com.android.volley.Response.ErrorListener createMyReqErrorListener() {
        return new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(com.android.volley.VolleyError error) {
                Log.e("Error", "Error occured", error.getCause());
            }
        };
    }

    private com.android.volley.Response.Listener<JSONObject> createMyReqSuccessListener(final String tag) {
        return new com.android.volley.Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObj) {
                try {
                    int id = jsonObj.getInt("userId");
                    if (id == 0 && tag.equals("StrollUp")) {
                        Toast.makeText(getApplicationContext(), "Please enter correct email and password.",
                                Toast.LENGTH_LONG).show();
                        return;
                    }
                    AppPreferences.setLoggedInAsTrue(getApplicationContext());
                    AppPreferences.setUserId(getApplicationContext(), id);
                    Intent intent = new Intent();
                    intent = new Intent(getApplicationContext(), CityActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

                    startActivity(intent);
                    finish();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

        };
    }

    protected void onStop() {
        super.onStop();
        if (mGoogleApiClient.isConnected()) {
            mGoogleApiClient.disconnect();
        }
    }

    private void resolveSignInError() {
        if (mConnectionResult.hasResolution()) {
            try {
                mIntentInProgress = true;
                startIntentSenderForResult(mConnectionResult.getResolution().getIntentSender(), RC_SIGN_IN, null, 0, 0,
                        0);
            } catch (SendIntentException e) {
                mIntentInProgress = false;
                mGoogleApiClient.connect();
            }
        }
    }

    public void onConnectionFailed(ConnectionResult result) {
        if (!mIntentInProgress) {
            if (mSignInClicked && result.hasResolution()) {
                try {
                    result.startResolutionForResult(this, RC_SIGN_IN);
                    mIntentInProgress = true;
                } catch (SendIntentException e) {
                    mIntentInProgress = false;
                    mGoogleApiClient.connect();
                }
            }
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.google_signin_button && !mGoogleApiClient.isConnecting()) {
            mSignInClicked = true;
            mGoogleApiClient.connect();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int responseCode, Intent intent) {
        if (requestCode == RC_SIGN_IN) {
            if (responseCode != RESULT_OK) {
                mSignInClicked = false;
            }

            mIntentInProgress = false;

            if (!mGoogleApiClient.isConnecting()) {
                mGoogleApiClient.reconnect();
            }
        }
        callbackManager.onActivityResult(requestCode, responseCode, intent);
    }

    @Override
    public void onConnectionSuspended(int arg0) {
        mGoogleApiClient.connect();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.log_in, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onSaveInstanceState(Bundle savedState) {
        super.onSaveInstanceState(savedState);
    }

    @Override
    public void onResult(LoadPeopleResult arg0) {
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        float fbIconScale = 1.45F;
        Drawable drawable = this.getResources().getDrawable(
                com.facebook.R.drawable.com_facebook_button_icon);
        drawable.setBounds(0, 0, (int) (drawable.getIntrinsicWidth() * fbIconScale),
                (int) (drawable.getIntrinsicHeight() * fbIconScale));
        facebookLoginButton.setCompoundDrawables(drawable, null, null, null);
        facebookLoginButton.setCompoundDrawablePadding(this.getResources().
                getDimensionPixelSize(R.dimen.fb_margin_override_textpadding));
        facebookLoginButton.setPadding(
                facebookLoginButton.getResources().getDimensionPixelSize(
                        R.dimen.fb_margin_override_lr),
                facebookLoginButton.getResources().getDimensionPixelSize(
                        R.dimen.fb_margin_override_top),
                0,
                facebookLoginButton.getResources().getDimensionPixelSize(
                        R.dimen.fb_margin_override_bottom));
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}