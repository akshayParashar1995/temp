package com.strollup.login;

public class UserDto {

	private String id;
	private String name;
	private String password;
	private String email;
	private String photo;
	private String response;

	public UserDto(String email, String password) {
		this.email = email;
		this.password = password;
	}

	public UserDto(String id, String name, String email, String photo, String response) {
		this.id = id;
		this.name = name;
		this.email = email;
		this.photo = photo;
		this.response = response;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	public String getPhoto() {
		return photo;
	}

	public String getResponse() {
		return response;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}