package com.strollup.login;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.strollup.main.AppController;
import com.strollup.utility.Constants;
import com.strollup.utility.GsonRequest;

import in.strollup.android.R;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class ForgotPasswordActivity extends Activity {
	private static final String TAG = ForgotPasswordActivity.class.getSimpleName();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_forgot_password);

		TextView tv = (TextView) findViewById(R.id.cancel);

		tv.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		final EditText et = (EditText) findViewById(R.id.resetedit);
		Button b = (Button) findViewById(R.id.login);
		b.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Editable email = et.getText();
				String mail = email.toString();
				String preEmail = "{\"type\":\"StrollUpUserDto\",\"properties\":{\"registerType\":{\"name\":STROLLUP},\"email\":\"";
				String postEmail = "\"}}";
				String url = Constants.BASE_SERVER_URL + "sendForgetPasswordMobileMail?strollUpUserDtoString="
						+ preEmail + mail + postEmail;
				loadContent(url);

			}
		});
	}

	private void loadContent(String url) {
		GsonRequest<ForgotPasswordResponse> myReq = new GsonRequest<ForgotPasswordResponse>(Request.Method.GET, url,
				ForgotPasswordResponse.class, createMyReqSuccessListener(), createMyReqErrorListener());
		AppController.getInstance().addToRequestQueue(myReq, TAG);
	}

	private Response.ErrorListener createMyReqErrorListener() {
		return new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {
				Log.e(TAG, "Error Occured while calling backend", error.getCause());
				Toast.makeText(getApplicationContext(), Constants.GENERAL_ERROR_MESSAGE, Toast.LENGTH_LONG).show();
			}
		};
	}

	private void onSuccess(ForgotPasswordResponse forgotPasswordResponse) {
		try {
			String response = forgotPasswordResponse.getUserResponseString();
			if (response.equals(Constants.TRUE)) {
				TextView tv = (TextView) findViewById(R.id.textView1);
				tv.setText(Constants.FORGOT_PASSWORD_SUCCESS);
				Button b = (Button) findViewById(R.id.login);
				b.setVisibility(View.INVISIBLE);
				EditText et = (EditText) findViewById(R.id.resetedit);
				et.setVisibility(View.INVISIBLE);
			} else {
				TextView tv = (TextView) findViewById(R.id.textView1);
				tv.setText(Constants.FORGOT_PASSWORD_FAIL);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private Response.Listener<ForgotPasswordResponse> createMyReqSuccessListener() {
		return new Response.Listener<ForgotPasswordResponse>() {
			@Override
			public void onResponse(ForgotPasswordResponse forgotPasswordResponse) {
				onSuccess(forgotPasswordResponse);
			};
		};
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.forgot_password, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
