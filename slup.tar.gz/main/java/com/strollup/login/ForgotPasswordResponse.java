package com.strollup.login;

public class ForgotPasswordResponse {

	private String userResponseString;

	public String getUserResponseString() {
		return userResponseString;
	}

	public void setUserResponseString(String userResponseString) {
		this.userResponseString = userResponseString;
	}
}
