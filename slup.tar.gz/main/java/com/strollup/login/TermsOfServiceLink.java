package com.strollup.login;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

import com.strollup.utility.Constants;
import com.strollup.utility.WebViewController;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

/**
 * Created by DELL LAPTOP on 7/3/2015.
 */
public class TermsOfServiceLink extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new WebViewController().launchWebView(getApplicationContext(), Constants.TERMS_OF_SERVICE_URL));
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
