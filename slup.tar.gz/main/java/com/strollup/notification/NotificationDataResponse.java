package com.strollup.notification;

import java.util.List;

public class NotificationDataResponse {

	private List<NotificationDto> notificationStrings;

	public List<NotificationDto> getNotificationStrings() {
		return notificationStrings;
	}

	public void setNotificationStrings(List<NotificationDto> notificationStrings) {
		this.notificationStrings = notificationStrings;
	}

}
