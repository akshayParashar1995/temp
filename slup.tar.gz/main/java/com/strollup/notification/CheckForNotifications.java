package com.strollup.notification;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.google.gson.Gson;
import com.strollup.main.AppController;
import com.strollup.main.SplashScreen;
import com.strollup.request.BaseRequest;
import com.strollup.utility.AppPreferences;
import com.strollup.utility.Constants;
import com.strollup.utility.GsonRequest;
import com.strollup.utility.Utils;

import java.util.List;

public class CheckForNotifications {

	private Context context;
	private Activity act;

	private GsonRequest<NotificationDataResponse> myReq;

	public void checkIfThereIsAnyNotification(Context cont, Activity acti) {
		context = cont;
		act = acti;

		BaseRequest baseRequest = new BaseRequest(context);
		String versionUrl = Constants.BASE_SERVER_URL + "getNotifications?baseRequestString="
				+ new Gson().toJson(baseRequest);
		myReq = new GsonRequest<NotificationDataResponse>(Request.Method.GET, versionUrl,
				NotificationDataResponse.class, createMyReqSuccessListener(), createMyReqErrorListener());
		AppController.getInstance().getRequestQueue().add(myReq);
		SplashScreen.incrementNoOfVolleyRequests();
	}

	private Response.Listener<NotificationDataResponse> createMyReqSuccessListener() {
		return new Response.Listener<NotificationDataResponse>() {
			@Override
			public void onResponse(NotificationDataResponse notificationDataResponse) {
				List<NotificationDto> notificationStrings = notificationDataResponse.getNotificationStrings();
				if (notificationStrings.isEmpty()) {
					SplashScreen.decrementNoOfVolleyRequests();
					return;
				}
				NotificationDto notificationDto = notificationStrings.get(0);
				boolean isWillingToShowNotifications = AppPreferences.getIsWillingToShowNotification(context,
						notificationDto.getId());
				if (isWillingToShowNotifications) {
					ShowNotification.generateNotification(context,notificationDto);
					SplashScreen.decrementNoOfVolleyRequests();
				} else {
					SplashScreen.decrementNoOfVolleyRequests();
				}
			}
		};
	}

	private Response.ErrorListener createMyReqErrorListener() {
		return new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {
				Log.e("Error", "Error occured", error.getCause());
				if (error instanceof NoConnectionError || error instanceof TimeoutError)
					Utils.noNetworkMessageSplashScreen(act, myReq);
				SplashScreen.setBooleanTrue();
			}
		};
	}
}
