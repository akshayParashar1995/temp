package com.strollup.floating_action_button;

import android.app.Activity;

import com.facebook.FacebookSdk;
import com.facebook.share.model.AppInviteContent;
import com.facebook.share.widget.AppInviteDialog;
import com.strollup.utility.Constants;

/**
 * Created by Akshay on 17-07-2015.
 */
public class FacebookInvite {
    public static void inviteFacebookFriends(Activity activity){
        String appLinkUrl, previewImageUrl;
        FacebookSdk.sdkInitialize(activity.getApplicationContext());
        appLinkUrl = Constants.SHARE_APP_LINK;
        previewImageUrl = "https://www.strollup.in/image/fb-image.jpg";

        if (AppInviteDialog.canShow()) {
            AppInviteContent content = new AppInviteContent.Builder()
                    .setApplinkUrl(appLinkUrl)
                    .setPreviewImageUrl(previewImageUrl)
                    .build();
            AppInviteDialog.show(activity, content);
        }
    }
}
