package com.strollup.floating_action_button;

import android.content.Context;
import android.widget.Toast;

import java.io.Serializable;

/**
 * Created by Akshay on 16-07-2015.
 */
public class ContactObject implements Serializable, PopupInterface{
    private long id;
    private String name;
    private String image;
    private String detail;
    private boolean ischecked;


    public ContactObject(String name, String image, String detail,String id) {
        this.name = name;
        this.image = image;
        this.detail = detail;
        this.ischecked=false;
        this.id=Long.parseLong(id);
    }

    public String getDetail() {
        return detail;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public boolean isIschecked() {
        return ischecked;
    }

    public void setIschecked(boolean ischecked) {
        this.ischecked = ischecked;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void onPopupDropDownclick(Context context) {
        Toast.makeText(context,"Contact clicked",Toast.LENGTH_LONG).show();
    }
}
