package com.strollup.floating_action_button;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.strollup.request.BaseRequest;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;

import in.strollup.android.R;

/**
 * Created by Akshay on 16-07-2015.
 */
public class ContactsListAdapter extends BaseAdapter implements Filterable {

    private ArrayList<ContactObject> data;
    private ArrayList<ContactObject> orig;
    private static LayoutInflater inflater=null;
    private Context context;
    private Activity activity;
    int i=0;

    public ContactsListAdapter(Activity activity,Context context, ArrayList<ContactObject> data) {
        this.context=context;
        this.data=data;
        this.activity=activity;
        inflater = ( LayoutInflater )activity.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    public int getCount() {

        if(data.size()<=0)
            return 1;
        return data.size();
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    @Override
    public Filter getFilter() {
        return new Filter() {

            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                final FilterResults oReturn = new FilterResults();
                final ArrayList<ContactObject> results = new ArrayList<ContactObject>();
                if (orig == null)
                    orig = data;
                if (constraint != null) {
                    if (orig != null && orig.size() > 0) {
                        for (final ContactObject object : orig) {
                            if (object.getName().toLowerCase()
                                    .contains(constraint.toString()))
                                results.add(object);
                        }
                    }
                    oReturn.values = results;
                }
                return oReturn;
            }

            @SuppressWarnings("unchecked")
            @Override
            protected void publishResults(CharSequence constraint,
                                          FilterResults results) {
                data = (ArrayList<ContactObject>) results.values;
                if(data.size()!=0) {
                    notifyDataSetChanged();
                }
                else{
                    data=orig;
                }
            }
        };
    }

    public static class ViewHolder{

        public TextView nameText;
        public TextView detailText;
        public ImageView image;
        public CheckBox checkBox;
        public LinearLayout itemLayout;
    }

    public View getView(int position, View convertView, ViewGroup parent) {

        View vi = convertView;
        final ViewHolder holder;
//        convertView=null;
        if(convertView==null){

            vi = inflater.inflate(R.layout.contact_single_list_item, null);
            holder = new ViewHolder();
            holder.nameText = (TextView) vi.findViewById(R.id.tv1_contact);
            holder.detailText=(TextView)vi.findViewById(R.id.tv2_contact);
            holder.image=(ImageView)vi.findViewById(R.id.iv1_contact);
            holder.checkBox= (CheckBox) vi.findViewById(R.id.check_invite);
            holder.itemLayout= (LinearLayout) vi.findViewById(R.id.contact_simple_item_layout);
            vi.setTag( holder );
        }
        else
            holder=(ViewHolder)vi.getTag();
            final ContactObject object = ( ContactObject ) data.get( position );
            holder.checkBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    object.setIschecked(!object.isIschecked());
                    holder.checkBox.setChecked(object.isIschecked());
                }
            });
            holder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    Log.i("here2","click:"+isChecked);
                }
            });
            if(object.isIschecked()){
                holder.checkBox.setChecked(true);
            }
            else{
                holder.checkBox.setChecked(false);
            }
            holder.nameText.setText(object.getName());
            holder.detailText.setText(object.getDetail() );
            if(object.getImage()!=null)
                holder.image.setImageBitmap(loadContactPhoto(context.getContentResolver(),object.getId()));
            else{

                final Resources res = context.getResources();
                final int tileSize = res.getDimensionPixelSize(R.dimen.letter_tile_size);
                final LetterTileProvider tileProvider = new LetterTileProvider(context);
                final Bitmap letterTile = tileProvider.getLetterTile(object.getName(),object.getDetail(), tileSize, tileSize);
                holder.image.setImageDrawable(new BitmapDrawable(res, letterTile));
            }
            vi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                object.setIschecked(!object.isIschecked());
                holder.checkBox.setChecked(object.isIschecked());
            }
        });
        LinearLayout.LayoutParams par=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 150);
        par.setMargins(0,20,0,20);
        vi.setLayoutParams(par);
        return vi;
    }
    public static Bitmap loadContactPhoto(ContentResolver cr, long  id) {
        Uri uri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, id);
        InputStream input = ContactsContract.Contacts.openContactPhotoInputStream(cr, uri);
        if (input == null) {
            return null;
        }
        return BitmapFactory.decodeStream(input);
    }}
