package com.strollup.floating_action_button;

import com.strollup.plan.MobilePlan;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Akshay on 21-07-2015.
 */
public class OutingObject implements Serializable{
    private String name;
    private List<PopupInterface> friends;
    private List<PopupInterface> plans;
    private List<ChatMessageDto> chatList;

    public List<ChatMessageDto> getChatList() {
        return chatList;
    }

    public void setChatList(List<ChatMessageDto> chatList) {
        this.chatList = chatList;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<PopupInterface> getFriends() {

        return friends;
    }

    public void setFriends(List<PopupInterface> friends) {
        this.friends = friends;
    }

    public List<PopupInterface> getPlans() {
        if(plans==null){
            plans=new ArrayList<PopupInterface>();
        }
        return plans;
    }

    public void setPlans(List<PopupInterface> plans) {
        this.plans = plans;
    }
}
