package com.strollup.floating_action_button;

import android.content.Context;

/**
 * Created by Akshay on 22-07-2015.
 */
public interface PopupInterface {
    public void onPopupDropDownclick(Context context);
}
