package com.strollup.floating_action_button;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Rect;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import com.strollup.utility.Globals;

import java.util.ArrayList;
import java.util.List;

import in.strollup.android.R;

/**
 * Created by Akshay on 16-07-2015.
 */
public class InviteFriends extends AppCompatActivity {
    private SearchView searchView;
    private ListView listView;
    private ContactsListAdapter contactsListAdapter;
    private ArrayList<ContactObject> contactObjectArrayList;
    private Button shareOuting;
    private EditText nameOfOuting;
    private LinearLayout layout;
    private boolean isSearchInFocus = false;
    private boolean isNameInFocus = false;
    private boolean isCalledByOutingDiscuss = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.invite_friends);
        getSupportActionBar().setTitle("Create your group");
        getSupportActionBar().setHomeButtonEnabled(true);
        searchView = (SearchView) findViewById(R.id.invite_friends_search_text);
        listView = (ListView) findViewById(R.id.contacts_list);
        nameOfOuting = (EditText) findViewById(R.id.name_of_outing);
        shareOuting = (Button) findViewById(R.id.share_outing);
        layout = (LinearLayout) findViewById(R.id.invite_whole);
        contactObjectArrayList = fetchListOfContact();
        contactsListAdapter = new ContactsListAdapter(this, getApplicationContext(), contactObjectArrayList);
        listView.setAdapter(contactsListAdapter);
        listView.setTextFilterEnabled(true);
        ViewTreeObserver viewTreeObserver = layout.getViewTreeObserver();
        layout.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {

                Rect r = new Rect();
                layout.getWindowVisibleDisplayFrame(r);
                int screenHeight = layout.getRootView().getHeight();
                int keypadHeight = screenHeight - r.bottom;
                if (keypadHeight > screenHeight * 0.15) {
                    // keyboard is opened
                    if (searchView.hasFocus()) {
                        nameOfOuting.setVisibility(View.GONE);
                        isSearchInFocus = true;
                    }
                    if (nameOfOuting.hasFocus()) {
                        searchView.setVisibility(View.GONE);
                        listView.setVisibility(View.GONE);
                        isNameInFocus = true;
                    }
                    shareOuting.setVisibility(View.GONE);
                } else {
                    // keyboard is closed
                    if (isSearchInFocus) {
                        nameOfOuting.setVisibility(View.VISIBLE);
                        isSearchInFocus = false;
                    }
                    if (isNameInFocus) {
                        searchView.setVisibility(View.VISIBLE);
                        listView.setVisibility(View.VISIBLE);
                        isNameInFocus = false;
                    }
                    shareOuting.setVisibility(View.VISIBLE);
                }
            }
        });
        shareOuting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                FacebookInvite.inviteFacebookFriends(InviteFriends.this);
                OutingObject outingObject = new OutingObject();

                String name = nameOfOuting.getText().toString();
                outingObject.setName(name);
                outingObject.setFriends(getSelectedContacts());

                if (!outingObject.getName().equals("") && outingObject.getFriends().size() != 0) {
                    Intent intent = new Intent(InviteFriends.this, OutingDiscuss.class);
                    Globals.outingDto.setFriends(outingObject.getFriends());
                    Globals.outingDto.setName(outingObject.getName());
                    intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    startActivity(intent);
                } else {
                    if(outingObject.getName().equals(""))
                        Toast.makeText(getApplicationContext(), "Please enter name of Outing", Toast.LENGTH_LONG).show();
                    else if(outingObject.getFriends().size() == 0)
                        Toast.makeText(getApplicationContext(), "Invite atleast 1 Friend", Toast.LENGTH_LONG).show();
                }


            }
        });
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (TextUtils.isEmpty(newText)) {
                    listView.clearTextFilter();
                } else {
                    listView.setFilterText(newText);
                }
                return true;
            }
        });
    }

    private List<PopupInterface> getSelectedContacts() {
        List<PopupInterface> selectedContacts = new ArrayList<PopupInterface>();
        for (ContactObject contactObject : contactObjectArrayList) {
            if (contactObject.isIschecked()) {
                selectedContacts.add(contactObject);
            }
        }
        return selectedContacts;
    }

    private ArrayList<ContactObject> fetchListOfContact() {
        ArrayList<ContactObject> list = new ArrayList<ContactObject>();
        Cursor c = getContentResolver().query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
        c.moveToFirst();
        for (int i = 0; i < c.getCount(); i++) {
            String name = c.getString(c.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
            String id = c.getString(c.getColumnIndex(ContactsContract.Contacts._ID));
            if (Integer.parseInt(c.getString(c.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {
                Cursor pCur = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?", new String[]{id},
                        null);
                while (pCur.moveToNext()) {
                    String phone = pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    String image = pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_URI));
                    Log.i("cdd", phone + " " + image + " " + name);
                    list.add(new ContactObject(name, image, phone, id));
                }
            }
            c.moveToNext();
        }
        return list;
    }
}
