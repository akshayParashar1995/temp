package com.strollup.floating_action_button;

import android.content.Intent;
import android.database.DataSetObserver;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.strollup.main.NavigationAndTabs;
import com.strollup.utility.Globals;
import com.strollup.utility.Utils;

import java.util.ArrayList;
import java.util.List;

import in.strollup.android.R;

/**
 * Created by Akshay on 21-07-2015.
 */
public class OutingDiscuss extends AppCompatActivity {

    private TextView friendsText;
    private TextView plansText;
    private ListView chatList;
    private EditText chatText;
    private Button sendButton;
    private ChatListAdapter chatListAdapter;
    private ListView friendsList;
    private ListView plansList;
    private ImageView addPlan;
    private ImageView addFriend;
    private ImageView planDropdown;


    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        Log.i("onNewIntent", "here "+Globals.outingDto.getFriends().size());
        Globals.outingDto=Globals.outingDto;
        initializeFields(Globals.outingDto);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.outing_discuss);
        friendsText = (TextView) findViewById(R.id.friends_count_text);
        plansText = (TextView) findViewById(R.id.plans_count_text);
        chatList = (ListView) findViewById(R.id.chat_list);
        chatText = (EditText) findViewById(R.id.chat_text);
        sendButton = (Button) findViewById(R.id.send_chat);
        addPlan= (ImageView) findViewById(R.id.add_button_plans);
        planDropdown= (ImageView) findViewById(R.id.drop_down_pointer);
        addFriend= (ImageView) findViewById(R.id.add_button_friend);
        friendsList = (ListView) findViewById(R.id.friends_list);
        plansList = (ListView) findViewById(R.id.plans_list);
        initializeFields(Globals.outingDto);
        chatListAdapter = new ChatListAdapter(getApplicationContext(), R.layout.activity_chat_simple_message);
        chatList.setAdapter(chatListAdapter);
        chatList.setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);



        chatText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chatList.setVisibility(View.VISIBLE);
                plansList.setVisibility(View.GONE);
                friendsList.setVisibility(View.GONE);

            }
        });

        friendsText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (chatList.getVisibility() != View.VISIBLE) {
                    chatList.setVisibility(View.VISIBLE);
                    plansList.setVisibility(View.GONE);
                    friendsList.setVisibility(View.GONE);
                } else {
                    chatList.setVisibility(View.GONE);
                    plansList.setVisibility(View.GONE);
                    friendsList.setVisibility(View.VISIBLE);
                }
            }
        });
        plansText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (chatList.getVisibility() != View.VISIBLE) {
                    chatList.setVisibility(View.VISIBLE);
                    plansList.setVisibility(View.GONE);
                    friendsList.setVisibility(View.GONE);
                } else {
                    chatList.setVisibility(View.GONE);
                    plansList.setVisibility(View.VISIBLE);
                    friendsList.setVisibility(View.GONE);
                }
            }
        });
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (chatText != null) {
                    ChatMessageDto chatMessageDto = new ChatMessageDto(Utils.getProperDate(0),"enter time here!",chatText.getText().toString(), true, "Me");
                    chatListAdapter.add(chatMessageDto);
                    if(Globals.outingDto.getChatList()==null){
                        Globals.outingDto.setChatList(new ArrayList<ChatMessageDto>());
                    }
                    Globals.outingDto.getChatList().add(chatMessageDto);

                    ChatMessageDto chatMessageDto2 = new ChatMessageDto(Utils.getProperDate(0),"enter time here!",chatText.getText().toString(), false, "Akshay");        //senders name
                    chatListAdapter.add(chatMessageDto2);
                    Globals.outingDto.getChatList().add(chatMessageDto);

                    chatText.setText("");

                }
            }
        });
        chatListAdapter.registerDataSetObserver(new DataSetObserver() {
            @Override
            public void onChanged() {
                super.onChanged();
                chatList.setSelection(chatListAdapter.getCount() - 1);
            }
        });
        addFriend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(OutingDiscuss.this,InviteFriends.class);
                intent.putExtra("isCalledByOutingDiscuss",true);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivityForResult(intent,0);
            }
        });
        addPlan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(OutingDiscuss.this, NavigationAndTabs.class);
                intent.putExtra("isCalledByOutingDiscuss",true);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
    }
    private void initializeFields(OutingObject outingDto){
        getSupportActionBar().setTitle("" + outingDto.getName());
        friendsText.setText("0/"+outingDto.getFriends().size()+" friends joined");

        PopUpAdapter popUpAdapter = new PopUpAdapter(getApplicationContext(), outingDto.getFriends());
        friendsList.setAdapter(popUpAdapter);

        if(outingDto.getPlans().size()!=0) {
            PopUpAdapter popUpAdapterplans = new PopUpAdapter(getApplicationContext(), outingDto.getPlans());
            plansList.setAdapter(popUpAdapterplans);
            planDropdown.setVisibility(View.VISIBLE);
            plansText.setText(outingDto.getPlans().size()+" Plans Added");
        }
        else{
            plansText.setText("Add a plan");
            planDropdown.setVisibility(View.GONE);
        }
        if(outingDto.getChatList()!=null&&outingDto.getChatList().size()!=0){
            for(ChatMessageDto chatMessageDto:outingDto.getChatList()){
                chatListAdapter.add(chatMessageDto);
            }
        }

    }
}
