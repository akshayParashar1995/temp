package com.strollup.floating_action_button;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.strollup.plan.MobilePlan;
import com.strollup.plan.MobilePlanDetail;

import java.io.InputStream;
import java.util.List;

import in.strollup.android.R;

/**
 * Created by Akshay on 22-07-2015.
 */
public class PopUpAdapter extends BaseAdapter{

    Context context;
    List<?> content;
    boolean isContactList;
    public PopUpAdapter(Context context,List<?> content){
        this.context=context;
        this.content=content;

        if(content.get(0) instanceof MobilePlan){
            this.isContactList=false;
        }
        else if(content.get(0) instanceof ContactObject){
            this.isContactList=true;
        }
    }

    @Override
    public int getCount() {
        return content.size();
    }

    @Override
    public Object getItem(int position) {
        return content.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public static class ViewHolder{

        public TextView nameText;
        public TextView detailText;
        public ImageView image;

    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        final ViewHolder holder;
        convertView=null;

        if(convertView==null){
            LayoutInflater inflater = (LayoutInflater)context.
                    getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            vi = inflater.inflate(R.layout.custom_popup_list_item, null);
            holder = new ViewHolder();
            holder.nameText = (TextView) vi.findViewById(R.id.name_popup);
            holder.detailText=(TextView)vi.findViewById(R.id.detail_popup);
            holder.image=(ImageView)vi.findViewById(R.id.iv_popup);
            vi.setTag( holder );
        }
        else
            holder=(ViewHolder)vi.getTag();
        if(isContactList) {
            final ContactObject object = (ContactObject) content.get(position);
            holder.nameText.setText(object.getName());
            holder.detailText.setText(object.getDetail());
            if (object.getImage() != null)
                holder.image.setImageBitmap(loadContactPhoto(context.getContentResolver(), object.getId()));
            else {
                holder.image.setImageDrawable(context.getResources().getDrawable(R.drawable.profile_placeholder));
            }

        }
        else{
            MobilePlan object=(MobilePlan)content.get(position);
            int planNo=position+1;
            holder.nameText.setText("Plan "+planNo);
            String planDetail = "";
            for(MobilePlanDetail mobilePlanDetail:object.getPlanDetails()){
                planDetail+=mobilePlanDetail.getLocationName()+"->";
            }
            planDetail=planDetail.substring(0,planDetail.length()-2);
            holder.detailText.setText(planDetail);
            holder.image.setImageDrawable(context.getResources().getDrawable(R.drawable.profile_placeholder));
        }
        vi.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 200));
        return vi;

    }
    public static Bitmap loadContactPhoto(ContentResolver cr, long  id) {
        Uri uri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, id);
        InputStream input = ContactsContract.Contacts.openContactPhotoInputStream(cr, uri);
        if (input == null) {
            return null;
        }
        return BitmapFactory.decodeStream(input);
    }
}
