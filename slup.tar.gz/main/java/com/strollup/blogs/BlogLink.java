package com.strollup.blogs;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Display;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;
import com.strollup.utility.Constants;
import com.strollup.utility.WebViewController;

import in.strollup.android.BuildConfig;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class BlogLink extends AppCompatActivity {
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Intent blogIntent = getIntent();
		Bundle b = blogIntent.getExtras();
        Display display = getWindowManager().getDefaultDisplay();
        int width=display.getWidth();
        final String blogUrl = b.getString("url");
        final String title = b.getString("title");
        if (!BuildConfig.DEBUG) {
            GoogleAnalytics analytics = GoogleAnalytics.getInstance(this);
            Tracker tracker = analytics.newTracker(Constants.GOOGLE_ANALYTICS_URL);
            tracker.setScreenName("Blog - " + title);
            tracker.send(new HitBuilders.ScreenViewBuilder().build());
        }
		getSupportActionBar().hide();
        WebView webView=new WebViewController().launchWebView(getApplicationContext(), blogUrl);
        if(width == 320 || width == 360)
        {
            WebSettings webSettings = webView.getSettings();
            webSettings.setUseWideViewPort(true);
            webSettings.setLoadWithOverviewMode(true);
            webView.getSettings().setJavaScriptEnabled(true);
        }

        else if(width == 480)
        {
            WebSettings webSettings = webView.getSettings();
            webSettings.setUseWideViewPort(true);
            webView.setInitialScale(85);
            webView.getSettings().setJavaScriptEnabled(true);
        }
        else if(width == 540)
        {
            WebSettings webSettings = webView.getSettings();
            webSettings.setUseWideViewPort(true);
            webView.setInitialScale(90);
            webView.getSettings().setJavaScriptEnabled(true);
        }
        else if(width > 540)
        {
            webView.getSettings().setJavaScriptEnabled(true);
        }
        else
        {
            WebSettings webSettings = webView.getSettings();
            webSettings.setUseWideViewPort(true);
            webSettings.setLoadWithOverviewMode(true);
            webView.getSettings().setJavaScriptEnabled(true);
        }
        webView.loadUrl(blogUrl);
		setContentView(webView);
	}

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
