package com.strollup.blogs;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.koushikdutta.ion.Ion;
import com.strollup.utility.Constants;

import in.strollup.android.R;

public class BlogListingAdapter extends ArrayAdapter<BlogDto> {

    private final LayoutInflater inflater;
    private RelativeLayout layout;

    public BlogListingAdapter(Context context, int resource, BlogDto[] objects, GridView gridView) {
        super(context, resource, objects);
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.blog_list_single_item, null);
        }

        BlogDto blog = getItem(position);

        TextView blogTitleTv = (TextView) convertView.findViewById(R.id.blog_title);
        ImageView blogImage = (ImageView) convertView.findViewById(R.id.blog_activity_image);
        blogImage.setScaleType(ScaleType.FIT_XY);
        layout = (RelativeLayout) convertView.findViewById(R.id.blog_image);
        Ion.with(blogImage)
                .placeholder(R.drawable.preloader)
                .error(R.drawable.error_image)
                .load(blog.getImage());
        Typeface font = Typeface.createFromAsset(getContext().getAssets(), Constants.BASE_FONT);
        blogTitleTv.setTypeface(font);
        blogTitleTv.setText(blog.getName());
        return convertView;
    }
}
