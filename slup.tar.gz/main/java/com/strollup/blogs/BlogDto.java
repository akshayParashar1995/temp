package com.strollup.blogs;

public class BlogDto {
	private int id;
	private String blogURL;
	private boolean isActive;
	private String name;
	private String image;
	private float rating;

	public BlogDto(int id, String blogURL, boolean isActive, String name, String image, float rating) {
		this.id = id;
		this.blogURL = blogURL;
		this.isActive = isActive;
		this.name = name;
		this.image = image;
		this.rating = rating;

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String blogURL() {
		return blogURL;
	}

	public void setblogURL(String blogURL) {
		this.blogURL = blogURL;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

}
