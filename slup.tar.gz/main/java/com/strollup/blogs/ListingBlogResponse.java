package com.strollup.blogs;

import java.util.List;


public class ListingBlogResponse {
	private List<BlogDto> blogStrings;

	public List<BlogDto> getBlogStrings() {
		return blogStrings;
	}

	public void setLocationStrings(List<BlogDto> blogStrings) {
		this.blogStrings = blogStrings;
	}
}
