package com.strollup.blogs;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;

import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.google.gson.Gson;
import com.strollup.main.AppController;
import com.strollup.request.BlogTypeRequest;
import com.strollup.utility.Constants;
import com.strollup.utility.GsonRequest;
import com.strollup.utility.Utils;

import java.util.List;

import in.strollup.android.R;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class BlogActivity extends AppCompatActivity {
	private List<BlogDto> blogStrings;
	private GsonRequest<ListingBlogResponse> myReq;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.listing_blog);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);

		BlogTypeRequest blogTypeRequest = new BlogTypeRequest(getApplicationContext());

		String url = Constants.BASE_SERVER_URL + "getBlogs?blogRequestString=" + new Gson().toJson(blogTypeRequest);

		loadContent(url);
	}

	private void loadContent(String url) {
		myReq = new GsonRequest<ListingBlogResponse>(Request.Method.GET, url, ListingBlogResponse.class,
				createMyReqSuccessListener(), createMyReqErrorListener());
		AppController.getInstance().getRequestQueue().add(myReq);
	}

	private Response.Listener<ListingBlogResponse> createMyReqSuccessListener() {
		return new Response.Listener<ListingBlogResponse>() {
			@Override
			public void onResponse(ListingBlogResponse listingBlogResponse) {
				try {
					final BlogDto[] arr = new BlogDto[listingBlogResponse.getBlogStrings().size()];
					blogStrings = listingBlogResponse.getBlogStrings();
					for (int i = 0; i < blogStrings.size(); i++) {
						arr[i] = new BlogDto(blogStrings.get(i).getId(), blogStrings.get(i).blogURL(), blogStrings.get(
								i).getIsActive(), blogStrings.get(i).getName(), blogStrings.get(i).getImage(),
								blogStrings.get(i).getRating());
					}
					GridView gv = (GridView) findViewById((int) R.id.blog_listing_grid_view);
					BlogListingAdapter adapter = new BlogListingAdapter(getApplicationContext(), 0, arr, gv);
					gv.setAdapter(adapter);

					gv.setOnItemClickListener(new OnItemClickListener() {
						@Override
						public void onItemClick(AdapterView<?> gv, View arg1, int position, long arg3) {
							Intent i = new Intent();
							i.setClass(getApplicationContext(), BlogLink.class);
							i.putExtra("url", arr[position].blogURL());
							i.putExtra("title", arr[position].getName());

							startActivity(i);
						}
					});
				} catch (Exception e) {
					e.printStackTrace();
				}
			};
		};
	}

	private Response.ErrorListener createMyReqErrorListener() {
		return new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {
				if (error instanceof NoConnectionError || error instanceof TimeoutError)
					Utils.noNetworkMessage(BlogActivity.this, myReq);
			}
		};
	}

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}