package com.strollup.place;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Cache;
import com.android.volley.Cache.Entry;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;
import com.google.gson.Gson;
import com.strollup.filter.AllFilterString;
import com.strollup.main.AppController;
import com.strollup.model.location.LocationDto;
import com.strollup.personal.PersonalMainActivity;
import com.strollup.request.ListingSearchRequest;
import com.strollup.utility.Constants;
import com.strollup.utility.EndlessScrollListener;
import com.strollup.utility.GsonRequest;
import com.strollup.utility.Utils;

import java.util.ArrayList;
import java.util.List;

import in.strollup.android.BuildConfig;
import in.strollup.android.R;

@SuppressLint("ValidFragment")
public class PlaceListingFragment extends Fragment {

    private View view;
    private int activityTypeId;
    private String searchString;
    private Button personalize;
    private List<LocationDto> locationStrings;
    private ArrayList<LocationDto> places;

    private static final String TAG = PlaceListingFragment.class.getSimpleName();
    private PlaceListingAdapter adapter;
    private ProgressBar mProgressBar;
    private int totalItemsCount = 0;
    private int totalPageCount = 0;
    private boolean isClicked = false;
    private AllFilterString allFilterString = null;

    public PlaceListingFragment(int activityTypeId, AllFilterString allFilterString, String searchString) {
        this.allFilterString = allFilterString;
        this.activityTypeId = activityTypeId;
        this.searchString = searchString;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate((Integer) R.layout.listing_place, null);
        personalize = (Button) view.findViewById(R.id.btbt);
        isClicked = false;
        personalize.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent i = new Intent(getActivity(), PersonalMainActivity.class);
                getActivity().startActivity(i);
                getActivity().finish();
            }
        });
        placeLoadContent();

        return view;
    }

    private void placeLoadContent() {
        ListingSearchRequest listingSearchRequest = new ListingSearchRequest(getActivity().getApplicationContext());
        listingSearchRequest.addActivityTypeIds(activityTypeId);
        listingSearchRequest.setPageNo(1);
        listingSearchRequest.setSearchString(searchString);
        mProgressBar = (ProgressBar) view.findViewById(R.id.progressBar_place);

        String url = Constants.BASE_SERVER_URL + "fetchListingDataMobile?listingSearchRequestString="
                + new Gson().toJson(listingSearchRequest) + "&allFilterString=" + new Gson().toJson(allFilterString);

        url = Utils.urlParser(url);

        loadContent(url);
        final GridView gv = (GridView) view.findViewById((int) R.id.place_listing_grid_view);
        final float SCREEN_DENSITY = getResources().getDisplayMetrics().density;
        gv.setPadding(0, (int) (50 * SCREEN_DENSITY), 0, 0);

        gv.setOnScrollListener(new EndlessScrollListener() {
            @Override
            public void onLoadMore(int page, int totalItemsCount) {
                customLoadMoreDataFromApi(page);

            }

            @Override
            public void onScrollStateChanged(AbsListView view1, int scrollState) {
                if (view1.getCount() == view1.getLastVisiblePosition() + 1 && view1.getCount() != totalItemsCount) {
                    gv.setPadding(0, 10, 0, (int) (50 * SCREEN_DENSITY));
                    mProgressBar.setVisibility(View.VISIBLE);
                } else {
                    gv.setPadding(0, (int) (50 * SCREEN_DENSITY), 0, 10);

                    mProgressBar.setVisibility(View.INVISIBLE);
                }
            }
        });
    }

    private void loadContent(String url) {
        Cache cache = AppController.getInstance().getRequestQueue().getCache();
        Entry entry = cache.get(url);
        if (entry != null && entry.serverDate + Constants.CACHE_EXPIRY_TIME > System.currentTimeMillis() && activityTypeId != 12) {
            try {
                mProgressBar.setVisibility(View.VISIBLE);
                String data = new String(entry.data, "UTF-8");
                ListingPlaceResponse listingPlaceResponse = (ListingPlaceResponse) Utils.getCachedResponse(
                        ListingPlaceResponse.class, data);
                onSuccess(listingPlaceResponse);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            AppController.getInstance().getRequestQueue().getCache().invalidate(url, true);
            mProgressBar.setVisibility(View.VISIBLE);
            GsonRequest<ListingPlaceResponse> myReq = new GsonRequest<ListingPlaceResponse>(Request.Method.GET, url,
                    ListingPlaceResponse.class, createMyReqSuccessListener(), createMyReqErrorListener());
            AppController.getInstance().addToRequestQueue(myReq, TAG);
        }
    }

    private Response.Listener<ListingPlaceResponse> createMyReqSuccessListener() {
        return new Response.Listener<ListingPlaceResponse>() {
            @Override
            public void onResponse(ListingPlaceResponse listingPlaceResponse) {
                onSuccess(listingPlaceResponse);
            }

            ;
        };
    }

    private void onSuccess(ListingPlaceResponse listingPlaceResponse) {
        try {
            places = new ArrayList<LocationDto>();
            locationStrings = listingPlaceResponse.getLocationStrings();
            totalItemsCount = listingPlaceResponse.getLocationCountStrings();
            totalPageCount = (int) Math.ceil(totalItemsCount / 10.0);
            places.addAll(locationStrings);
            mProgressBar.setVisibility(View.INVISIBLE);
            GridView gv = (GridView) view.findViewById((int) R.id.place_listing_grid_view);
            TextView tv = (TextView) view.findViewById((int) R.id.noImages);
            if (places.size() == 0) {
                gv.setVisibility(View.INVISIBLE);
                tv.setText(Constants.NO_PLACES_FOUND);
                tv.setVisibility(View.VISIBLE);
                if (activityTypeId == 12) {
                    personalize.setVisibility(View.VISIBLE);            ///////////////
                }
            }

            adapter = new PlaceListingAdapter(getActivity(), 0, places, gv);
            gv.setAdapter(adapter);
            adapter.notifyDataSetChanged();
            gv.setOnItemClickListener(new OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> gv, View arg1, int position, long arg3) {

                    gv.setOnItemClickListener(null);
                    int resId = places.get(position).getId();
                    String name = places.get(position).getName();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void customLoadMoreDataFromApi(int pageNo) {
        if (pageNo <= totalPageCount) {
            ListingSearchRequest listingSearchRequest = new ListingSearchRequest(getActivity().getApplicationContext());
            listingSearchRequest.addActivityTypeIds(activityTypeId);
            listingSearchRequest.setPageNo(pageNo);
            listingSearchRequest.setSearchString(searchString);

            String url = Constants.BASE_SERVER_URL + "fetchListingDataMobile?listingSearchRequestString="
                    + new Gson().toJson(listingSearchRequest) + "&allFilterString="
                    + new Gson().toJson(allFilterString);
            url = Utils.urlParser(url);
            loadContentForScroll(url);
        } else {
            GridView gv = (GridView) view.findViewById((int) R.id.place_listing_grid_view);
            gv.setPadding(0, 10, 0, 10);
            mProgressBar.setVisibility(View.INVISIBLE);
        }
    }

    private void loadContentForScroll(String url) {
        Cache cache = AppController.getInstance().getRequestQueue().getCache();
        Entry entry = cache.get(url);
        if (entry != null && entry.serverDate + Constants.CACHE_EXPIRY_TIME > System.currentTimeMillis() && activityTypeId != 12) {
            try {
                mProgressBar.setVisibility(View.VISIBLE);
                String data = new String(entry.data, "UTF-8");
                ListingPlaceResponse listingPlaceResponse = (ListingPlaceResponse) Utils.getCachedResponse(
                        ListingPlaceResponse.class, data);
                onSuccessScroll(listingPlaceResponse);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            AppController.getInstance().getRequestQueue().getCache().invalidate(url, true);
            mProgressBar.setVisibility(View.VISIBLE);
            GsonRequest<ListingPlaceResponse> myReq = new GsonRequest<ListingPlaceResponse>(Request.Method.GET, url,
                    ListingPlaceResponse.class, createMyReqSuccessListenerForScroll(), createMyReqErrorListener());
            AppController.getInstance().addToRequestQueue(myReq, TAG);
        }
    }

    private Response.Listener<ListingPlaceResponse> createMyReqSuccessListenerForScroll() {
        return new Response.Listener<ListingPlaceResponse>() {
            @Override
            public void onResponse(ListingPlaceResponse listingPlaceResponse) {
                onSuccessScroll(listingPlaceResponse);

            }

            ;
        };
    }

    private void onSuccessScroll(ListingPlaceResponse listingPlaceResponse) {
        try {
            locationStrings = listingPlaceResponse.getLocationStrings();
            places.addAll(locationStrings);
            adapter.notifyDataSetChanged();
            mProgressBar.setVisibility(View.INVISIBLE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Response.ErrorListener createMyReqErrorListener() {
        return new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Error Occured while calling backend", error.getCause());
                if (getActivity() != null) {
                    Toast.makeText(getActivity(), Constants.GENERAL_ERROR_MESSAGE, Toast.LENGTH_LONG).show();
                }
            }
        };
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!BuildConfig.DEBUG) {
            GoogleAnalytics analytics = GoogleAnalytics.getInstance(getActivity());
            Tracker tracker = analytics.newTracker(Constants.GOOGLE_ANALYTICS_URL);
            tracker.setScreenName("Listing" + activityTypeId);
            tracker.send(new HitBuilders.ScreenViewBuilder().build());
        }
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
        GridView gridView = (GridView) view.findViewById(R.id.place_listing_grid_view);
        gridView.setClickable(true);
    }
}
