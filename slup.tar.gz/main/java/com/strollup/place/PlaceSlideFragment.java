package com.strollup.place;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.koushikdutta.ion.Ion;

import in.strollup.android.R;

/**
 * Created by DELL LAPTOP on 7/6/2015.
 */
public class PlaceSlideFragment extends Fragment {
    private String url;

    public PlaceSlideFragment(String url) {
        this.url = url;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ImageView imageView = new ImageView(getActivity().getApplicationContext());
        int padding = 1;
        imageView.setBackgroundColor(Color.parseColor("#000000"));
        imageView.setPadding(padding, padding, padding, padding);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 200);
        imageView.setLayoutParams(layoutParams);
        Ion.with(imageView)
                .placeholder(R.drawable.preloader)
                .error(R.drawable.error_image)
                .load(url);
        return imageView;
    }
}