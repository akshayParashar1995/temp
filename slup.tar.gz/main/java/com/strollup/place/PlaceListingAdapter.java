package com.strollup.place;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;
import com.koushikdutta.ion.Ion;
import com.strollup.filter.Region;
import com.strollup.model.location.LocationDto;
import com.strollup.plan.DisplayPlanMain;
import com.strollup.plan.DisplayPlanMainController;
import com.strollup.request.ActivityLocation;
import com.strollup.save.SaveLocationController;
import com.strollup.utility.Constants;
import com.strollup.utility.Utils;

import java.util.ArrayList;

import in.strollup.android.BuildConfig;
import in.strollup.android.R;

public class PlaceListingAdapter extends ArrayAdapter<LocationDto> {

    private Context context;

    private GridView gridView;
    private final LayoutInflater inflater;
    Intent sendIntent;
    private SaveLocationController saveController;
    private Button showPlansButton;
    private LinearLayout distanceLayout;

    public PlaceListingAdapter(Context context, int resource, ArrayList<LocationDto> objects, GridView gridView) {
        super(context, resource, objects);
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.gridView = gridView;
        this.context = context;

    }

    @SuppressLint("ViewHolder")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.place_list_single_item, null);
        }

        final LocationDto locationDto = getItem(position);
        LinearLayout placeLayout = (LinearLayout) convertView.findViewById(R.id.place_layout);
        TextView placeAreaTv = (TextView) convertView.findViewById(R.id.place_area);
        TextView placeCostTv = (TextView) convertView.findViewById(R.id.place_cost);
        TextView placeNameTv = (TextView) convertView.findViewById(R.id.place_name);
        distanceLayout= (LinearLayout) convertView.findViewById(R.id.distance_layout);
        TextView distanceTextView = (TextView) convertView.findViewById(R.id.disance_text);
        TextView placeSmallDescTv = (TextView) convertView.findViewById(R.id.place_small_desc);
        TextView placeRatingTv = (TextView) convertView.findViewById(R.id.place_rating);
        ImageView placeImage = (ImageView) convertView.findViewById(R.id.activity_image);
        RelativeLayout placeRelativeLayout = (RelativeLayout)convertView.findViewById(R.id.place_image);
        placeImage.setScaleType(ScaleType.FIT_XY);
        showPlansButton = (Button) convertView.findViewById(R.id.show_plans_button);
        saveController = new SaveLocationController();
        final Button saveButton = (Button) convertView.findViewById(R.id.save_button);
        Ion.with(placeImage)
                .placeholder(R.drawable.preloader)
                .error(R.drawable.error_image)
                .load(locationDto.getImage());
        if(!Utils.isGpsEnabled(context) || locationDto.getGroupId() == Constants.MOVIE_GROUP_ID){
            distanceLayout.setVisibility(View.GONE);
        }
        else{
            Region currentRegion=Utils.getNearByRegion(context);
            String distance=Utils.getDistanceFromLatAndLong(currentRegion.getLatitude(),locationDto.getLatitude()
                    ,currentRegion.getLongitude(),locationDto.getLongitude());
            distanceTextView.setText(distance);
        }
        placeAreaTv.setText(locationDto.getRegion());
        placeCostTv.setText(locationDto.getCostText());
        placeNameTv.setText(locationDto.getName());
        placeRatingTv.setText(locationDto.getRating());
        if (locationDto.getSmallDescription() != null) {
            placeSmallDescTv.setText(Html.fromHtml(locationDto.getSmallDescription()));
        } else if (locationDto.getGroupId() != Constants.MOVIE_GROUP_ID) {
            placeSmallDescTv.setText(locationDto.getTagsString());
        } else {
            placeSmallDescTv.setText("");
            distanceLayout.setVisibility(View.GONE);
        }
        setBookmarkButtonStatus(saveButton, locationDto.getActivityId(), locationDto.getId());

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ActivityLocation location = new ActivityLocation(locationDto.getId(), locationDto.getActivityId());
                if (!saveController.isThisLocationAlreadyPresent(location)) {
                    saveController.addLocationToListOfSavedLocations(locationDto, location, getContext());
                    if (!BuildConfig.DEBUG) {
                        GoogleAnalytics analytics = GoogleAnalytics.getInstance(context);
                        Tracker tracker = analytics.newTracker(Constants.GOOGLE_ANALYTICS_URL);
                        tracker.setScreenName("Listing Page");
                        tracker.send(new HitBuilders.EventBuilder().setCategory("UX").setAction("click")
                                .setLabel("bookmark").build());
                    }

                    saveButton.setText("Bookmarked");

                } else {
                    saveController.removeFromSavedLocations(locationDto, location, getContext());
                    saveButton.setText("Bookmark");
                }
            }
        });

        showPlansButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                ActivityLocation activityLocation = new ActivityLocation(locationDto.getId(), locationDto
                        .getActivityId());
                String url = DisplayPlanMainController.getPlansWithThisLocation(activityLocation, false, 0, null,
                        context);
                Intent i = new Intent(context, DisplayPlanMain.class);
                i.putExtra("url", url);
                context.startActivity(i);
            }
        });

        placeRelativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, PlaceDetailActivity.class);
                i.putExtra("activity_id", locationDto.getActivityId());
                i.putExtra("location_detail_id", locationDto.getId());
                i.putExtra("inApp", true);
                context.startActivity(i);

            }
        });

        // shareButton.setOnClickListener(new View.OnClickListener() {
        // @Override
        // public void onClick(View v) {
        // CharSequence options[] = new CharSequence[] { "Via Whatsapp",
        // "Via Facebook", "Via Gmail",
        // "More Options" };
        //
        // AlertDialog.Builder builder = new AlertDialog.Builder(context);
        // builder.setTitle("Share Place");
        // builder.setItems(options, new DialogInterface.OnClickListener() {
        // @Override
        // public void onClick(DialogInterface dialog, int which) {
        // // the user clicked on colors[which]
        // switch (which) {
        // case 0:
        // sendIntent = new Intent();
        // sendIntent.setAction(Intent.ACTION_SEND);
        // sendIntent.putExtra(Intent.EXTRA_TEXT, Constants.SHARE_US_TEXT);
        // sendIntent.setType("text/plain");
        // sendIntent.setPackage("com.whatsapp");
        // PackageManager packageManager = context.getPackageManager();
        // List<ResolveInfo> activities =
        // packageManager.queryIntentActivities(sendIntent, 0);
        // boolean isIntentSafe = activities.size() > 0;
        // if (isIntentSafe)
        // context.startActivity(sendIntent);
        // else
        // Toast.makeText(context, "Whatsapp not installed",
        // Toast.LENGTH_LONG).show();
        // break;
        // case 1:
        // sendIntent = new Intent(Intent.ACTION_SEND);
        // sendIntent.setType("text/plain");
        // sendIntent.putExtra(Intent.EXTRA_TEXT, Constants.SHARE_US_URL);
        // sendIntent.setPackage("com.facebook.katana");
        //
        // packageManager = context.getPackageManager();
        // activities = packageManager.queryIntentActivities(sendIntent, 0);
        // isIntentSafe = activities.size() > 0;
        // if (isIntentSafe)
        // // startActivity(sendIntent);
        // context.startActivity(sendIntent);
        // else
        // Toast.makeText(context, "Facebook not installed",
        // Toast.LENGTH_LONG).show();
        // break;
        // case 2:
        // sendIntent = new Intent(Intent.ACTION_VIEW);
        // sendIntent.setType("plain/text");
        // // sendIntent.setData(Uri.parse("test@gmail.com"));
        // sendIntent.setClassName("com.google.android.gm",
        // "com.google.android.gm.ComposeActivityGmail");
        // // sendIntent.putExtra(Intent.EXTRA_EMAIL, new
        // // String[] { "test@gmail.com" });
        // sendIntent.putExtra(Intent.EXTRA_SUBJECT, "StrollUp");
        // sendIntent.putExtra(Intent.EXTRA_TEXT, Constants.SHARE_US_TEXT);
        //
        // packageManager = context.getPackageManager();
        // activities = packageManager.queryIntentActivities(sendIntent, 0);
        // isIntentSafe = activities.size() > 0;
        // if (isIntentSafe)
        // // startActivity(sendIntent);
        // context.startActivity(sendIntent);
        // else
        // Toast.makeText(context, "Gmail not installed",
        // Toast.LENGTH_LONG).show();
        // break;
        // case 3:
        // sendIntent = new Intent();
        // sendIntent.setAction(Intent.ACTION_SEND);
        // sendIntent.putExtra(Intent.EXTRA_TEXT, Constants.SHARE_US_TEXT);
        // sendIntent.setType("text/plain");
        // context.startActivity(sendIntent);
        // }
        // }
        // });
        // builder.show();
        // }
        // });
        return convertView;
    }

    private void setBookmarkButtonStatus(Button saveButton, int activityId, int locationDetailId) {
        ActivityLocation location = new ActivityLocation(locationDetailId, activityId);
        if (saveController.isThisLocationAlreadyPresent(location)) {
            saveButton.setText("Bookmarked");
        } else {
            saveButton.setText("Bookmark");
        }
    }
}
