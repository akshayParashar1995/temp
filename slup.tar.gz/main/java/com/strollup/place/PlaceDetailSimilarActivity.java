package com.strollup.place;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.GridView;

import com.strollup.model.location.LocationDto;

import java.util.ArrayList;
import java.util.List;

import in.strollup.android.R;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class PlaceDetailSimilarActivity extends AppCompatActivity{
	List<LocationDto> similarLocations;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.listing_place);
		
		ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
		actionBar.setTitle("Similar to "+ PlaceDetailActivity.locationData.getLocation().getName());
	//	actionBar.setDisplayHomeAsUpEnabled(true);
		similarLocations = PlaceDetailActivity.locationData.getSimilarLocations();
		final GridView gv = (GridView)findViewById((int) R.id.place_listing_grid_view);
		ArrayList<LocationDto> places = new ArrayList<LocationDto>();
		places.addAll(similarLocations);
		PlaceListingAdapter adapter = new PlaceListingAdapter(this, 0, places, gv);
		gv.setAdapter(adapter);
	}

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
