package com.strollup.place;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by DELL LAPTOP on 7/8/2015.
 */
public class PlaceImageObject implements Serializable {
    private List<String> imageUrls= new ArrayList<String>();

    public List<String> getImageUrls() {
        return imageUrls;
    }

    public void setImageUrls(List<String> imageUrls) {
        this.imageUrls = imageUrls;
    }
}
