package com.strollup.place;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Cache;
import com.android.volley.Cache.Entry;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.github.ksoichiro.android.observablescrollview.ObservableScrollView;
import com.github.ksoichiro.android.observablescrollview.ObservableScrollViewCallbacks;
import com.github.ksoichiro.android.observablescrollview.ScrollState;
import com.github.ksoichiro.android.observablescrollview.ScrollUtils;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;
import com.google.gson.Gson;
import com.koushikdutta.ion.Ion;
import com.nineoldandroids.view.ViewHelper;
import com.strollup.filter.Region;
import com.strollup.main.AppController;
import com.strollup.main.NavigationAndTabs;
import com.strollup.model.location.DetailData;
import com.strollup.model.location.EventDto;
import com.strollup.model.location.LocationData;
import com.strollup.model.location.LocationDataResponse;
import com.strollup.model.location.LocationDto;
import com.strollup.model.location.PlaceDetailRequest;
import com.strollup.model.location.ShowDetail;
import com.strollup.model.location.ShowDetailDto;
import com.strollup.plan.DisplayPlanMain;
import com.strollup.plan.DisplayPlanMainController;
import com.strollup.request.ActivityLocation;
import com.strollup.request.TrendingDataRequest;
import com.strollup.save.SaveLocationController;
import com.strollup.trending.TrendingDataResponse;
import com.strollup.utility.Constants;
import com.strollup.utility.Globals;
import com.strollup.utility.GoogleMapsUtility;
import com.strollup.utility.GsonRequest;
import com.strollup.utility.Utils;

import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import in.strollup.android.BuildConfig;
import in.strollup.android.R;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class PlaceDetailActivity extends AppCompatActivity implements OnClickListener, ObservableScrollViewCallbacks, View.OnClickListener {

    private static final float MAX_TEXT_SCALE_DELTA = 0.3f;
    private View mImageView;
    private View mOverlayView;
    private ObservableScrollView mScrollView;
    private TextView mTitleView;
    private View customView;

    private TextView timingsHeading;

    private int mActionBarSize;
    private int mFlexibleSpaceShowFabOffset;
    private int mFlexibleSpaceImageHeight;

    private TextView shareButton;
    private TextView backButton;


    private int activityId;
    private RelativeLayout relativeLayout;
    private int locationDetailId;
    private ActivityLocation activityLocation;
    private boolean inApp;
    private String shareUrl;
    private ImageView placeImage;
    private TextView placeName;
    private TextView smallDescription;
    private TextView description;
    private TextView address;
    private TextView time;
    private TextView cost;
    private TextView highlights;
    private TextView address_head;
    private TextView rating;
    private View gradientOverlay;
    private TextView time_head;
    private TextView cost_head;
    private TextView extrasTextView;
    private TextView distance_text;
    private boolean isCallable = false;
    private LinearLayout layout;
    private LinearLayout timingLayout;

    private LinearLayout whatsHappeningLayout;
    private RelativeLayout smallDescriptionLayout;
    private RelativeLayout descriptionLayout;
    private RelativeLayout highlightsLayout;
    private RelativeLayout addressLayout;
    private ProgressBar progressBar;
    private TextView callButton;
    private Button bookmark;
    private Button similarPlaces;
    private Button nearPlaces;
    private Button directions;
    private Button showPlans;
    public static LocationData locationData;
    private Context context;
    private String longitude;
    private Menu menu;
    private String latitude;
    private LocationDto locationDetails;
    private String called_by = "none";
    private String contact = null;
    private LinearLayout extrasLayout;
    private RelativeLayout actionBarButttons;
    // private RelativeLayout tutLayout;
    GsonRequest<LocationDataResponse> myReq;

    private static final String TAG = PlaceDetailActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = PlaceDetailActivity.this;
        setContentView(R.layout.place_detail);
        getSupportActionBar().hide();

        shareButton = (TextView) findViewById(R.id.share_button);
        TextView shareButtonInner = (TextView) findViewById(R.id.share_button_inner);
        shareButton.setOnClickListener(this);
        shareButtonInner.setOnClickListener(this);

        backButton = (TextView) findViewById(R.id.back_button);
        TextView backButtonInner = (TextView) findViewById(R.id.back_button_inner);
        backButton.setOnClickListener(this);
        backButtonInner.setOnClickListener(this);

        mFlexibleSpaceImageHeight = getResources().getDimensionPixelSize(R.dimen.flexible_space_image_height);
        mFlexibleSpaceShowFabOffset = getResources().getDimensionPixelSize(R.dimen.flexible_space_show_fab_offset);
        mActionBarSize = getActionBarSize();
        // tutLayout = (RelativeLayout) findViewById(R.id.tut_layout);
        mImageView = findViewById(R.id.image);
        mOverlayView = findViewById(R.id.overlay);
        mScrollView = (ObservableScrollView) findViewById(R.id.scroll);
        mScrollView.setScrollViewCallbacks(this);

        timingsHeading = (TextView) findViewById(R.id.timings_heading);


        ScrollUtils.addOnGlobalLayoutListener(mScrollView, new Runnable() {
            @Override
            public void run() {
                mScrollView.scrollTo(0, 5);
            }
        });
        placeImage = (ImageView) findViewById(R.id.image);

        customView = (View) findViewById(R.id.custom_view);
        relativeLayout = (RelativeLayout) findViewById(R.id.relative_layout);
        actionBarButttons = (RelativeLayout) findViewById(R.id.action_bar_buttons);
        callButton = (TextView) findViewById(R.id.call_button);
        placeName = (TextView) findViewById(R.id.title);
        mTitleView = (TextView) findViewById(R.id.title);
        smallDescription = (TextView) findViewById(R.id.small_description_text);
        description = (TextView) findViewById(R.id.description_text);
        address = (TextView) findViewById(R.id.address_text);
        time = (TextView) findViewById(R.id.time_text);
        cost = (TextView) findViewById(R.id.cost_text);
        address_head = (TextView) findViewById(R.id.address);
        rating = (TextView) findViewById(R.id.place_rating3);
        gradientOverlay = (View) findViewById(R.id.image_gradient_overlay);
        extrasTextView = (TextView) findViewById(R.id.extras);
        time_head = (TextView) findViewById(R.id.time);
        cost_head = (TextView) findViewById(R.id.cost);
        highlights = (TextView) findViewById(R.id.highlight_text);
        similarPlaces = (Button) findViewById(R.id.similar_button);
        nearPlaces = (Button) findViewById(R.id.nearby_button);
        bookmark = (Button) findViewById(R.id.bookmark_button);
        distance_text = (TextView) findViewById(R.id.address_text_distance);
        layout = (LinearLayout) findViewById(R.id.main_content_layout);
        progressBar = (ProgressBar) findViewById(R.id.progressBar_place_detail);
        directions = (Button) findViewById(R.id.directions_button);
        showPlans = (Button) findViewById(R.id.show_plans_button);
        smallDescriptionLayout = (RelativeLayout) findViewById(R.id.small_description_layout);
        descriptionLayout = (RelativeLayout) findViewById(R.id.description_layout);
        highlightsLayout = (RelativeLayout) findViewById(R.id.highlights_layout);
        addressLayout = (RelativeLayout) findViewById(R.id.address_layout);
        extrasLayout = (LinearLayout) findViewById(R.id.extras_layout);
        timingLayout = (LinearLayout) findViewById(R.id.show_timings);

        whatsHappeningLayout = (LinearLayout) findViewById(R.id.whats_happening_layout);
        layout.setVisibility(View.INVISIBLE);

        Bundle extras = getIntent().getExtras();
        if (extras.getString("called_by") != null) {
            called_by = extras.getString("called_by");
            if (extras.getString("called_by").equals("trending")) {
                int tableNameId = extras.getInt("table_name_id");
                int tableRowId = extras.getInt("table_row_id");
                TrendingDataRequest trendingDataRequest = new TrendingDataRequest(context, tableNameId, tableRowId);
                String TrendingUrl = Constants.BASE_SERVER_URL + "getMobileTrendingData?trendingDataRequestString="
                        + new Gson().toJson(trendingDataRequest);
                loadTrendingContent(TrendingUrl);
            }
        } else {
            activityId = extras.getInt("activity_id");
            locationDetailId = extras.getInt("location_detail_id");
            activityLocation = new ActivityLocation(locationDetailId, activityId);
            inApp = extras.getBoolean("inApp");
            PlaceDetailRequest placeDetailRequest = new PlaceDetailRequest(this);
            placeDetailRequest.setActivityLocation(activityLocation);
            String url = Constants.BASE_SERVER_URL + "fetchLocationDataMobile?activityLocationRequestString="
                    + new Gson().toJson(placeDetailRequest);
            loadPlaceContent(url);
        }

        similarPlaces.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(PlaceDetailActivity.this, PlaceDetailSimilarActivity.class);
                startActivity(i);
            }
        });

        customView.setOnClickListener(this);

        nearPlaces.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(PlaceDetailActivity.this, PlaceDetailNearbyActivity.class);
                startActivity(i);
            }
        });


        // tutLayout.setOnClickListener(new View.OnClickListener() {
        //
        // @Override
        // public void onClick(View v) {
        // // TODO Auto-generated method stub
        // tutLayout.setVisibility(View.GONE);
        // AppPreferences.setIsThisPageDisplayedFirst(context,
        // Constants.PLACE_DETAIL_ACTIVITY_NO);
        // }
        // });
        bookmark.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                SaveLocationController saveController = new SaveLocationController();
                if (!saveController.isThisLocationAlreadyPresent(activityLocation)) {
                    if(!BuildConfig.DEBUG) {
                        GoogleAnalytics analytics = GoogleAnalytics.getInstance(getBaseContext());
                        Tracker tracker = analytics.newTracker(Constants.GOOGLE_ANALYTICS_URL);
                        tracker.setScreenName("Place Page - " + locationDetails.getName() + locationDetailId + "-" + activityId);
                        tracker.send(new HitBuilders.EventBuilder().setCategory("UX").setAction("click")
                                .setLabel("bookmark").build());
                    }
                    saveController.addLocationToListOfSavedLocations(locationDetails, activityLocation,
                            getApplicationContext());
                    bookmark.setText("Bookmarked");

                } else {
                    saveController.removeFromSavedLocations(locationDetails, activityLocation, getApplicationContext());
                    bookmark.setText("Bookmark");
                }
            }
        });

        directions.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PlaceDetailActivity.this, GoogleMapsUtility.class);
                intent.putExtra("latitude", latitude);
                intent.putExtra("longitude", longitude);
                startActivity(intent);
            }
        });
        showPlans.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String url = DisplayPlanMainController.getPlansWithThisLocation(activityLocation, false, 0, null,
                        getApplicationContext());
                Intent i = new Intent(PlaceDetailActivity.this, DisplayPlanMain.class);
                i.putExtra("url", url);
                startActivity(i);
            }
        });

        actionBarButttons.bringToFront();
    }


    protected int getActionBarSize() {
        TypedValue typedValue = new TypedValue();
        int[] textSizeAttr = new int[]{R.attr.actionBarSize};
        int indexOfAttrTextSize = 0;
        TypedArray a = obtainStyledAttributes(typedValue.data, textSizeAttr);
        int actionBarSize = a.getDimensionPixelSize(indexOfAttrTextSize, -1);
        a.recycle();
        return actionBarSize;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if (inApp || called_by.equals("trending"))
                    this.finish();
                else {
                    Intent i = new Intent(PlaceDetailActivity.this, NavigationAndTabs.class);
                    startActivity(i);
                    this.finish();

                }
                break;
            case R.id.share:
                final Intent sendIntent;
                CharSequence options[] = new CharSequence[]{"Via Whatsapp", "Via Facebook", "Via Gmail", "More Options"};
                AlertDialog.Builder builder = new AlertDialog.Builder(PlaceDetailActivity.this);
                builder.setTitle("Share Place");
                builder.setItems(options, this);
                builder.show();
                break;


            case R.id.call:
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + contact));
                startActivity(intent);
                break;
        }
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.place_detail, menu);
        this.menu = menu;

        return true;
    }

    private void loadTrendingContent(String url) {
        Cache cache = AppController.getInstance().getRequestQueue().getCache();
        Entry entry = cache.get(url);
        if (entry != null && entry.serverDate + Constants.CACHE_EXPIRY_TIME > System.currentTimeMillis()) {
            try {
                String data = new String(entry.data, "UTF-8");
                TrendingDataResponse TrendingDataResponse = (TrendingDataResponse) Utils.getCachedResponse(
                        TrendingDataResponse.class, data);
                onSuccess(TrendingDataResponse.getTrendingDataResponseString());
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            AppController.getInstance().getRequestQueue().getCache().invalidate(url, true);
            AppController.getInstance().getRequestQueue().getCache().invalidate(url, true);
            progressBar.setVisibility(View.VISIBLE);
            GsonRequest<TrendingDataResponse> ResponseRequest = new GsonRequest<TrendingDataResponse>(
                    Request.Method.GET, url, TrendingDataResponse.class, createMyTrendingReqSuccessListener(),
                    createMyReqErrorListener());
            AppController.getInstance().addToRequestQueue(ResponseRequest);
        }
    }

    private void loadPlaceContent(String url) {
        Cache cache = AppController.getInstance().getRequestQueue().getCache();
        Entry entry = cache.get(url);
        if (entry != null && entry.serverDate + Constants.CACHE_EXPIRY_TIME > System.currentTimeMillis()) {
            try {
                String data = new String(entry.data, "UTF-8");
                LocationDataResponse locationDataResponse = (LocationDataResponse) Utils.getCachedResponse(
                        LocationDataResponse.class, data);
                onSuccess(locationDataResponse.getLocationDataResponseString());
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            AppController.getInstance().getRequestQueue().getCache().invalidate(url, true);
            progressBar.setVisibility(View.VISIBLE);
            myReq = new GsonRequest<LocationDataResponse>(Request.Method.GET, url, LocationDataResponse.class,
                    createMyReqSuccessListener(), createMyReqErrorListener());
            AppController.getInstance().addToRequestQueue(myReq, TAG);
        }
    }

    private Response.Listener<LocationDataResponse> createMyReqSuccessListener() {
        return new Response.Listener<LocationDataResponse>() {
            @Override
            public void onResponse(LocationDataResponse locattionDataResponse) {
                onSuccess(locattionDataResponse.getLocationDataResponseString());
            }

            ;
        };
    }

    private Response.ErrorListener createMyReqErrorListener() {
        return new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Error Occured while calling backend", error.getCause());
                if (error instanceof NoConnectionError || error instanceof TimeoutError)
                    Utils.noNetworkMessage(PlaceDetailActivity.this, myReq);

            }
        };

    }

    private Response.Listener<TrendingDataResponse> createMyTrendingReqSuccessListener() {
        return new Response.Listener<TrendingDataResponse>() {
            @Override
            public void onResponse(TrendingDataResponse trendingDataResponse) {
                LocationData response = trendingDataResponse.getTrendingDataResponseString();
                onSuccess(response);
            }
        };
    }

    private void onSuccess(LocationData location) {
        // if (AppPreferences.getIsThisPageDisplayedFirst(context,
        // Constants.PLACE_DETAIL_ACTIVITY_NO)) {
        // tutLayout.setVisibility(View.VISIBLE);
        // }
        Typeface font = Typeface.createFromAsset(context.getAssets(), Constants.BASE_FONT);
        layout.setVisibility(View.VISIBLE);
        progressBar.setVisibility(View.GONE);

        locationData = location;
        Map<String, List<ShowDetailDto>> showTimingInfo;
        locationDetails = locationData.getLocation();

        locationDetailId = locationDetails.getId();
        activityId = locationDetails.getActivityId();
        activityLocation = new ActivityLocation(locationDetailId, activityId);
        if(!BuildConfig.DEBUG) {
            GoogleAnalytics analytics = GoogleAnalytics.getInstance(this);
            Tracker tracker = analytics.newTracker(Constants.GOOGLE_ANALYTICS_URL);
            tracker.setScreenName("Place Page - " + locationDetails.getName() + locationDetailId + "-" + activityId);
            tracker.send(new HitBuilders.ScreenViewBuilder().build());
        }
        shareUrl = Utils.generateShareUrl(PlaceDetailActivity.this, locationDetails.getGroupId(),
                locationDetails.getRegion(), locationDetails.getName(), locationDetails.getId(),
                locationDetails.getActivityId());


        Ion.with(placeImage)
                .placeholder(R.drawable.preloader)
                .error(R.drawable.error_image)
                .load(locationDetails.getImage());
        placeName.setText(locationDetails.getName());

        List<EventDto> events = locationDetails.getEvents();


        if (events != null && events.size() != 0 && activityId == -1) {
            whatsHappeningLayout.setVisibility(View.VISIBLE);
            LayoutParams textParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
            LayoutParams layoutParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
            layoutParams.setMargins(5, 30, 5, 30);
            for (final EventDto event : events) {
                LinearLayout oneEventLayout = new LinearLayout(this);
                oneEventLayout.setOrientation(LinearLayout.VERTICAL);
                LinearLayout nameAndTypeLayout = new LinearLayout(this);
                nameAndTypeLayout.setOrientation(LinearLayout.HORIZONTAL);
                nameAndTypeLayout.setWeightSum(1.0f);
                TextView name = new TextView(this);
                name.setTypeface(font, 0);
                name.setClickable(true);
                name.setTextSize(16);
                name.setMaxLines(2);
                name.setEllipsize(TextUtils.TruncateAt.END);
                name.setLayoutParams(new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1.0f));
                String nameText = event.getEventType() + " - <font color='#05c5cf'>" + event.getName() + "</font>";
                name.setText(Html.fromHtml(nameText));
                name.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent place = new Intent(PlaceDetailActivity.this, PlaceDetailActivity.class);
                        place.putExtra("activity_id", event.getId());
                        place.putExtra("location_detail_id", -1);
                        place.putExtra("inApp", true);
                        startActivity(place);

                    }
                });
                nameAndTypeLayout.addView(name);
                oneEventLayout.addView(nameAndTypeLayout, textParams);


                TextView dateAndTime = new TextView(this);
                dateAndTime.setTypeface(font, 0);
                dateAndTime.setTextSize(14);
                dateAndTime.setText(Utils.getDateString(event.getDate()) + " @ " + event.getTime());
                oneEventLayout.addView(dateAndTime, textParams);

                TextView costText = new TextView(this);
                costText.setTypeface(font, 0);
                costText.setTextSize(14);

                if (event.getCost().getValue() == 0) {
                    costText.setText(event.getCost().getText());
                } else if (event.getCost().getValue() != -1) {
                    costText.setText(event.getCost().getText() + " per head");
                } else {
                    costText.setText("");
                }
                oneEventLayout.addView(costText, textParams);
                whatsHappeningLayout.addView(oneEventLayout, layoutParams);
            }
        }


        if (locationDetails.getContact() != null) {
            TextView callButtonInner = (TextView) findViewById(R.id.call_button_inner);
            callButtonInner.setVisibility(View.VISIBLE);
            callButton.setVisibility(View.VISIBLE);
            callButton.setOnClickListener(this);
            callButtonInner.setOnClickListener(this);
            contact = locationDetails.getContact();
        }
        if (!StringUtils.isEmpty(locationDetails.getSmallDescription())) {
            smallDescription.setText(Html.fromHtml(locationDetails.getSmallDescription()));
            smallDescription.setMovementMethod(LinkMovementMethod.getInstance());
        } else {
            smallDescriptionLayout.setVisibility(View.GONE);
        }
        if (!StringUtils.isEmpty(locationDetails.getDescription())) {
            description.setText(Html.fromHtml(locationDetails.getDescription()));
            description.setMovementMethod(LinkMovementMethod.getInstance());
        } else {
            descriptionLayout.setVisibility(View.GONE);
        }
        if (locationDetails.getDetailData().size() == 0) {
            extrasLayout.setVisibility(View.GONE);
            extrasTextView.setVisibility(View.GONE);
        } else {
            for (DetailData detailData : locationDetails.getDetailData()) {
                LinearLayout singleExtraLayout = new LinearLayout(this);
                singleExtraLayout.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
                params.setMargins(0, 10, 0, 0);
                singleExtraLayout.setLayoutParams(params);

                TextView keyView = new TextView(this);
                keyView.setTypeface(font, 0);
                LayoutParams keytextViewparams = new LayoutParams(0, LayoutParams.WRAP_CONTENT);
                keytextViewparams.weight = 3;
                keyView.setLayoutParams(keytextViewparams);
                float SCREEN_DENSITY = getResources().getDisplayMetrics().density;
                keyView.setPadding((int) (5 * SCREEN_DENSITY), 0, (int) (5 * SCREEN_DENSITY), 0);
                keyView.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                keyView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
                keyView.setText(detailData.getKey());
                singleExtraLayout.addView(keyView);

                TextView valView = new TextView(this);
                valView.setTypeface(font, 0);
                LayoutParams valtextViewparams = new LayoutParams(0, LayoutParams.WRAP_CONTENT);
                valtextViewparams.weight = 7;
                valView.setLayoutParams(valtextViewparams);
                valView.setPadding((int) (5 * SCREEN_DENSITY), 0, (int) (5 * SCREEN_DENSITY), 0);
                valView.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                valView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
                valView.setText(Html.fromHtml(detailData.getValue()));
                valView.setMovementMethod(LinkMovementMethod.getInstance());
                singleExtraLayout.addView(valView);

                extrasLayout.addView(singleExtraLayout);
            }
        }

        rating.setText(locationDetails.getRating());
        address.setText(locationDetails.getAddress());
        if (Utils.isGpsEnabled(getApplicationContext())) {
            Region currentRegion = Utils.getNearByRegion(context);
            String distance = Utils.getDistanceFromLatAndLong(currentRegion.getLatitude(), locationDetails.getLatitude()
                    , currentRegion.getLongitude(), locationDetails.getLongitude());
            distance_text.setText(distance);
        } else {
            distance_text.setVisibility(View.GONE);
        }


        time.setText(locationDetails.getDisplayTime());
        cost.setText(locationDetails.getCostText());
        latitude = locationDetails.getLatitude();
        longitude = locationDetails.getLongitude();
        highlights.setText(locationDetails.getTagsString());
        setBookMarkStatus(locationDetails.getActivityId(), locationDetails.getId());

        // TabbedActivity.progressbar.setVisibility(View.INVISIBLE);
        if (latitude == null || longitude == null) {
            directions.setVisibility(View.GONE);
        }
        if (activityId != -1) {
            time_head.setVisibility(View.GONE);
            time.setVisibility(View.GONE);
            cost_head.setVisibility(View.GONE);
            cost.setVisibility(View.GONE);
            timingLayout.setVisibility(View.VISIBLE);
            showTimingInfo = locationData.getDateShowDetailInfo();
            if (locationDetails.getGroupId() == Constants.MOVIE_GROUP_ID) {
                highlightsLayout.setVisibility(View.GONE);
                addressLayout.setVisibility(View.GONE);
                directions.setVisibility(View.GONE);
                nearPlaces.setVisibility(View.GONE);
                similarPlaces.setVisibility(View.GONE);
                for (String date : showTimingInfo.keySet()) {
                    LayoutParams lparams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
                    TextView dateText = new TextView(context);
                    dateText.setTypeface(font, 0);
                    String dateFormat = Utils.getDateString(date);

                    dateText.setTextSize(20);
                    dateText.setText(dateFormat);

                    lparams.setMargins(0, 20, 0, 0);

                    timingLayout.addView(dateText, lparams);

                    for (ShowDetailDto showDetailDto : showTimingInfo.get(date)) {
                        LayoutParams hallparams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
                        TextView halltext = new TextView(context);
                        halltext.setTypeface(font, 0);
                        halltext.setText(showDetailDto.getText());
                        hallparams.setMargins(0, 10, 0, 0);
                        halltext.setTextSize(18);

                        timingLayout.addView(halltext, hallparams);
                        LinearLayout timeLayout = new LinearLayout(this);
                        timeLayout.setOrientation(LinearLayout.HORIZONTAL);
                        LayoutParams LLParams = new LayoutParams(LayoutParams.MATCH_PARENT, 60);

                        for (ShowDetail showDetail : showDetailDto.getShowDetails()) {
                            LayoutParams timeParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
                            TextView time = new TextView(context);
                            time.setTypeface(font, 0);
                            time.setText(showDetail.getShowTime());
                            time.setPadding(2, 1, 15, 1);
                            timeLayout.addView(time, timeParams);
                        }
                        timingLayout.addView(timeLayout, LLParams);
                    }
                }
            } else if (locationDetails.getGroupId() == Constants.EVENTS_GROUP_ID) {
                timingsHeading.setText("Event Details");
                for (String date : showTimingInfo.keySet()) {
                    LayoutParams lparams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
                    String dateFormat = Utils.getDateString(date);

                    for (final ShowDetailDto showDetailDto : showTimingInfo.get(date)) {

                        ShowDetail showDetail = showDetailDto.getShowDetails().get(0);
                        LinearLayout timeLayout = new LinearLayout(this);
                        timeLayout.setOrientation(LinearLayout.HORIZONTAL);
                        TextView dateTime = new TextView(this);
                        dateTime.setTypeface(font, 0);
                        dateTime.setTextSize(16);
                        dateTime.setText(dateFormat + "\n" + showDetail.getShowTime());
                        dateTime.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                        LayoutParams dateTimeParams = new LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 4.5f);
                        timeLayout.addView(dateTime, dateTimeParams);

                        TextView at = new TextView(this);
                        at.setTypeface(font, 0);
                        at.setTextSize(16);
                        at.setText("at");
                        at.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                        LayoutParams atParams = new LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.0f);
                        timeLayout.addView(at, atParams);

                        TextView locationText = new TextView(this);
                        locationText.setTypeface(font, 0);
                        locationText.setTextSize(16);
                        locationText.setClickable(true);
                        //locationText.setMovementMethod(LinkMovementMethod.getInstance());
                        //String url = Constants.BASE_SERVER_URL;
                        String text = "<font color='#05c5cf'><u>" + showDetailDto.getText() + "</font></u>";

                        locationText.setText(Html.fromHtml(text));
                        locationText.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent place = new Intent(PlaceDetailActivity.this, PlaceDetailActivity.class);
                                place.putExtra("activity_id", -1);
                                place.putExtra("location_detail_id", showDetailDto.getValue());
                                place.putExtra("inApp", true);
                                startActivity(place);

                            }
                        });
                        locationText.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
                        LayoutParams hallParams = new LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 4.5f);
                        timeLayout.addView(locationText, hallParams);


                        LayoutParams LLParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
                        LLParams.setMargins(0, 30, 0, 30);
                        View view = new View(this);
                        view.setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 2));
                        view.setBackgroundColor(getResources().getColor(R.color.grey));

                        timingLayout.addView(timeLayout, LLParams);
                        timingLayout.addView(view);
                    }
                }
                timingLayout.removeViewAt(timingLayout.getChildCount() - 1);
            }
        }
    }


    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        if (!isCallable) {
            MenuItem callItem = menu.findItem(R.id.call);
            callItem.setVisible(false);
        }
        return super.onPrepareOptionsMenu(menu);
    }

    private void setBookMarkStatus(int activityId, int id) {
        if (Globals.listOfSavedLocations.contains(activityLocation)) {
            bookmark.setText("Bookmarked");
        } else {
            bookmark.setText("Bookmark");
        }
    }

    @Override
    public void onClick(DialogInterface dialog, int which) {
        Intent sendIntent;
        Context context = PlaceDetailActivity.this;
        switch (which) {
            case 0:
                sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, Constants.SHARE_US_TEXT + locationDetails.getName() + "\n" + shareUrl);
                Bitmap mBitmap = Ion.with(placeImage).getBitmap();
                String path = MediaStore.Images.Media.insertImage(getContentResolver(),
                        mBitmap, locationDetails.getName(), null);
                Uri imageUri = Uri.parse(path);
                sendIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
                sendIntent.setType("image/*");
                sendIntent.setPackage("com.whatsapp");
                PackageManager packageManager = context.getPackageManager();
                List<ResolveInfo> activities = packageManager.queryIntentActivities(sendIntent, 0);
                boolean isIntentSafe = activities.size() > 0;
                if (isIntentSafe)
                    context.startActivity(sendIntent);
                else
                    Toast.makeText(context, "Whatsapp not installed", Toast.LENGTH_LONG).show();
                break;
            case 1:
                sendIntent = new Intent(Intent.ACTION_SEND);
                sendIntent.setType("text/plain");
                sendIntent.putExtra(Intent.EXTRA_SUBJECT, "I liked " + locationDetails.getName());
                sendIntent.putExtra(Intent.EXTRA_TEXT, shareUrl);
                sendIntent.setPackage("com.facebook.katana");

                packageManager = context.getPackageManager();
                activities = packageManager.queryIntentActivities(sendIntent, 0);
                isIntentSafe = activities.size() > 0;
                if (isIntentSafe)
                    context.startActivity(sendIntent);
                else
                    Toast.makeText(context, "Facebook not installed", Toast.LENGTH_LONG).show();
                break;
            case 2:
                sendIntent = new Intent(Intent.ACTION_VIEW);
                sendIntent.setType("plain/text");
                sendIntent.setClassName("com.google.android.gm", "com.google.android.gm.ComposeActivityGmail");
                sendIntent.putExtra(Intent.EXTRA_SUBJECT, "Hey, We should go out - " + locationDetails.getName());
                sendIntent.putExtra(Intent.EXTRA_TEXT, Constants.SHARE_US_TEXT + shareUrl);

                packageManager = context.getPackageManager();
                activities = packageManager.queryIntentActivities(sendIntent, 0);
                isIntentSafe = activities.size() > 0;
                if (isIntentSafe)
                    context.startActivity(sendIntent);
                else
                    Toast.makeText(context, "Gmail not installed", Toast.LENGTH_LONG).show();
                break;
            case 3:
                sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, Constants.SHARE_US_TEXT + locationDetails.getName() + "\n" + shareUrl);
                mBitmap = Ion.with(placeImage).getBitmap();
                path = MediaStore.Images.Media.insertImage(getContentResolver(),
                        mBitmap, locationDetails.getName(), null);
                imageUri = Uri.parse(path);
                sendIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
                sendIntent.setType("image/*");
                context.startActivity(sendIntent);
                break;
        }
        if(!BuildConfig.DEBUG) {
            GoogleAnalytics analytics = GoogleAnalytics.getInstance(context);
            Tracker tracker = analytics.newTracker(Constants.GOOGLE_ANALYTICS_URL);
            tracker.setScreenName("Place Page - " + locationDetails.getName() + locationDetailId + "-" + activityId);
            tracker.send(new HitBuilders.EventBuilder().setCategory("UX").setAction("click").setLabel("share").setValue(which).build());
        }
    }

    public Uri getLocalBitmapUri(ImageView imageView) {
        // Extract Bitmap from ImageView drawable
        Drawable drawable = imageView.getDrawable();
        Bitmap bmp = null;
        if (drawable instanceof BitmapDrawable){
            bmp = ((BitmapDrawable) imageView.getDrawable()).getBitmap();
        } else {
            return null;
        }
        // Store image to default external storage directory
        Uri bmpUri = null;
        try {
            File file =  new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS), "share_image_" + System.currentTimeMillis() + ".png");
            file.getParentFile().mkdirs();
            FileOutputStream out = new FileOutputStream(file);
            bmp.compress(Bitmap.CompressFormat.PNG, 90, out);
            out.close();
            bmpUri = Uri.fromFile(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bmpUri;
    }

    @Override
    public void onScrollChanged(int scrollY, boolean b, boolean b1) {

        FrameLayout.LayoutParams buttonLayoutParams = new FrameLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);

        // Translate title text
        float flexibleRange = mFlexibleSpaceImageHeight - mActionBarSize;
        int minOverlayTransitionY = mActionBarSize - mOverlayView.getHeight();
        ViewHelper.setTranslationY(mOverlayView, ScrollUtils.getFloat(-(int) (scrollY), minOverlayTransitionY, 0));
        ViewHelper.setTranslationY(mImageView, ScrollUtils.getFloat(-(int) (scrollY), minOverlayTransitionY, 0));

        // Change alpha of overlay
        ViewHelper.setAlpha(mOverlayView, ScrollUtils.getFloat((float) scrollY / flexibleRange, 0, 1));

        // Scale title text

        float scale = 1 + ScrollUtils.getFloat((flexibleRange - scrollY) / flexibleRange, 0, MAX_TEXT_SCALE_DELTA);
        ViewHelper.setPivotX(mTitleView, 0);
        ViewHelper.setPivotY(mTitleView, 0);
        ViewHelper.setScaleX(mTitleView, scale);
        ViewHelper.setScaleY(mTitleView, scale);

        int maxTitleTranslationY = (int) (mFlexibleSpaceImageHeight - mTitleView.getHeight() * scale);
        int titleTranslationY = maxTitleTranslationY - scrollY;
        if (scrollY > 10) {

            rating.setVisibility(View.GONE);
            gradientOverlay.setVisibility(View.GONE);
        } else {
            rating.setVisibility(View.VISIBLE);
            gradientOverlay.setVisibility(View.VISIBLE);
        }
        float density = context.getResources().getDisplayMetrics().density;
        double titleTranslationX = 0.0f;
        double marginTop = 0.0f;

        if (scrollY >= (int) (150 * density)) {
            marginTop = 200 * density / 3;
            titleTranslationY = 0;
            titleTranslationX = 23.3 * density;

        } else if (scrollY <= 5) {
            marginTop = 0.0f;
            titleTranslationX = 0;
        } else {
            marginTop = (200 * scrollY) / (150 * 3);
            titleTranslationX = (23.3 * scrollY) / 150;
        }
        buttonLayoutParams.setMargins(0, (int) marginTop, 0, 0);
        mScrollView.setLayoutParams(buttonLayoutParams);
        ViewHelper.setTranslationY(mTitleView, titleTranslationY);
        ViewHelper.setTranslationX(mTitleView, (int) titleTranslationX);
    }

    @Override
    public void onDownMotionEvent() {

    }

    @Override
    public void onUpOrCancelMotionEvent(ScrollState scrollState) {
    /*		ActionBar ab = getSupportActionBar();
            if (scrollState == ScrollState.UP) {
				if (ab.isShowing()) {
					ab.hide();
				}
			} else if (scrollState == ScrollState.DOWN) {
				if (!ab.isShowing()) {
					ab.show();
				}
			}*/

    }


    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.call_button:
            case R.id.call_button_inner:
                if(!BuildConfig.DEBUG) {
                    GoogleAnalytics analytics = GoogleAnalytics.getInstance(context);
                    Tracker tracker = analytics.newTracker(Constants.GOOGLE_ANALYTICS_URL);
                    tracker.setScreenName("Place Page - " + locationDetails.getName() + locationDetailId + "-" + activityId);
                    tracker.send(new HitBuilders.EventBuilder().setCategory("UX").setAction("click").setLabel("call").build());
                }
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + contact));
                startActivity(intent);
                break;

            case R.id.custom_view:
                intent = new Intent();

                if (locationDetails.getImages() != null) {
                    PlaceImageObject placeImageObject = new PlaceImageObject();
                    placeImageObject.setImageUrls(locationDetails.getImages());
                    intent.putExtra("imageUrls", placeImageObject);
                    intent.putExtra("name", locationDetails.getName());
                }
                intent.setClass(getApplicationContext(), PlaceImagesDisplay.class);
                startActivity(intent);


                break;
            case R.id.share_button:
            case R.id.share_button_inner:
                final Intent sendIntent;
                CharSequence options[] = new CharSequence[]{"Via Whatsapp", "Via Facebook", "Via Gmail", "More Options"};
                AlertDialog.Builder builder = new AlertDialog.Builder(PlaceDetailActivity.this);
                builder.setTitle("Share Place");
                builder.setItems(options, this);
                builder.show();
                break;
            case R.id.back_button:
            case R.id.back_button_inner:
                if (inApp || called_by.equals("trending"))
                    this.finish();
                else {
                    Intent i = new Intent(PlaceDetailActivity.this, NavigationAndTabs.class);
                    startActivity(i);
                    this.finish();
                }
                break;
        }
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
