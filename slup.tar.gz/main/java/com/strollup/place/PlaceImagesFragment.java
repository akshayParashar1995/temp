package com.strollup.place;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;

import java.util.List;

import in.strollup.android.R;

/**
 * Created by DELL LAPTOP on 7/10/2015.
 */
public class PlaceImagesFragment extends AppCompatActivity {
    private PlaceSlidesFragmentAdapter mAdapter;
    private ViewPager mPager;
    private List<String> imageUrls;
    public static final String TAG = "detailsFragment";
    private String name;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_place_details);
        Intent i = getIntent();
        Bundle b = i.getExtras();
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#000000")));

        PlaceImageObject placeImageObject = (PlaceImageObject) b.get("images");
        name= (String) b.get("name");
        int tabPosition = (int) b.get("tabPosition");
        imageUrls = placeImageObject.getImageUrls();
        mAdapter = new PlaceSlidesFragmentAdapter(this
                .getSupportFragmentManager(), imageUrls);

        mPager = (ViewPager) findViewById(R.id.pager);
        mPager.setAdapter(mAdapter);
        mPager.setCurrentItem(tabPosition);

        mPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                getSupportActionBar().setTitle(String.valueOf(position + 1) + " of " + String.valueOf(imageUrls.size()));
            }
        });
        return;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed()
    {
        Intent i=new Intent();
        PlaceImageObject placeImageObject = new PlaceImageObject();
        placeImageObject.setImageUrls(imageUrls);
        i.putExtra("imageUrls", placeImageObject);
        i.putExtra("name",name);
        i.setClass(getApplicationContext(),PlaceImagesDisplay.class);
        startActivity(i);
        finish();
    }
}