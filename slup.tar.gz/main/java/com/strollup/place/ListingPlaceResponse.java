package com.strollup.place;

import com.strollup.model.location.LocationDto;

import java.util.List;

public class ListingPlaceResponse {

	private List<LocationDto> locationStrings;
	private int locationCountStrings;

	public int getLocationCountStrings() {
		return locationCountStrings;
	}

	public void setLocationCountStrings(int locationCountStrings) {
		this.locationCountStrings = locationCountStrings;
	}

	public List<LocationDto> getLocationStrings() {
		return locationStrings;
	}

	public void setLocationStrings(List<LocationDto> locationStrings) {
		this.locationStrings = locationStrings;
	}

}
