package com.strollup.place;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;

import com.strollup.model.location.LocationDto;
import com.strollup.model.location.NearbyLocationDto;
import com.strollup.model.location.NearbyLocationGroupDto;

import java.util.ArrayList;
import java.util.List;

import in.strollup.android.R;


@SuppressLint("ValidFragment")
public class PlaceDetailNearbyFragment extends Fragment{
	
	NearbyLocationGroupDto locationGroup;
	List<NearbyLocationDto> locationOuterList;

    public PlaceDetailNearbyFragment() {
    }

	public PlaceDetailNearbyFragment(NearbyLocationGroupDto locations) {
		this.locationGroup = locations;
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater,
			@Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		View v = inflater.inflate(R.layout.listing_place, null);
		final GridView gv = (GridView)v.findViewById((int) R.id.place_listing_grid_view);
        float SCREEN_DENSITY = getResources().getDisplayMetrics().density;
        gv.setPadding(0, (int)(50 * SCREEN_DENSITY), 0, (int)10);
		locationOuterList = locationGroup.getNearByLocations();
		ArrayList<LocationDto> locations = new ArrayList<LocationDto>();
		for(int i=0;i<locationOuterList.size();i++)
			locations.add(locationOuterList.get(i).getLocation());
		PlaceListingAdapter adapter = new PlaceListingAdapter(getActivity(), 0, locations, gv);
		gv.setAdapter(adapter);
		return v;
	}

}
