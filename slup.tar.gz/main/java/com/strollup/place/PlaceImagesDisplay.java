package com.strollup.place;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import in.strollup.android.R;

/**
 * Created by DELL LAPTOP on 7/6/2015.
 */
public class PlaceImagesDisplay extends AppCompatActivity {
    private List<String> displayList = new ArrayList<String>();
    private String name;
    private   PlaceImageObject placeImageObject;

    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        setContentView(R.layout.place_list_display);
        Intent i = getIntent();
        Bundle b = null;
        if (i != null)
            b = i.getExtras();
        if (b != null) {
            placeImageObject = (PlaceImageObject) b.get("imageUrls");
            name = (String) b.get("name");
            String title = name + " Photos";
            setTitle(title);
        }
            displayList = placeImageObject.getImageUrls();
            ListView lv = (ListView) findViewById((int) R.id.place_detail_listview);
            PlaceImageListAdapter adapter = new PlaceImageListAdapter(getApplicationContext(), 0, displayList, lv);
            lv.setAdapter(adapter);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> gv, View arg1, int position, long arg3) {
                    gv.setEnabled(false);
                    Intent i = new Intent(getApplicationContext(), PlaceImagesFragment.class);
                    i.putExtra("tabPosition", position);
                    i.putExtra("images", placeImageObject);
                    i.putExtra("name",name);
                    startActivity(i);
                    finish();
                }
            });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
