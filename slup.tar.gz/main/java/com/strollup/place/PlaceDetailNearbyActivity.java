package com.strollup.place;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;

import com.github.florent37.materialviewpager.MaterialViewPager;
import com.strollup.model.location.NearbyLocationGroupDto;
import com.strollup.utility.Constants;

import java.util.ArrayList;
import java.util.List;

import in.strollup.android.R;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class PlaceDetailNearbyActivity extends AppCompatActivity {

    private MaterialViewPager mViewPager;
	private SectionPagerAdapterNew mSectionsPagerAdapter;
	private static final String TAG = PlaceDetailNearbyActivity.class.getSimpleName();
	List<NearbyLocationGroupDto> locationGroupsList;

	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);

		setContentView(R.layout.sliding_tabs_layout);
		ActionBar actionBar = getSupportActionBar();

		actionBar.setTitle("Near " + PlaceDetailActivity.locationData.getLocation().getName());
		actionBar.setDisplayHomeAsUpEnabled(true);
		locationGroupsList = PlaceDetailActivity.locationData.getNearByLocations();
		List<NearbyLocationGroupDto> nearbyLocationGroupDtos = new ArrayList<NearbyLocationGroupDto>();
		for (NearbyLocationGroupDto nearbyLocationGroupDto : locationGroupsList) {
			if (!nearbyLocationGroupDto.getGroup().equals("MOVIE")) {
				nearbyLocationGroupDtos.add(nearbyLocationGroupDto);
			}
		}
		locationGroupsList = nearbyLocationGroupDtos;
		mSectionsPagerAdapter = new SectionPagerAdapterNew(getSupportFragmentManager());
        mViewPager = (MaterialViewPager)findViewById(R.id.pager);
        mViewPager.getViewPager().setAdapter(mSectionsPagerAdapter);
        mViewPager.getPagerTitleStrip().setViewPager(mViewPager.getViewPager());
        Typeface font = Typeface.createFromAsset(this.getAssets(), Constants.BASE_FONT);
        mViewPager.getPagerTitleStrip().setTypeface(font,0);
        mViewPager.getViewPager().setOffscreenPageLimit(3);
	}

	public class SectionPagerAdapterNew extends FragmentPagerAdapter {

		public SectionPagerAdapterNew(FragmentManager fm) {
			super(fm);
		}

		@Override
		public Fragment getItem(int position) {
			Fragment fragment = new PlaceDetailNearbyFragment(locationGroupsList.get(position));
			return fragment;
		}

		@Override
		public int getCount() {
			return locationGroupsList.size();
		}

		@Override
		public CharSequence getPageTitle(int position) {
			return locationGroupsList.get(position).getGroup();
		}
	}

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
