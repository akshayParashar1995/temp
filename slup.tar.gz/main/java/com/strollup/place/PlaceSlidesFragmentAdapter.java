package com.strollup.place;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by DELL LAPTOP on 7/10/2015.
 */
public class PlaceSlidesFragmentAdapter extends FragmentPagerAdapter {
    List<String> imageUrls = new ArrayList<String>();

    public PlaceSlidesFragmentAdapter(FragmentManager fm, List<String> imageUrls) {
        super(fm);
        this.imageUrls = imageUrls;
    }

    @Override
    public Fragment getItem(int position) {
        return new PlaceSlideFragment(imageUrls.get(position));
    }

    @Override
    public int getCount() {
        return this.imageUrls.size();
    }

    public void setCount(int count) {
        notifyDataSetChanged();
    }
}
