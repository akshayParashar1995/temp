package com.strollup.trending;

import com.strollup.model.location.LocationData;

public class TrendingDataResponse {

	private LocationData trendingDataResponseString;

	public LocationData getTrendingDataResponseString() {
		return trendingDataResponseString;
	}

	public void setTrendingDataResponseString(LocationData trendingDataResponseString) {
		this.trendingDataResponseString = trendingDataResponseString;
	}

}
