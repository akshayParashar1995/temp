package com.strollup.trending;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.strollup.place.PlaceDetailActivity;
import com.strollup.plan.DisplayPlanMain;
import com.strollup.plan.DisplayPlanMainController;
import com.strollup.utility.Constants;

import java.util.List;

import in.strollup.android.R;

public class TrendingCardAdapter extends ArrayAdapter<TrendingCard> {
    private Context context;
    private Context activityContext;
    LayoutInflater inflater;
    private static float scale = 0.0f;

    public TrendingCardAdapter(Context context, int resource, List<TrendingCard> objects, Context activityContext) {
        super(context, resource, objects);
        this.context = context;
        this.activityContext = activityContext;
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        scale = context.getResources().getDisplayMetrics().density;
    }

    public class TrendingViewHolder {
        protected TextView headerTextView;
        protected ListView listView;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final TrendingViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.trending_card_item, null);
            holder = new TrendingViewHolder();
            holder.headerTextView = (TextView) convertView.findViewById(R.id.headerTextView);
            holder.listView = (ListView) convertView.findViewById(R.id.valueListView);
            convertView.setTag(holder);
        } else {
            holder = (TrendingViewHolder) convertView.getTag();
        }
        final TrendingCard trendingCard = getItem(position);
        Typeface font = Typeface.createFromAsset(context.getAssets(), Constants.BASE_FONT);
        holder.headerTextView.setTypeface(font, 0);
        holder.headerTextView.setText(trendingCard.getHeader());
        TrendingCardListAdapter adapter = new TrendingCardListAdapter(context, trendingCard.getHeader(), 0, trendingCard.getTrendingValues(),
                activityContext);
        int numberOfItems = trendingCard.getTrendingValues().size();
        ViewGroup.LayoutParams params = holder.listView.getLayoutParams();
        int pixels = (int) (80 * scale);
        int dpPixels = (int) (0.4 * scale);
        params.height = numberOfItems * pixels + (numberOfItems - 1) * dpPixels;
        holder.listView.setLayoutParams(params);
        holder.listView.setAdapter(adapter);
        holder.listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TrendingDetailDto detailDto = (TrendingDetailDto) holder.listView.getItemAtPosition(position);
                if (trendingCard.getHeader().equals("Outing Plans")) {
                    String url = DisplayPlanMainController.getTrendingPlan(context, detailDto.getTableNameId(), detailDto.getTableRowId());
                    Intent i = new Intent(context, DisplayPlanMain.class);
                    i.putExtra("url", url);
                    i.putExtra("called_by", "trending");
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(i);                                //display plans here :)
                } else {
                    Intent i = new Intent(context, PlaceDetailActivity.class);
                    i.putExtra("called_by", "trending");
                    i.putExtra("table_row_id", detailDto.getTableRowId());
                    i.putExtra("table_name_id", detailDto.getTableNameId());
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(i);
                }
            }
        });
        return convertView;
    }
}
