package com.strollup.trending;

import java.util.List;

public class TrendingCard {
	private String header;
	private List<TrendingDetailDto> trendingValues;

	public TrendingCard(String header, List<TrendingDetailDto> trendingValues) {
		this.header = header;
		this.trendingValues = trendingValues;
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public List<TrendingDetailDto> getTrendingValues() {
		return trendingValues;
	}

	public void setTrendingValues(List<TrendingDetailDto> trendingValues) {
		this.trendingValues = trendingValues;
	}

}
