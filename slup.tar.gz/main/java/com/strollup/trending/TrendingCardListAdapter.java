package com.strollup.trending;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView.LayoutParams;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.TableLayout;
import android.widget.TextView;

import com.balysv.materialripple.MaterialRippleLayout;
import com.squareup.picasso.Picasso;
import com.strollup.utility.Constants;
import com.strollup.utility.GsonRequest;

import java.util.List;

import in.strollup.android.R;

public class TrendingCardListAdapter extends ArrayAdapter<TrendingDetailDto> {

    private final LayoutInflater inflater;
    private Context context;
    private GsonRequest<TrendingDataResponse> ResponseRequest;
    private Context activityContext;
    private String headerType;
    private float scale = 0.0f;

    public TrendingCardListAdapter(Context context, String headerType, int resource, List<TrendingDetailDto> objects, Context activity) {
        super(context, resource, objects);
        this.context = context;
        this.headerType = headerType;
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.activityContext = activity;
        scale = context.getResources().getDisplayMetrics().density;

    }

    public class ViewHolder {
        private ImageView iv;
        private TextView header;
        private TextView descrip;
        private TextView rating;
        private MaterialRippleLayout layout;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.trending_simple_list_item, null);
            holder = new ViewHolder();
            Typeface font = Typeface.createFromAsset(context.getAssets(), Constants.BASE_FONT);
            Typeface boldFont = Typeface.createFromAsset(context.getAssets(), Constants.BOLD_FONT);
            holder.iv = (ImageView) convertView.findViewById(R.id.iv1);
            holder.header = (TextView) convertView.findViewById(R.id.tv1);
            holder.header.setTypeface(boldFont, 0);
            holder.descrip = (TextView) convertView.findViewById(R.id.tv2);
            holder.descrip.setTypeface(font, 0);
            holder.rating = (TextView) convertView.findViewById(R.id.tv_rate);
            holder.rating.setTypeface(font, 0);
            holder.layout = (MaterialRippleLayout) convertView.findViewById(R.id.riple_layout);
            convertView.setTag(holder);
        } else
            holder = (ViewHolder) convertView.getTag();

        int pixels = (int) (80 * scale + 0.5f);
        ViewGroup.LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, pixels);
        holder.layout.setLayoutParams(params);
        holder.layout.setPadding((int) (5 * scale), (int) (5 * scale), (int) (5 * scale), (int) (5 * scale));
        final TrendingDetailDto detailDto = getItem(position);
        holder.header.setText(detailDto.getName());
        holder.descrip.setText(detailDto.getTags());
        holder.rating.setText(detailDto.getRating());

        Picasso.with(context).load(detailDto.getImage()).placeholder(R.drawable.preloader).error(R.drawable.error_image).into(holder.iv);

        if (headerType.equals("Outing Plans")) {
            holder.header.setText(detailDto.getName());
            holder.header.setMaxLines(2);
            holder.header.setLayoutParams(new TableLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 2));
            holder.descrip.setVisibility(View.GONE);
            holder.iv.setScaleType(ScaleType.FIT_XY);
            holder.rating.setText(detailDto.getRating());
        } else {
            holder.header.setText(detailDto.getName());
            holder.descrip.setText(detailDto.getTags());
            holder.iv.setScaleType(ScaleType.FIT_XY);
            holder.rating.setText(detailDto.getRating());
        }
        return convertView;
    }
}
