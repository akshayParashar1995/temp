package com.strollup.trending;

import java.util.List;

public class TrendingResponse {
	private List<TrendingDto> trendingResponseString;

	public List<TrendingDto> getTrendingResponseString() {
		return trendingResponseString;
	}

	public void setTrendingResponseString(List<TrendingDto> trendingResponseString) {
		this.trendingResponseString = trendingResponseString;
	}

}
