package com.strollup.trending;

public class TrendingDataDto {

//	private DataResponse dataResponse;
//
//	public DataResponse getDataResponse() {
//		return dataResponse;
//	}
//
//	public void setDataResponse(DataResponse dataResponse) {
//		this.dataResponse = dataResponse;
//	}

}
