package com.strollup.trending;

import java.util.ArrayList;
import java.util.List;

public class TrendingDto {

	private int trendingEnumId;
	private String text;
	private int value;
	private List<TrendingDetailDto> details = new ArrayList<TrendingDetailDto>();

	public int getTrendingEnumId() {
		return trendingEnumId;
	}

	public void setTrendingEnumId(int trendingEnumId) {
		this.trendingEnumId = trendingEnumId;
	}

	public List<TrendingDetailDto> getDetails() {
		return details;
	}

	public void setDetails(List<TrendingDetailDto> details) {
		this.details = details;
	}

	public void addDetail(TrendingDetailDto detail) {
		if (details == null) {
			details = new ArrayList<TrendingDetailDto>();
		}
		details.add(detail);
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}
}
