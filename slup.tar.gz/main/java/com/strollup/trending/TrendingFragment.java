package com.strollup.trending;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.android.volley.Cache;
import com.android.volley.Cache.Entry;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;
import com.google.gson.Gson;
import com.getbase.floatingactionbutton.FloatingActionButton;
import com.strollup.floating_action_button.InviteFriends;
import com.strollup.main.AppController;
import com.strollup.request.BaseRequest;
import com.strollup.utility.Constants;
import com.strollup.utility.GsonRequest;
import com.strollup.utility.Utils;

import java.util.ArrayList;
import java.util.List;

import in.strollup.android.BuildConfig;
import in.strollup.android.R;

public class TrendingFragment extends Fragment {
	private static final String TAG = TrendingFragment.class.getSimpleName();
	private ArrayList<TrendingCard> trendingItems;
	private List<TrendingDto> trendingResponseString;
	private GsonRequest<TrendingResponse> myReq;
	private View view;
    private FloatingActionButton floatingActionButton;

    @Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		view = inflater.inflate((Integer) R.layout.trending_whole, null);
      //  FontsOverride.setDefaultFont(getActivity(), "MONOSPACE", "fonts/Montserrat-Light.otf");
		BaseRequest baseRequest = new BaseRequest(getActivity().getApplicationContext());
		String url = Constants.BASE_SERVER_URL + "getTrending?trendingRequestString=" + new Gson().toJson(baseRequest);
		loadContent(url);
		return view;
	}

	private void loadContent(String url) {
		Cache cache = AppController.getInstance().getRequestQueue().getCache();
		Entry entry = cache.get(url);
		if (entry != null && entry.serverDate + Constants.CACHE_EXPIRY_TIME > System.currentTimeMillis()) {
			try {
				String data = new String(entry.data, "UTF-8");
				TrendingResponse trendingResponse = (TrendingResponse) Utils.getCachedResponse(TrendingResponse.class,
						data);
				onSuccess(trendingResponse);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			AppController.getInstance().getRequestQueue().getCache().invalidate(url, true);
			myReq = new GsonRequest<TrendingResponse>(Request.Method.GET, url, TrendingResponse.class,
					createMyReqSuccessListener(), createMyReqErrorListener());
			AppController.getInstance().addToRequestQueue(myReq, TAG);
		}
	}

	private Response.Listener<TrendingResponse> createMyReqSuccessListener() {
		return new Response.Listener<TrendingResponse>() {
			@Override
			public void onResponse(TrendingResponse trendingResponse) {
				onSuccess(trendingResponse);
			};
		};
	}

	private void onSuccess(TrendingResponse trendingResponse) {
		try {
			trendingItems = new ArrayList<TrendingCard>();
			trendingResponseString = trendingResponse.getTrendingResponseString();
			for (int i = 0; i < trendingResponseString.size(); i++) {

				TrendingDto trendingDto = trendingResponseString.get(i);
				String header = trendingDto.getText();
				TrendingCard trendingCard = new TrendingCard(header, trendingDto.getDetails());
				trendingItems.add(trendingCard);

			}
			ListView lv = (ListView) view.findViewById((int) R.id.trending_whole1);
            floatingActionButton = (FloatingActionButton)view.findViewById(R.id.floating_trending);
            floatingActionButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(getActivity(),InviteFriends.class);
                    getActivity().startActivity(intent);
                }
            });
			TrendingCardAdapter adapter = new TrendingCardAdapter(getActivity().getApplicationContext(), 0,
					trendingItems, getActivity());
			lv.setAdapter(adapter);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private Response.ErrorListener createMyReqErrorListener() {
		return new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {
				Log.e(TAG, "Error Occured while calling backend", error.getCause());
				if (error instanceof NoConnectionError || error instanceof TimeoutError)
					Utils.noNetworkMessage(getActivity(), myReq);
			}
		};
	}

    @Override
    public void onResume() {
        super.onResume();
        if (!BuildConfig.DEBUG) {
            GoogleAnalytics analytics = GoogleAnalytics.getInstance(getActivity());
            Tracker tracker = analytics.newTracker(Constants.GOOGLE_ANALYTICS_URL);
            tracker.setScreenName("Trending");
            tracker.send(new HitBuilders.ScreenViewBuilder().build());
        }
    }
}
