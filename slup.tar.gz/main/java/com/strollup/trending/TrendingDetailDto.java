package com.strollup.trending;

import com.strollup.utility.Constants;

public class TrendingDetailDto {

	private int tableNameId;
	private int tableRowId;
	private int showTime;
	private int hideTime;
	private String name;
	private int id;
	private String image;
	private String tags;
	private double rating;
	private int groupId;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTags() {
		return tags;
	}

	public void setTags(String tags) {
		this.tags = tags;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public int getTableNameId() {
		return tableNameId;
	}

	public void setTableNameId(int tableNameId) {
		this.tableNameId = tableNameId;
	}

	public int getTableRowId() {
		return tableRowId;
	}

	public void setTableRowId(int tableRowId) {
		this.tableRowId = tableRowId;
	}

	public int getShowTime() {
		return showTime;
	}

	public void setShowTime(int showTime) {
		this.showTime = showTime;
	}

	public int getHideTime() {
		return hideTime;
	}

	public void setHideTime(int hideTime) {
		this.hideTime = hideTime;
	}

	public String getImage() {
		if (groupId == Constants.MOVIE_GROUP_ID || groupId == Constants.EVENT_ID) {
			return (Constants.BASE_LOCATION_IMAGE_URL + image).replace(" ","%20").replace("é","&#233");
		}
		return (Constants.BASE_LOCATION_IMAGE_URL + name + "/" + image).replace(" ","%20").replace("é","&#233");
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getRating() {
		String rating = String.valueOf(this.rating * 2);
		int rIndex = rating.indexOf(".");
		if(rIndex > -1) {
			return rating.substring(0, rIndex);
		}
		return rating;
	}
}