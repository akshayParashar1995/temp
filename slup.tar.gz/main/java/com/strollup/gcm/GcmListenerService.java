package com.strollup.gcm;

import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.TaskStackBuilder;

import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.strollup.main.SplashScreen;

import in.strollup.android.R;

/**
 * An {@link IntentService} subclass for handling asynchronous task requests in
 * a service on a separate handler thread.
 * <p/>
 * TODO: Customize class - update intent actions, extra parameters and static
 * helper methods.
 */
public class GcmListenerService extends com.google.android.gms.gcm.GcmListenerService {
    private Bitmap userImage;
    private Bitmap backBitmap;

    private Bundle bundle;
    private NotificationManager mNotificationManager;
    private Notification notification;

    @Override
    public void onMessageReceived(String from, Bundle data) {
        super.onMessageReceived(from, data);
        String message = data.getString("Title");
        this.bundle = data;
        showNotification(data);
    }


    public void showNotification(Bundle bundle) {
        NotificationCompat.Builder mBuilder;
        mBuilder = new NotificationCompat.Builder(getApplicationContext())
                .setContentTitle(bundle.getString("Title")).setContentText(bundle.getString("Description"));
        mBuilder.setSmallIcon(R.drawable.ic_stat_s);

        String userPhotoUrl = bundle.getString("IconUrl");
        if (userPhotoUrl != null)
            getBitmapFromUrl(userPhotoUrl);
        String backBitmapUrl = bundle.getString("Image");
        if (backBitmapUrl != null)
            getBackgroundBitmapFromUrl(backBitmapUrl);

        if ((backBitmapUrl != null)) {
            while (userImage == null || backBitmap == null) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            mBuilder.setStyle(new NotificationCompat.BigPictureStyle().bigPicture(backBitmap).setSummaryText(bundle.getString("Description")).setBigContentTitle(bundle.getString("Title")));
        } else {
            while (userImage == null) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        mBuilder.setLargeIcon(userImage);
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(GcmListenerService.this);
        Intent resultIntent = new Intent(getApplicationContext(), SplashScreen.class);
        resultIntent.putExtra("called_by", "gcm_notification");
        resultIntent.putExtras(bundle);
        stackBuilder.addParentStack(SplashScreen.class);
        stackBuilder.addNextIntent(resultIntent);
        PendingIntent resultPendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);
        mBuilder.setContentIntent(resultPendingIntent);

        mBuilder.setAutoCancel(true);
        notification = mBuilder.build();
        mNotificationManager = (NotificationManager) getApplicationContext()
                .getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.notify(Integer.parseInt(bundle.getString("Id")), notification);
    }

    public void getBackgroundBitmapFromUrl(String photoUrl) {
        final Bitmap bitmap = null;
        Ion.with(this).load(photoUrl).withBitmap().asBitmap()
                .setCallback(new FutureCallback<Bitmap>() {
                    @Override
                    public void onCompleted(Exception e, Bitmap result) {
                        backBitmap = result;
                    }

                });
    }

    public void getBitmapFromUrl(String photoUrl) {
        final Bitmap bitmap = null;
        Ion.with(this).load(photoUrl).withBitmap().asBitmap()
                .setCallback(new FutureCallback<Bitmap>() {
                    @Override
                    public void onCompleted(Exception e, Bitmap result) {
                        userImage = result;
                    }
                });
    }
}
