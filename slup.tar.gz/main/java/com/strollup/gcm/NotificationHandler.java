package com.strollup.gcm;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;
import com.strollup.main.ExploreTabListing;
import com.strollup.main.NavigationAndTabs;
import com.strollup.place.PlaceDetailActivity;
import com.strollup.utility.Constants;

import in.strollup.android.BuildConfig;

/**
 * Created by Akshay on 08-07-2015.
 */
public class NotificationHandler {

    public static void handleNotification(Bundle bundle, Context context) {

        Intent resultIntent = new Intent();
        String action = bundle.getString("Intent");
        String label = bundle.getString("Title");
        long value = Integer.parseInt(bundle.getString("Id"));
        if (!BuildConfig.DEBUG) {
            GoogleAnalytics analytics = GoogleAnalytics.getInstance(context);
            Tracker tracker = analytics.newTracker(Constants.GOOGLE_ANALYTICS_URL);
            tracker.send(new HitBuilders.EventBuilder().setCategory("Notification").setAction(action).setLabel(label).setValue(value).build());
        }
        switch (bundle.getString("Intent")) {
            case "PlaceDetailActivity":
                resultIntent = new Intent(context, PlaceDetailActivity.class);
                resultIntent.putExtra("activity_id", Integer.parseInt(bundle.getString("activity_id")));
                resultIntent.putExtra("location_detail_id", Integer.parseInt(bundle.getString("location_detail_id")));
                break;
            case "Explore":
                resultIntent = new Intent(context, ExploreTabListing.class);
                resultIntent.putExtra("tabPosition", Integer.parseInt(bundle.getString("tabPosition")));
                resultIntent.putExtra("allFilter", (bundle.getString("allFilter")));
                break;
            case "Trending":
                resultIntent = new Intent(context, NavigationAndTabs.class);
                resultIntent.putExtra("isCalledByGcm",true);
                resultIntent.putExtra("tabbedPosition", Integer.parseInt(bundle.getString("tabbedPosition")));
                break;
        }
        resultIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(resultIntent);
    }
}
