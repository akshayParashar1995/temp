package com.strollup.gcm;

import com.google.android.gms.gcm.GcmListenerService;

/**
 * Created by Akshay on 07-07-2015.
 */
public class GcmListener extends GcmListenerService {
}
