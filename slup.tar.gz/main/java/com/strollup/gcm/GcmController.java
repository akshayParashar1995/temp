package com.strollup.gcm;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.google.gson.Gson;
import com.strollup.main.AppController;
import com.strollup.utility.Constants;
import com.strollup.utility.GsonRequest;

/**
 * Created by Akshay on 06-07-2015.
 */
public class GcmController {

    public static void sendRegIdToBackend(Context context,String regId){
        GcmRequest gcmRequest=new GcmRequest(context,regId);
        String saveGcmRegIdUrl = Constants.BASE_SERVER_URL + "registerGCMId?gcmRequestString="+
                new Gson().toJson(gcmRequest);
        saveGcmRegIdUrl = saveGcmRegIdUrl.replaceAll(" ", "%20");
        GsonRequest<GcmRegistrationResponse> request = new GsonRequest<GcmRegistrationResponse>(
                Request.Method.GET, saveGcmRegIdUrl, GcmRegistrationResponse.class,
                createMyReqSuccessListener(regId), createMyReqErrorListener());
        AppController.getInstance().addToRequestQueue(request);
    }

    private static Response.Listener<GcmRegistrationResponse> createMyReqSuccessListener(String Id) {
        return new Response.Listener<GcmRegistrationResponse>() {
            @Override
            public void onResponse(GcmRegistrationResponse response) {
            }
        };
    }

    private static Response.ErrorListener createMyReqErrorListener() {
        return new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        };
    }

}
