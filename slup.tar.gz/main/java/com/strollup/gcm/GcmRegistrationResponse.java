package com.strollup.gcm;

/**
 * Created by Akshay on 06-07-2015.
 */
public class GcmRegistrationResponse {

    private boolean responseString;

    public boolean isResponseString() {
        return responseString;
    }

    public void setResponseString(boolean responseString) {
        this.responseString = responseString;
    }
}
