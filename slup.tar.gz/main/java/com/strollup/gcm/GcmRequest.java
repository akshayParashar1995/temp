package com.strollup.gcm;

import android.content.Context;

import com.strollup.request.BaseRequest;

/**
 * Created by Akshay on 06-07-2015.
 */
public class GcmRequest extends BaseRequest{

    private String gcmRegisterId;

    public String getGcmRegisterId() {
        return gcmRegisterId;
    }

    public void setGcmRegisterId(String gcmRegisterId) {
        this.gcmRegisterId = gcmRegisterId;
    }

    public GcmRequest(Context context,String regId) {
        super(context);
        this.gcmRegisterId =regId;
    }
}
