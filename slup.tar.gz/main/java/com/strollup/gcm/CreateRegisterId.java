package com.strollup.gcm;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.strollup.utility.AppPreferences;
import com.strollup.utility.Utils;

import java.io.IOException;

public class CreateRegisterId  {
    private int nId;
    private GoogleCloudMessaging gcm;
    private static final String SENDER_ID = "493772607049";
    private String regID;
    private Context context;

    public void getRegisterId(Context context) {
        regID = AppPreferences.getRegistrationId(context);
        this.context=context;
        gcm = GoogleCloudMessaging.getInstance(context);


        if(gcm == null) {
            return;
        }
        if (regID == null) {
            register();
        } else {
            if (Utils.getCurrentVersionCode(context) != AppPreferences.getCurrentVersion(context)) {
                register();
                AppPreferences.setCurrentVersion(context);
            }
        }
    }

    private void register() {
        AsyncTask<Void, Void, String> registerTask = new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... params) {
                String output = "";
                try {
                    String regId = gcm.register(SENDER_ID);
                    output += regId;

                } catch (IOException e) {
                    e.printStackTrace();
                    output += e.getMessage();
                }
                return output;
            }

            @Override
            protected void onPostExecute(String result) {
                Log.i("regId", result  + "");
                if (result != null) {
                    AppPreferences.saveRegistrationId(context, result);
                    GcmController.sendRegIdToBackend(context, result);
                }
                super.onPostExecute(result);
            }
        };
        registerTask.execute();
    }
    private void sendUpstreamMessage(){
        new AsyncTask() {


            @Override
            protected Object doInBackground(Object[] params) {
                String msg = "";
                try {
                    Bundle data = new Bundle();
                    data.putString("my_message", "Hello World");
                    data.putString("my_action",
                            "com.google.android.gcm.demo.app.ECHO_NOW");
                    String id = Integer.toString(1);
                    gcm.send("493772607049" + "@gcm.googleapis.com", id, data);
                    msg = "Sent message";
                } catch (IOException ex) {
                    msg = "Error :" + ex.getMessage();
                }
                return msg;
            }

            @Override
            protected void onPostExecute(Object o) {
                super.onPostExecute(o);
                Log.i("sent", o.toString() + "\n");
            }
        }.execute(null, null, null);
    }
}
