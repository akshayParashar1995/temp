package com.strollup.utility;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;

import com.strollup.filter.LatLong;

public class GoogleMapsUtility extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		Intent mapIntent = getIntent();
		Bundle b = mapIntent.getExtras();
		final String latitude = b.getString("latitude");
		final String longitude = b.getString("longitude");
		Boolean isMapPresent = checkForGoogleMaps(getApplicationContext());
		if (isMapPresent == true) {
			openMapWithApp(latitude, longitude);
		} else {
			openMapWithBrowser(latitude, longitude);
		}

	}
	public static void showDirections(LatLong start, LatLong end,Context context){
		if(checkForGoogleMaps(context)){
			getDirectionsWithApp(start.getLatitude(),start.getLongitude(),end.getLatitude(),end.getLongitude(), context);
		}
		else{
			getDirectionsWithoutApp(start.getLatitude(),start.getLongitude(),end.getLatitude(),end.getLongitude(), context);
		}
	}
	public static void getDirectionsWithApp(String startLat, String startLong, String endLat, String endLong,Context context) {
		Intent intent = new Intent(android.content.Intent.ACTION_VIEW, Uri.parse("http://maps.google.com/maps?saddr="
				+ startLat + "," + startLong + "&daddr=" + endLat + "," + endLong));
		intent.setClassName("com.google.android.apps.maps", "com.google.android.maps.MapsActivity");
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		context.startActivity(intent);
	}

	public static void getDirectionsWithoutApp(String startLat, String startLong, String endLat, String endLong,Context context) {
		Intent intent = new Intent(android.content.Intent.ACTION_VIEW, Uri.parse("http://maps.google.com/maps?saddr="
				+ startLat + "," + startLong + "&daddr=" + endLat + "," + endLong));
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		context.startActivity(intent);
	}
	
	public void openMapWithApp(String latitude, String longitude) {
		Intent intent = new Intent(android.content.Intent.ACTION_VIEW, Uri.parse("http://maps.google.com/maps?daddr="
				+ latitude + "," + longitude));
		intent.setClassName("com.google.android.apps.maps", "com.google.android.maps.MapsActivity");
		startActivity(intent);
		finish();
	}

	public void openMapWithBrowser(String latitude, String longitude) {
		Intent intent = new Intent(android.content.Intent.ACTION_VIEW, Uri.parse("http://maps.google.com/maps?daddr="
				+ latitude + "," + longitude));
		startActivity(intent);
		finish();
	}

	public static boolean checkForGoogleMaps(Context context) {
		try {
			ApplicationInfo info = context.getPackageManager().getApplicationInfo("com.google.android.apps.maps", 0);
			return true;
		} catch (PackageManager.NameNotFoundException e) {
			return false;
		}

	}
}
