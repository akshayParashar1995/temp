package com.strollup.utility;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.strollup.main.SplashScreen;

public class WebViewController {

	public WebView launchWebView(final Context context, View view, final String url) {
		final WebView w = new WebView(context);
		view.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				launchWebView(context, url);
			}
		});
		return w;
	}

	public WebView launchWebView(Context context, final String url) {
		WebView webview = new WebView(context);
		webview.setWebViewClient(new WebViewClient() {
			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				return false;
			}

			@Override
			public void onPageStarted(WebView view, String url, Bitmap bitmap) {
			}

			@Override
			public void onPageFinished(WebView view, String url) {
			}
		});
		webview.loadUrl(url);
		if(!url.equals(Constants.TERMS_OF_SERVICE_URL)) {
			SplashScreen.decrementNoOfVolleyRequests();
		}
		return webview;
	}
}
