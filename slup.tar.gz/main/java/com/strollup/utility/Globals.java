package com.strollup.utility;

import com.strollup.activity.ActivityDataResponse;
import com.strollup.filter.Region;
import com.strollup.floating_action_button.OutingObject;
import com.strollup.main.SavedPlanResponse;
import com.strollup.plan.PlanActivityType;
import com.strollup.request.ActivityLocation;
import com.strollup.save.SavedMobileLocationDto;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Globals {
	public static ActivityDataResponse activityResult = new ActivityDataResponse();
	public static List<PlanActivityType> planActivityTypes = new ArrayList<PlanActivityType>();
	public static List<ActivityLocation> listOfSavedLocations = new ArrayList<ActivityLocation>();
	public static List<SavedMobileLocationDto> savedLoacations = new ArrayList<SavedMobileLocationDto>();
	public static Set<Region> suggestedAreas = new HashSet<Region>();
	public static SavedPlanResponse savedPlans=new SavedPlanResponse();
    public static Region currentGpsLocation=null;
    public static OutingObject outingDto=new OutingObject();
}
