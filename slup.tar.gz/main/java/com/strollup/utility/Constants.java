package com.strollup.utility;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Constants {

    public static final String BASE_SERVER_URL = Constants.BASE_TEST_SERVER_URL;
    public static final String BASE_FONT = "fonts/Montserrat-Light.otf";
    public static final String BOLD_FONT = "fonts/Montserrat-Regular.otf";
    public static int HOME_TAB_POSITION = 0;
    public static int NO_OF_TRIES_BEFORE_SHARE_POPUP = 3;        //on 4th plan page no
    public static int NO_OF_URL_HITS_SHARE_POPUP = 3;        //on viewing 3rd url hit
    public static final String GOOGLE_ANALYTICS_URL = "UA-50435201-2";
    public static int PLACE_DETAIL_ACTIVITY_NO = 1;
    public static int PLAN_DISPLAY_ACTIVITY_NO = 2;
    public static final String SHARE_APP_LINK = "https://play.google.com/store/apps/details?id=in.strollup.android";
    public static final String SHARE_US_ON_FACEBOOK = "We hope you like these outing plans. Please share our app on facebook just once to checkout all the plans";
    public static final String BASE_IMAGE_URL = "https://d2od7r6i0yooa3.cloudfront.net/image/";
    public static final String BASE_LOCATION_IMAGE_URL = "https://d2od7r6i0yooa3.cloudfront.net/image/location/";
    public static final String DEFAULT_IMAGE_URL = "https://d2od7r6i0yooa3.cloudfront.net/image/default.jpg";
    public static final String BASE_TEST_SERVER_URL = "http://52.74.78.106:8080/";
    public static final String BASE_DEV_SERVER_URL = "http://192.168.1.100:9090/skyfall/";
    public static final String BASE_PROD_SERVER_URL = "http://www.strollup.in/";
    public static final String SHARE_APP_TEXT = "Check out the new cool way to plan your outings : https://play.google.com/store/apps/details?id=in.strollup.android";
    public static final String SHARE_US_TEXT = "We should definitely try this out! \n";
    public static final String GENERAL_ERROR_MESSAGE = "Oops, Something went wrong!";
    public static final int ACTIVITY_TYPE_COUNT = 11;
    public static final int EVENT_ID = 5;
    public static final String FORGOT_PASSWORD_SUCCESS = "Instructions have been sent to your mail.\nCheck your mail to reset your password";
    public static final String FORGOT_PASSWORD_FAIL = "We could not find this email in our system.\nPlease check again.";
    public static final String NEARBY_PLACES = "Near Current Location";
    public static final String SHARE_US_URL = "http://www.strollup.in/";
    public static final String DEFAULT_USER_NAME = "StrollUp User";
    public static final String DEFAULT_USER_IMAGE = BASE_IMAGE_URL + "fb-image.jpg";
    public static final int DELHI_CITY_ID = 1;
    public static final int BANGALORE_CITY_ID = 2;
    public static final String SHOWING_PLANS = "Plan ";
    public static final String NO_PLACES_FOUND = "No places found corresponding to your selection";
    public static final int NEARBY_GROUP_COUNT = 3;
    public final static String APP_PACKAGE_NAME = "in.strollup.android";

    public static final String TERMS_OF_SERVICE_URL = "http://www.strollup.in/terms";
    public static final String PLAY_STORE_MARKET_URL = "market://details?id=";
    public static final String PLAY_STORE_BROWSER_URL = "https://play.google.com/store/apps/details?id=";
    public static final String PACKAGE_NAME = "in.strollup.android";
    public static final long CACHE_EXPIRY_TIME = 60 * 60 * 1000;
    public static final long BIG_CACHE_EXPIRY_TIME = 24 * 60 * 60 * 1000;
    public static final int MOVIE_GROUP_ID = 4;
    public static final int EVENTS_GROUP_ID = 5;
    public static final String TRUE = "true";
    public static final String SELECT_ALL = "Select All";
    public static final String ANYTHING_ACTIVITY = "Anything will work";
    public static final CharSequence ENABLE_GPS_MESSAGE = "Your GPS seems to be disabled, Please enable it to access your location";
    public static final CharSequence NO_NETWORK_FOUND = "Unable to connect to network. Please switch on your network and try again.";

    public static final String[] COST = {"Less than Rs.250", "Rs.250 to Rs.500", "Rs.500 to Rs.1000",
            "Rs.1000 to Rs.2000", "Greater than Rs.2000"};
    public static final String[] TIME_SLOTS = {"12:00 AM", "1:00 AM", "2:00 AM", "3:00 AM", "4:00 AM", "5:00 AM",
            "6:00 AM", "7:00 AM", "8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "1:00 PM", "2:00 PM",
            "3:00 PM", "4:00 PM", "5:00 PM", "6:00 PM", "7:00 PM", "8:00 PM", "9:00 PM", "10:00 PM", "11:00 PM"};
    public static final String[] SORT_OPTIONS_FOR_PLACES = {"Cost", "Popularity"};
    public static final String[] SORT_OPTIONS_FOR_PLANS = {"Cost", "Popularity", "Distance"};

    public static final int DEFAULT_CITY_ID = 1;
    public static final String DEFAULT_DEVICE_ID = "-1";
    public static final Map<Integer, String> GROUPURL_NAME = new HashMap<Integer, String>() {
        {
            put(1, "foodanddrink-places");
            put(2, "fun-places");
            put(3, "visit-places");
            put(4, "movies");
            put(5, "events");
        }
    };
    public static final Map<Integer, String> CITY_URL_NAME = new HashMap<Integer, String>() {
        {
            put(1, "delhi");
            put(2, "bangalore");
        }
    };
    public static final Map<Integer, String> HEADER_NAMES = new HashMap<Integer, String>() {
        {
            put(4, "Recommended Plans");
            put(3, "Popular Places");
            put(2, "Trending Activities");
        }
    };

    public static final Map<Integer, String> DEFAULT_AREA = new HashMap<Integer, String>() {
        {
            put(1, "Connaught Place");
            put(2, "Indiranagar");
        }
    };
    public static final Map<Integer, String> DEFAULT_AREA_LATITUDE_LONGITUDE = new HashMap<Integer, String>() {
        {
            put(1, "28.6289146,77.2152869");
            put(2, "12.9731051,77.638255");
        }
    };
    public static final Map<Integer, String> DEFAULT_AREA_LATITUDE = new HashMap<Integer, String>() {
        {
            put(1, "28.6289146");
            put(2, "12.9731051");
        }
    };
    public static final Map<Integer, String> DEFAULT_AREA_LONGITUDE = new HashMap<Integer, String>() {
        {
            put(1, "77.2152869");
            put(2, "77.638255");
        }
    };
    public static final List<Integer> PLAN_ACTIVITY_TYPES = Arrays.asList(1, 2, 3, 6, 7, 8, 9, 11, 12, 13, 14, 15, 16);
    public static final String CURRENT_LOCATION = "Current Location";
    public static final Map<Integer, String> CITY_MAP = new HashMap<Integer, String>() {
        {
            put(1, "Delhi-NCR");
            put(2, "Bangalore");
        }
    };

    public static void setKeyValue(String key, String value) {
        if (key.equals("NO_OF_TRIES_BEFORE_SHARE_POPUP")) {
            NO_OF_TRIES_BEFORE_SHARE_POPUP = Integer.parseInt(value);
        }
        if (key.equals("NO_OF_URL_HITS_SHARE_POPUP")) {
            NO_OF_URL_HITS_SHARE_POPUP = Integer.parseInt(value);
        }
        if (key.equals("HOME_TAB_POSITION")) {
            HOME_TAB_POSITION = 0;
        }
    }

    public static String ANYWHERE_IN_CURRENT_STATE = "Anywhere in ";

}
