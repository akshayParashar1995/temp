package com.strollup.utility;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.telephony.TelephonyManager;

import com.google.gson.Gson;
import com.strollup.filter.Region;

import java.util.HashSet;

public class AppPreferences {

	public static void setBasicProfile(Context mContext, String name, String photo) {
		if(name == null || photo == null) {
			return;
		}
		SharedPreferences prefs = mContext.getSharedPreferences("basicProfile", 0);
		SharedPreferences.Editor editor = prefs.edit();
		editor.putString("name", name);
		editor.putString("photo", photo);
		editor.commit();
	}

	public static void setLoggedInAsTrue(Context mContext) {
		SharedPreferences prefs = mContext.getSharedPreferences("basicProfile", 0);
		SharedPreferences.Editor editor = prefs.edit();
		editor.putBoolean("loggedin", true);
		editor.commit();
	}

	public static String getDeviceId(Context mContext) {
		final TelephonyManager tm = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
		if (tm.getDeviceId() == null) {
			return Constants.DEFAULT_DEVICE_ID;
		}
		return tm.getDeviceId();
	}

	public static void setUserId(Context mContext, int userId) {
		SharedPreferences prefs = mContext.getSharedPreferences("basicProfile", 0);
		SharedPreferences.Editor editor = prefs.edit();
		editor.putInt("userId", userId);
		editor.commit();
	}

	public static int getUserId(Context mContext) {
		SharedPreferences prefs = mContext.getSharedPreferences("basicProfile", 0);
		return prefs.getInt("userId", 311);
	}

	public static int getCityId(Context mContext) {
		SharedPreferences prefs = mContext.getSharedPreferences("basicProfile", 0);
		return prefs.getInt("cityId", Constants.DEFAULT_CITY_ID);
	}

	public static void setCityId(Context mContext, int cityId) {
		SharedPreferences prefs = mContext.getSharedPreferences("basicProfile", 0);
		SharedPreferences.Editor editor = prefs.edit();
		editor.putInt("cityId", cityId);
		editor.commit();
	}

	public static boolean isLoggedIn(Context mContext) {
		SharedPreferences prefs = mContext.getSharedPreferences("basicProfile", 0);
		return prefs.getBoolean("loggedin", false);
	}

	public static String getUsername(Context mContext) {
		SharedPreferences prefs = mContext.getSharedPreferences("basicProfile", 0);
		return prefs.getString("name", Constants.DEFAULT_USER_NAME);
	}

	public static String getUserPhoto(Context mContext) {
		SharedPreferences prefs = mContext.getSharedPreferences("basicProfile", 0);
		return prefs.getString("photo",null);
	}

	public static boolean isCitySet(Context mContext) {
		SharedPreferences prefs = mContext.getSharedPreferences("basicProfile", 0);
		int cityId = prefs.getInt("cityId", -1);
		if (cityId >= 1 && cityId <= 2) {
			return true;
		}
		return false;
	}

	public static boolean getIsWillingToUpdate(Context context, float latestVersion) {
		SharedPreferences sp = context.getSharedPreferences("update_preference", Context.MODE_PRIVATE);
		return sp.getBoolean("version:" + latestVersion, true);
	}

	public static void setIsWillingToUpdateToFalse(Context context, String latestVersion) {
		SharedPreferences sp = context.getSharedPreferences("update_preference", Context.MODE_PRIVATE);
		Editor editor = sp.edit();
		editor.putBoolean("version:" + latestVersion, false);
		editor.commit();
	}

	public static boolean getIsWillingToShowNotification(Context context, int id) {
		SharedPreferences sp = context.getSharedPreferences("notification_preference", Context.MODE_PRIVATE);
		return sp.getBoolean("id:" + id, true);
	}

	public static void setIsWillingToShowNotificationToFalse(Context context, int id) {
		SharedPreferences sp = context.getSharedPreferences("notification_preference", Context.MODE_PRIVATE);
		Editor editor = sp.edit();
		editor.putBoolean("id:" + id, false);
		editor.commit();
	}

	public static boolean getIsThisPageDisplayedFirst(Context context, int pageNo) {
		SharedPreferences sp = context.getSharedPreferences("tutorial_preference", Context.MODE_PRIVATE);
		return sp.getBoolean("page:" + pageNo, true);
	}

	public static void setIsThisPageDisplayedFirst(Context context, int pageNo) {
		SharedPreferences sp = context.getSharedPreferences("tutorial_preference", Context.MODE_PRIVATE);
		Editor editor = sp.edit();
		editor.putBoolean("page:" + pageNo, false);
		editor.commit();
	}

    public static int getNoOfDisplayPlanHits(Context context) {
        SharedPreferences sp = context.getSharedPreferences("plan_display_preference", Context.MODE_PRIVATE);
        HashSet<String> newSet = new HashSet<String>();
        return ((HashSet<String>) sp.getStringSet("display_plan", newSet)).size();

    }

    public static void addToListOfDisplayPlanHits(Context context, String url) {
        SharedPreferences sp = context.getSharedPreferences("plan_display_preference", Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        HashSet<String> newSet = new HashSet<String>();
        HashSet<String> set = (HashSet<String>) sp.getStringSet("display_plan", newSet);
        set.add(url);
        editor.putStringSet("display_plan", set);
        editor.commit();
    }

    public static boolean getIsSharedSucessfullyOnFb(Context context) {
        SharedPreferences sp = context.getSharedPreferences("shared_preference", Context.MODE_PRIVATE);
        return sp.getBoolean("is_shared", false);
    }

    public static void setIsSharedSucessfullyOnFb(Context context) {
        SharedPreferences sp = context.getSharedPreferences("shared_preference", Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        editor.putBoolean("is_shared", true);
        editor.commit();
    }

    public static void saveRegistrationId(Context context,String regId) {
        SharedPreferences sp = context.getSharedPreferences("gcm_reg_id", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();

        editor.putString("regid", regId);
        editor.commit();
    }

    public static String getRegistrationId(Context context) {
        SharedPreferences sp = context.getSharedPreferences("gcm_reg_id", Context.MODE_PRIVATE);
        return sp.getString("regid", null);
    }

    public static float getCurrentVersion(Context context)
    {
        SharedPreferences sp = context.getSharedPreferences("app_version", Context.MODE_PRIVATE);
        return sp.getFloat("version",Utils.getCurrentVersionCode(context));
    }
    public static void setCurrentVersion(Context context) {
        SharedPreferences sp = context.getSharedPreferences("app_version", Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        editor.putFloat("version", Utils.getCurrentVersionCode(context));
        editor.commit();
    }

    public static void setStartLocation(Context mContext, Region area) {
        SharedPreferences prefs = mContext.getSharedPreferences("basicProfile", 0);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("startLocation", new Gson().toJson(area));
        editor.commit();
    }

    public static void setEndLocation(Context mContext, Region area) {
        SharedPreferences prefs = mContext.getSharedPreferences("basicProfile", 0);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("endLocation", new Gson().toJson(area));
        editor.commit();
    }

    public static Region getStartLocation(Context mContext) {
        SharedPreferences prefs = mContext.getSharedPreferences("basicProfile", 0);
        if(prefs.contains("startLocation")) {
            return new Gson().fromJson(prefs.getString("startLocation", new Gson().toJson(Utils.getDefaultRegion(mContext))), Region.class);
        }
        return null;
    }

    public static Region getEndLocation(Context mContext) {
        SharedPreferences prefs = mContext.getSharedPreferences("basicProfile", 0);
        if(prefs.contains("endLocation")) {
            return new Gson().fromJson(prefs.getString("endLocation", new Gson().toJson(Utils.getDefaultRegion(mContext))), Region.class);
        }
        return null;
    }
}