package com.strollup.utility;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.location.Address;
import android.location.Geocoder;
import android.location.LocationManager;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.strollup.filter.Region;
import com.strollup.login.UserDto;
import com.strollup.main.AppController;
import com.strollup.main.FacebookShare;
import com.strollup.main.SplashScreen;
import com.strollup.model.location.TextValPair;

import org.apache.commons.lang3.StringEscapeUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Type;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import in.strollup.android.R;

public class Utils {

    public static final String SAVED_DATE_FORMAT = "MMM dd, yyyy hh:mm:ss a";

    public static String getTimeEstimated(String distance) {
        double time = 3.5;
        if (distance.contains("km")) {
            distance = distance.replace(" km", "");
            time = Double.parseDouble(distance) * time;

        } else if (distance.contains("m")) {
            distance = distance.replace(" m", "");
            time = (Double.parseDouble(distance) * time) / 1000;
        }
        if (time < 5.0) {
            time = 5.0;
        }
        int timeInt = (int) time;
        if (timeInt < 60) {
            return timeInt + " mins";
        } else if (timeInt % 60 != 0) {
            return (timeInt / 60) + " hrs " + timeInt % 60 + " mins";
        } else {
            return (timeInt / 60) + " hrs";
        }
    }

    public static String getDistanceFromLatAndLong(String latt1, String latt2, String long1, String long2) {

        double lat1 = Double.parseDouble(latt1);
        double lat2 = Double.parseDouble(latt2);
        double lon1 = Double.parseDouble(long1);
        double lon2 = Double.parseDouble(long2);
        final int R = 6371; // Radius of the earth
        Double latDistance = Math.toRadians(lat2 - lat1);
        Double lonDistance = Math.toRadians(lon2 - lon1);
        Double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2) + Math.cos(Math.toRadians(lat1))
                * Math.cos(Math.toRadians(lat2)) * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        Double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double distance = R * c * 1000; // convert to meters
        distance = distance * 1.3;
        return getTextFromValue(distance);
    }

    public static String getTextFromValue(double value) {
        double meters = 0;
        double kilometers = 0;
        if (value < 1000) {
            meters = value;
            if (meters < 50) {
                meters = 50;
            }
            DecimalFormat df = new DecimalFormat("#");
            meters = Double.parseDouble(df.format(meters));
            return String.valueOf(meters) + " m";
        } else {
            kilometers = value / 1000.0;
            DecimalFormat df = new DecimalFormat("#.#");
            kilometers = Double.parseDouble(df.format(kilometers));
            return String.valueOf(kilometers) + " km";
        }
    }

    public static final String correctJson(String responseJsonString) {
        if (responseJsonString != null) {
            if (responseJsonString.contains(":\"{") || responseJsonString.contains(":\"[")) {
                responseJsonString = responseJsonString.substring(0, responseJsonString.length() - 2);
                responseJsonString = responseJsonString + "}";
            }
            responseJsonString = responseJsonString.replace(":\"[", ":[");
            responseJsonString = responseJsonString.replace(":\"{", ":{");
            responseJsonString = responseJsonString.replace("\\\"", "\"");
            responseJsonString = StringEscapeUtils.unescapeJava(responseJsonString);
        }
        return responseJsonString;
    }

    public static boolean isGpsEnabled(Context context) {
        LocationManager locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        boolean isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);

        return isGPSEnabled;
    }

    public static void buildAlertMessageShareFacebook(final Context context) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(Constants.SHARE_US_ON_FACEBOOK).setCancelable(false).setTitle("Thank you " + AppPreferences.getUsername(context))
                .setPositiveButton("Share", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog,
                                        @SuppressWarnings("unused") final int id) {

                        Intent i = new Intent(context, FacebookShare.class);
                        context.startActivity(i);

                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                dialog.cancel();
            }
        });

        final AlertDialog alert = builder.create();
        alert.show();
    }

    public static void buildAlertMessageNoGps(final Context context) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(Constants.ENABLE_GPS_MESSAGE).setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog,
                                        @SuppressWarnings("unused") final int id) {
                        context.startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                dialog.cancel();
            }
        });

        final AlertDialog alert = builder.create();
        alert.show();
    }

    public static String urlParser(String url) {
        return url.replace(" ", "%20");
    }

    public static void noNetworkMessage(final Context context, final GsonRequest<?> req) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(Constants.NO_NETWORK_FOUND).setCancelable(false)
                .setPositiveButton(" Try again ", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog,
                                        @SuppressWarnings("unused") final int id) {
                        AppController.getInstance().addToRequestQueue(req);

                    }
                });
        final AlertDialog alert = builder.create();
        if (context instanceof Activity) {
            Activity acti = (Activity) context;
            if (SplashScreen.isError == false && !(acti.isFinishing())) {
                alert.show();
            }
        }
    }

    public static void noNetworkMessageSplashScreen(final Context context, final GsonRequest<?> req) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(Constants.NO_NETWORK_FOUND).setCancelable(false)
                .setPositiveButton("Try again", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog,
                                        @SuppressWarnings("unused") final int id) {
                        Activity act = (Activity) context;
                        Intent i = new Intent(context, SplashScreen.class);
                        context.startActivity(i);
                        act.finish();
                    }
                });
        final AlertDialog alert = builder.create();
        Activity acti = (Activity) context;
        if (SplashScreen.isError == false && !(acti.isFinishing())) {
            alert.show();
        }
    }

    public static Region getNearByRegion(Context context) {
        if (Globals.currentGpsLocation != null) {
            return Globals.currentGpsLocation;
        }
        GPSTracker gps = new GPSTracker(context);
        Double latitude = gps.getLatitude();
        Double longitude = gps.getLongitude();
        Geocoder gcd = new Geocoder(context, Locale.getDefault());
        List<Address> addresses = null;
        String cityName = null;
        try {
            addresses = gcd.getFromLocation(latitude, longitude, 1);
            if (addresses != null && addresses.size() > 0) {
                cityName = addresses.get(0).getSubLocality();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        Region nearMyLocationArea = new Region(cityName, String.valueOf(latitude), String.valueOf(longitude));
        if (cityName == null) {
            nearMyLocationArea.setArea(Utils.getDefaultArea(context));
            nearMyLocationArea.setLatitude(Utils.getDefaultAreaLatitude(context));
            nearMyLocationArea.setLongitude(Utils.getDefaultAreaLongitude(context));
        }
        Globals.currentGpsLocation = nearMyLocationArea;
        return nearMyLocationArea;
    }

    public static <T> Object getCachedResponse(Class<T> clazz, String response) throws Exception {
        try {
            response = Utils.correctJson(response);
            return new Gson().fromJson(response, clazz);
        } catch (Exception e) {
            throw e;
        }
    }

    public static <T> Object getCachedResponse(Class<T> clazz, String response, Map<Type, Object> adapterMap) throws Exception {
        try {
            response = Utils.correctJson(response);
            GsonBuilder builder = new GsonBuilder();
            for (Type type : adapterMap.keySet()) {
                builder.registerTypeAdapter(type, adapterMap.get(type));
            }
            Gson mGson = builder.disableHtmlEscaping().create();
            return mGson.fromJson(response, clazz);
        } catch (Exception e) {
            throw e;
        }
    }

    public static String getProperDate(String date) {
        if (date == null) {
            return null;
        }
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat format2 = new SimpleDateFormat("dd MMM");
        String properDate = "";
        try {
            properDate = format2.format(format1.parse(date));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return properDate;
    }

    public static String getDateString(String date) {
        String result = null;
        Date finalDate;
        String day = null;
        String dayOfTheWeek = null;
        String stringMonth = null;
        String intMonth = null; //06


        Calendar c = Calendar.getInstance();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        try {

            finalDate = format.parse(date);

            dayOfTheWeek = (String) android.text.format.DateFormat.format("EEE", finalDate);

            day = (String) android.text.format.DateFormat.format("dd", finalDate);
            stringMonth = (String) android.text.format.DateFormat.format("MMM", finalDate);
            intMonth = (String) android.text.format.DateFormat.format("MM", finalDate);


        } catch (ParseException e) {
            e.printStackTrace();
        }
        String todaysDate = format.format(c.getTime());
        c.add(Calendar.DATE, 1);
        String tomorrowDate = format.format(c.getTime());
        if (todaysDate.equals(date)) {
            result = "Today, " + day + " " + stringMonth;
        } else {
            result = dayOfTheWeek + ", " + day + " " + stringMonth;
        }

        return result;


    }

    public static String getSavedProperDate(String date) {
        if (date == null) {
            return null;
        }
        SimpleDateFormat format1 = new SimpleDateFormat(SAVED_DATE_FORMAT);
        SimpleDateFormat format2 = new SimpleDateFormat("dd MMM");
        String properDate = "";
        try {
            properDate = format2.format(format1.parse(date));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return properDate;
    }

    public static String generateShareUrl(Context context, int groupId, String region, String name, int id,
                                          int activityId) {
        String shareUrl = null;
        if (id != -1) {

            Map<Integer, String> cityName = Constants.CITY_URL_NAME;
            int cityId = AppPreferences.getCityId(context);
            String city = cityName.get(cityId);
            Map<Integer, String> groupMap = Constants.GROUPURL_NAME;
            String group = groupMap.get(groupId);
            String regionNameId = region + " " + name + " " + id;

            shareUrl = "http://www.strollup.in/#!/" + city + "/" + group + "/" + regionNameId;
            shareUrl = shareUrl.replace(" ", "-");

        } else {

            Map<Integer, String> cityName = Constants.CITY_URL_NAME;
            int cityId = AppPreferences.getCityId(context);
            String city = cityName.get(cityId);
            Map<Integer, String> groupMap = Constants.GROUPURL_NAME;
            String group = groupMap.get(groupId);
            String regionNameId = name + " " + activityId;
            shareUrl = "http://www.strollup.in/#!/" + city + "/" + group + "/" + regionNameId;
            shareUrl = shareUrl.replace(" ", "-");

        }

        return shareUrl;

    }

    public static String getProperDateWithYear(int ahead) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String properDate = format.format(getXDayAheadDate(ahead));
        return properDate;
    }

    public static String getProperDate(int ahead) {
        SimpleDateFormat format = new SimpleDateFormat("dd MMM");
        String properDate = format.format(getXDayAheadDate(ahead));
        return properDate;
    }

    public static String getDay(int ahead) {
        SimpleDateFormat format = new SimpleDateFormat("EE");
        String day = format.format(getXDayAheadDate(ahead));
        return day;

    }

    public static Date getXDayAheadDate(int ahead) {
        final Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.DAY_OF_YEAR, ahead);
        return calendar.getTime();
    }

    public static String[] getArrayOfWhenOptions() {
        String arr[] = new String[5];
        arr[0] = "Today, " + Utils.getProperDate(0);
        arr[1] = "Tomorrow, " + Utils.getProperDate(1);
        for (int i = 2; i < 5; i++) {
            String day = Utils.getDay(i);
            arr[i] = day + ", " + Utils.getProperDate(i);
        }
        return arr;
    }

    public static Bitmap getScreenShot(View view) {
        View screenView = view.getRootView();
        screenView.setDrawingCacheEnabled(true);
        Bitmap bitmap = Bitmap.createBitmap(screenView.getDrawingCache());
        screenView.setDrawingCacheEnabled(false);
        return bitmap;
    }

    public static void store(Context context, Bitmap bm) {
        int screenshotNumber = 0;
        String tempFileName = "screenshot-";
        String fileName = "";
        String dirs = Environment.getExternalStorageDirectory() + "/StrollUp";
        File dir = new File(dirs);
        if (!dir.exists())
            dir.mkdirs();
        File file = null;
        do {
            screenshotNumber++;
            fileName = tempFileName + screenshotNumber + ".jpg";
            file = new File(dir, fileName);
        } while(file.exists());

        try {
            file.createNewFile();
            FileOutputStream fOut = new FileOutputStream(file);
            boolean isSaved = bm.compress(Bitmap.CompressFormat.JPEG, 85, fOut);
            if (isSaved) {
                Toast.makeText(context, "Image saved to your device", Toast.LENGTH_SHORT).show();
            }
            fOut.flush();
            fOut.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Region getDefaultRegion(Context mContext) {
        return new Region(Constants.DEFAULT_AREA.get(AppPreferences.getCityId(mContext)), Constants.DEFAULT_AREA_LATITUDE.get(AppPreferences.getCityId(mContext)), Constants.DEFAULT_AREA_LONGITUDE.get(AppPreferences.getCityId(mContext)));
    }

    public static String getDefaultArea(Context mContext) {
        return Constants.DEFAULT_AREA.get(AppPreferences.getCityId(mContext));
    }

    public static String getDefaultAreaLatitude(Context mContext) {
        return Constants.DEFAULT_AREA_LATITUDE.get(AppPreferences.getCityId(mContext));
    }

    public static String getDefaultAreaLongitude(Context mContext) {
        return Constants.DEFAULT_AREA_LONGITUDE.get(AppPreferences.getCityId(mContext));
    }

    public static void selectButton(final Button button, final Resources resources) {
        button.setBackgroundResource(R.drawable.button_green);
        button.setTextColor(resources.getColor(R.color.white));
    }

    public static void unselectButton(final Button button, final Resources resources) {
        button.setBackgroundResource(R.drawable.button_white);
        button.setTextColor(resources.getColor(R.color.green));
    }

    public static HashMap<String, Integer> getHashMapFromTextValPairList(List<TextValPair> activityTagsList) {
        HashMap<String, Integer> IdToVal = new HashMap<String, Integer>();
        if (activityTagsList != null) {
            for (int i = 0; i < activityTagsList.size(); i++) {
                Integer val = activityTagsList.get(i).getValue();
                String text = activityTagsList.get(i).getText();
                IdToVal.put(text, val);
            }
        }
        return IdToVal;
    }

    public static String getFbLoginUrl(UserDto userDto) {
        StringBuilder sb = new StringBuilder();
        sb.append(Constants.BASE_SERVER_URL
                + "loginMobileUserWithFB?facebookUserString={\"type\"=\"FBUserDto\",\"properties\"={\"registerType\"={\"name\"=\"FACEBOOK\"},\"name\"=\"");
        sb.append(userDto.getName());
        sb.append("\",\"email\"=\"");
        sb.append(userDto.getEmail());
        sb.append("\",\"userProfile\"={\"properties\"={\"picture\"=\"");
        sb.append(userDto.getPhoto());
        sb.append("\"}},\"status\"={\"properties\"={},\"type\"=\"FBStatusDto\"}}}");
        String url = sb.toString().replaceAll(" ", "%20");
        return url;
    }

    public static String getGPlusLoginUrl(UserDto userDto) {
        StringBuilder sb = new StringBuilder();
        sb.append(Constants.BASE_SERVER_URL
                + "loginMobileUserWithGPlus?gPlusUserDtoString={\"type\"=\"GPlusUserDto\",\"properties\"={\"registerType\"={\"name\"=\"GOOGLE_PLUS\"},\"name\"=\"");
        sb.append(userDto.getName());
        sb.append("\",\"email\"=\"");
        sb.append(userDto.getEmail());
        sb.append("\",\"userProfile\"={\"properties\"={\"picture\"=\"");
        sb.append(userDto.getPhoto());
        sb.append("\"}},\"status\"={\"properties\"={},\"type\"=\"GPlusStatusDto\"}}}");
        String url = sb.toString().replaceAll(" ", "%20");
        return url;
    }

    public static String getStrollUpLoginUrl(String emailId, String pass) {
        String url = Constants.BASE_SERVER_URL
                + "loginMobileStrollUpUser?strollUpUserDtoString={\"type\"=\"StrollUpUserDto\",\"properties\"={\"registerType\"={\"name\"=\"STROLLUP\"},\"email\"=\""
                + emailId + "\"," + "\"password\":\"" + pass + "\"}}";
        return url;
    }

    public static String getMd5Password(String password) {
        MessageDigest m = null;
        try {
            m = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        m.reset();
        m.update(password.getBytes());
        byte[] digest = m.digest();
        BigInteger bigInt = new BigInteger(1, digest);
        String passwordMd5 = bigInt.toString(16);
        while (passwordMd5.length() < 32) {
            passwordMd5 = "0" + passwordMd5;
        }
        return passwordMd5;
    }

    public static String getCurrentVersionName(Context context) {
        PackageInfo pInfo = null;
        try {
            pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        String currentVersion = (String) pInfo.versionName;
        return currentVersion;
    }

    public static float getCurrentVersionCode(Context context) {
        PackageInfo pInfo = null;
        try {
            pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        float currentVersion = (float) pInfo.versionCode;
        return currentVersion;
    }
}
