package com.strollup.model.location;

import java.util.List;


public class ShowDetail {
    private String showTime;
    private List<TextValPair> costs;

    public String getShowTime() {
        return showTime;
    }

    public void setShowTime(String showTime) {
        this.showTime = showTime;
    }

    public List<TextValPair> getCosts() {
        return costs;
    }

    public void setCosts(List<TextValPair> costs) {
        this.costs = costs;
    }
}
