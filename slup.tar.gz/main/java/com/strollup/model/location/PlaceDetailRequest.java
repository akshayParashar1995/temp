package com.strollup.model.location;

import android.content.Context;

import com.strollup.request.ActivityLocation;
import com.strollup.request.BaseRequest;

public class PlaceDetailRequest extends BaseRequest{

	
	private ActivityLocation activityLocation;
	public PlaceDetailRequest(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}
	public ActivityLocation getActivityLocation() {
		return activityLocation;
	}
	public void setActivityLocation(ActivityLocation activityLocation) {
		this.activityLocation = activityLocation;
	}

}
