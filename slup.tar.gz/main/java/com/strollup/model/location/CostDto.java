package com.strollup.model.location;

/**
 * Created by ankurgupta on 7/23/2015.
 */
public class CostDto {
    private String text;
    private int value;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
}
