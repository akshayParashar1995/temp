package com.strollup.model.location;


import java.io.Serializable;

/**
 * This object can be used to populate the DATA table entries like LOCATION_DETAIL_DATA, ACTIVITY_DETAIL_DATA
 *
 * @author AKSHAY
 */
public class DetailData  implements Serializable{

    private int priority;
    private String key;
    private String value;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }


    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }
}
