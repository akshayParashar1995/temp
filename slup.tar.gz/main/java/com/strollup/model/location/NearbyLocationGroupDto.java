package com.strollup.model.location;

import java.util.List;

public class NearbyLocationGroupDto {

	private String group;
	private List<NearbyLocationDto> nearByLocations;

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public List<NearbyLocationDto> getNearByLocations() {
		return nearByLocations;
	}

	public void setNearByLocations(List<NearbyLocationDto> nearByLocations) {
		this.nearByLocations = nearByLocations;
	}

}
