package com.strollup.model.location;

import com.strollup.utility.Constants;
import com.strollup.utility.Utils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class LocationDto implements Serializable{

    private String address;
    private double rating;
    private int id;
    private int activityId;
    private String releaseDate;
    private int duration;
    private String name;
    private String image;
    private List<TagDto> tags;
    private String displayTime;
    private String description;
    private String smallDescription;
    private String region;
    private String cost;
    private String contact;
    private String latitude;
    private String longitude;
    private String cast;
    private int groupId;
    private int franchiseCount;
    private List<String> images;
    private List<DetailData> detailData;
    private String date;
    private String eventTime;
    private List<EventDto> events;

    public List<DetailData> getDetailData() {
        return detailData;
    }

    public void setDetailData(List<DetailData> detailData) {
        this.detailData = detailData;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getActivityId() {
        return activityId;
    }

    public void setActivityId(int activityId) {
        this.activityId = activityId;
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public String getReleaseDate() {
        return Utils.getProperDate(releaseDate);
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return getImageUrl(image);
    }

    public String getImageUrl(String image) {
        if (groupId == Constants.MOVIE_GROUP_ID || groupId == Constants.EVENT_ID) {
            return (Constants.BASE_LOCATION_IMAGE_URL + image).replace(" ", "%20").replace("é", "&#233");
        }
        return (Constants.BASE_LOCATION_IMAGE_URL + name + "/" + image).replace(" ", "%20").replace("é", "&#233");
    }

    public void setImage(String image) {
        this.image = image;
    }


    public String getSmallDescription() {
        return smallDescription;
    }

    public void setSmallDescription(String smallDescription) {
        this.smallDescription = smallDescription;
    }

    public String getRegion() {
        if (groupId == Constants.MOVIE_GROUP_ID) {
            return "Released on " + getReleaseDate();
        }
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCost() {
        return cost;
    }

    public String getCostText() {
        if (groupId == Constants.MOVIE_GROUP_ID) {
            return String.valueOf(duration / 60) + " hrs " + String.valueOf(duration % 60) + " mins";
        } else if(groupId == Constants.EVENT_ID) {
            return Utils.getDateString(date) + "\n" + eventTime;
        }
        if (cost.equals("0")) {
            return "Free";
        }
        return "Rs. " + cost + " per head";
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    public int getFranchiseCount() {
        return franchiseCount;
    }

    public void setFranchiseCount(int franchiseCount) {
        this.franchiseCount = franchiseCount;
    }

    public String getDisplayTime() {
        if (displayTime == null) {
            return "Not Available";
        }
        return displayTime;
    }

    public void setDisplayTime(String displayTime) {
        this.displayTime = displayTime;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTagsString() {
        String tagString = "";
        if (tags == null || tags.isEmpty()) {
            return tagString;
        }
        for (TagDto tag : tags) {
            if (tag.getPriority() != 0) {
                tagString = tagString + tag.getName() + ", ";
            }
        }
        if (tagString.lastIndexOf(",") == tagString.length() - 2) {
            tagString = tagString.substring(0, tagString.length() - 2);
        }
        return tagString;
    }

    public List<TagDto> getTags() {
        return tags;
    }

    public void setTags(List<TagDto> tags) {
        this.tags = tags;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getRating() {
        String rating = String.valueOf(this.rating * 2);
        int rIndex = rating.indexOf(".");
        if (rIndex > -1) {
            return rating.substring(0, rIndex);
        }
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public String getCast() {
        return cast;
    }

    public void setCast(String cast) {
        this.cast = cast;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public List<String> getImages() {
        List<String> urlImages = new ArrayList<>();
        if (images == null) {
            return urlImages;
        }
        for (String image : images) {
            urlImages.add(getImageUrl(image));
        }
        return urlImages;
    }

    public void setImages(List<String> images) {
        this.images = images;
    }

    public List<EventDto> getEvents() {
        return events;
    }

    public void setEvents(List<EventDto> events) {
        this.events = events;
    }

    public String getEventTime() {
        return eventTime;
    }

    public void setEventTime(String eventTime) {
        this.eventTime = eventTime;
    }
}