package com.strollup.model.location;

import java.util.List;
import java.util.Map;

public class LocationData {

    private List<LocationDto> similarLocations;
    private LocationDto location;
    private List<NearbyLocationGroupDto> nearByLocations;
    private Map<String, Map<String, List<TextValPair>>> dateMovieShowTimeInfo;
    private Map<String, List<ShowDetailDto>> dateShowDetailInfo;

    public List<LocationDto> getSimilarLocations() {
        return similarLocations;
    }

    public void setSimilarLocations(List<LocationDto> similarLocations) {
        this.similarLocations = similarLocations;
    }

    public List<NearbyLocationGroupDto> getNearByLocations() {
        return nearByLocations;
    }

    public void setNearByLocations(List<NearbyLocationGroupDto> nearByLocations) {
        this.nearByLocations = nearByLocations;
    }

    public LocationDto getLocation() {
        return location;
    }

    public Map<String, List<ShowDetailDto>> getDateShowDetailInfo() {
        return dateShowDetailInfo;
    }

    public void setDateShowDetailInfo(Map<String, List<ShowDetailDto>> dateShowDetailInfo) {
        this.dateShowDetailInfo = dateShowDetailInfo;
    }

    public void setLocation(LocationDto location) {
        this.location = location;
    }

    public Map<String, Map<String, List<TextValPair>>> getDateMovieShowTimeInfo() {
        return dateMovieShowTimeInfo;
    }

    public void setDateMovieShowTimeInfo(Map<String, Map<String, List<TextValPair>>> dateMovieShowTimeInfo) {
        this.dateMovieShowTimeInfo = dateMovieShowTimeInfo;
    }
}
