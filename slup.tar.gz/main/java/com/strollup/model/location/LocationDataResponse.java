package com.strollup.model.location;

public class LocationDataResponse {

	private LocationData locationDataResponseString;

	public LocationData getLocationDataResponseString() {
		return locationDataResponseString;
	}

	public void setLocationDataResponseString(LocationData locationDataResponseString) {
		this.locationDataResponseString = locationDataResponseString;
	}

}
