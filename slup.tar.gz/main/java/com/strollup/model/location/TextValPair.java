package com.strollup.model.location;

public class TextValPair {
	
	private String text;
	private int value;

	public String getText() {
		return text;
	}

	public int getValue() {
		return value;
	}

	public void setText(String text) {
		this.text = text;
	}

	public void setValue(int value) {
		this.value = value;
	}
}
