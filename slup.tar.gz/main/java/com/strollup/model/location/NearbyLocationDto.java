package com.strollup.model.location;

public class NearbyLocationDto {
	private float distance;
	private LocationDto location;

	public float getDistance() {
		return distance;
	}

	public void setDistance(float distance) {
		this.distance = distance;
	}

	public LocationDto getLocation() {
		return location;
	}

	public void setLocation(LocationDto location) {
		this.location = location;
	}

}
