package com.strollup.model.location;

import java.util.ArrayList;
import java.util.List;

public class ShowDetailDto extends TextValPair {

    private List<ShowDetail> showDetails = new ArrayList<>();

    public List<ShowDetail> getShowDetails() {
        return showDetails;
    }

    public void setShowDetails(List<ShowDetail> showDetails) {
        this.showDetails = showDetails;
    }

    public void add(ShowDetail showDetail) {
        showDetails.add(showDetail);
    }
}
