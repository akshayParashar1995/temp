package com.strollup.update;

public class VersionDataResponse {
	private VersionDto versionString;

	public VersionDto getVersionString() {
		return versionString;
	}

	public void setVersionString(VersionDto versionString) {
		this.versionString = versionString;
	}

}