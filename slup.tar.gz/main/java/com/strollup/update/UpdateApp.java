package com.strollup.update;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.strollup.main.SplashScreen;
import com.strollup.utility.AppPreferences;
import com.strollup.utility.Constants;

import in.strollup.android.R;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class UpdateApp extends Activity implements OnClickListener {

	private Button update;
	private TextView whatsNew, close;
	private String version_name;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_update_app);
		update = (Button) findViewById(R.id.update);
		close = (TextView) findViewById(R.id.close);
		whatsNew = (TextView) findViewById(R.id.whats_new);
		Bundle b = getIntent().getExtras();
		if (b != null) {
			String whats_new = b.getString("whats_new");
			version_name = b.getString("version_name");
			whatsNew.setText(whats_new);
		}
		update.setOnClickListener(this);
		close.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.update:
			AppPreferences.setIsWillingToUpdateToFalse(getApplicationContext(), version_name);
			try {
				startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(Constants.PLAY_STORE_MARKET_URL
						+ Constants.PACKAGE_NAME)));
			} catch (ActivityNotFoundException e) {
				startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(Constants.PLAY_STORE_BROWSER_URL
						+ Constants.PACKAGE_NAME)));
			}
			SplashScreen.decrementNoOfVolleyRequests();
			finish();
			break;
		case R.id.close:
			AppPreferences.setIsWillingToUpdateToFalse(getApplicationContext(), version_name);
			SplashScreen.decrementNoOfVolleyRequests();
			finish();
			break;
		}
	}

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}