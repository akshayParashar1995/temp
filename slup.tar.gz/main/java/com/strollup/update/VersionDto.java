package com.strollup.update;

import android.util.Log;

import com.strollup.utility.Constants;

import java.util.List;

public class VersionDto {
	private String releaseDate;
	private String whatsNew;
	private String name;
	private int id;
	private double rating;
    private List<ConstantsDto > constants;

    public List<ConstantsDto> getConstants() {
        return constants;
    }

    public void setConstants() {
        List<ConstantsDto > constants=this.constants;
        for(ConstantsDto constantsDto:constants){
            List<ConstantDto> constantDtos=constantsDto.getConstants();
            for(ConstantDto constantDto:constantDtos){
                Log.i("key:" + constantDto.getKey(), "value:" + constantDto.getValue());
                Constants.setKeyValue(constantDto.getKey(), constantDto.getValue());
            }
        }
    }
    public void setConstants(List<ConstantsDto> constants) {
        this.constants = constants;
    }

    public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public String getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getWhatsNew() {
		return whatsNew;
	}

	public void setWhatsNew(String whatsNew) {
		this.whatsNew = whatsNew;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}