package com.strollup.update;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.google.gson.Gson;
import com.strollup.main.AppController;
import com.strollup.main.SplashScreen;
import com.strollup.request.BaseRequest;
import com.strollup.utility.AppPreferences;
import com.strollup.utility.Constants;
import com.strollup.utility.GsonRequest;
import com.strollup.utility.Utils;

public class CheckForUpdates {

	private Context context;
	private Activity act;
	private GsonRequest<VersionDataResponse> myReq;

	public void checkIfThereIsAnyUpdate(Context cont, Activity acti) {
		context = cont;
		act = acti;
		BaseRequest baseRequest = new BaseRequest(context);
		String versionUrl = Constants.BASE_SERVER_URL + "getLatestVesion?baseRequestString="
				+ new Gson().toJson(baseRequest);
		myReq = new GsonRequest<VersionDataResponse>(Request.Method.GET, versionUrl, VersionDataResponse.class,
				createMyReqSuccessListener(), createMyReqErrorListener());
		myReq.setSequence(1);
		AppController.getInstance().getRequestQueue().add(myReq);
		SplashScreen.incrementNoOfVolleyRequests();
	}

	private Response.Listener<VersionDataResponse> createMyReqSuccessListener() {
		return new Response.Listener<VersionDataResponse>() {
			@Override
			public void onResponse(VersionDataResponse versionDataResponse) {
				try {
					VersionDto v = versionDataResponse.getVersionString();
                    v.setConstants();
					float latestVersion = Float.parseFloat(v.getName());
					float currentVersion = Utils.getCurrentVersionCode(context);
					boolean isWillingToUpdate = AppPreferences.getIsWillingToUpdate(context, latestVersion);
					if (currentVersion < latestVersion && isWillingToUpdate) {
						Intent intent = new Intent(context, UpdateApp.class);
						intent.putExtra("whats_new", v.getWhatsNew());
						intent.putExtra("version_name", v.getName());
						intent.putExtra("release_date", v.getReleaseDate());
						intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
						act.startActivity(intent);
					} else {
						SplashScreen.decrementNoOfVolleyRequests();
					}
				} catch (Exception e) {
					e.printStackTrace();
					SplashScreen.decrementNoOfVolleyRequests();
				}
			}
		};
	}

	private Response.ErrorListener createMyReqErrorListener() {
		return new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {
				Log.e("Error", "Error occured", error.getCause());
				if (error instanceof NoConnectionError || error instanceof TimeoutError)
					Utils.noNetworkMessageSplashScreen(act, myReq);
				SplashScreen.setBooleanTrue();
			}
		};
	}
}