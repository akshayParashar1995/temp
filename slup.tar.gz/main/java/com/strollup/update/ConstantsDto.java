package com.strollup.update;

import java.util.List;

/**
 * Created by Akshay on 06-07-2015.
 */
public class ConstantsDto {
    private String context;

    private List<ConstantDto> constants;

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }

    public List<ConstantDto> getConstants() {
        return constants;
    }

    public void setConstants(List<ConstantDto> constants) {
        this.constants = constants;
    }
}
