package com.strollup.activity;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.android.volley.Cache;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.google.gson.Gson;
import com.strollup.main.AppController;
import com.strollup.main.ExploreTabListing;
import com.strollup.request.ActivityTypeRequest;
import com.strollup.utility.Constants;
import com.strollup.utility.GsonRequest;
import com.strollup.utility.Utils;

/**
 * Created by Akshay on 12-07-2015.
 */
public class ActivityTypeController {

    private Activity activity;
    private Context context;
    private String tag;
    private Object object;
    private GsonRequest<ActivityDataResponse> myReq;

    public  ActivityTypeController(Object object,Activity activity,Context context,String tag){
        this.activity=activity;
        this.object=object;
        this.context=context;
        this.tag=tag;
    }
    public void fetchActivityTypes(){
        ActivityTypeRequest activityTypeRequest = new ActivityTypeRequest(context);
        String url = Constants.BASE_SERVER_URL + "fetchActivityList?activityListRequestString="
                + new Gson().toJson(activityTypeRequest);
        loadContent(url);
    }
    private void loadContent(String url) {
        Cache cache = AppController.getInstance().getRequestQueue().getCache();
        Cache.Entry entry = cache.get(url);
        if (entry != null && entry.serverDate + Constants.BIG_CACHE_EXPIRY_TIME > System.currentTimeMillis()) {
            try {
                String data = new String(entry.data, "UTF-8");
                ActivityDataResponse activityDataResponse = (ActivityDataResponse) Utils.getCachedResponse(
                        ActivityDataResponse.class, data);
                success(activityDataResponse);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            AppController.getInstance().getRequestQueue().getCache().invalidate(url, true);
            myReq = new GsonRequest<ActivityDataResponse>(Request.Method.GET, url, ActivityDataResponse.class,
                    createMyReqSuccessListener(), createMyReqErrorListener());
            AppController.getInstance().addToRequestQueue(myReq);
        }

    }
        private Response.Listener<ActivityDataResponse> createMyReqSuccessListener(){
            return new Response.Listener<ActivityDataResponse>() {
                @Override
                public void onResponse(ActivityDataResponse activityResult) {
                    success(activityResult);
                }
            };
        }

    private Response.ErrorListener createMyReqErrorListener() {
        return new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("ActivityTypeController", "Error Occured while calling backend", error.getCause());
                if (error instanceof NoConnectionError || error instanceof TimeoutError)
                    Utils.noNetworkMessage(activity, myReq);
            }
        };
    }

    private void success(ActivityDataResponse activityDataResponse) {
        if(tag.equals("ActivityFragment")){
            ((ActivityFragment)object).onSuccess(activityDataResponse);
        }
        else if(tag.equals("ExploreTabListing")){
            ((ExploreTabListing)object).success(activityDataResponse);
        }
    }
}


