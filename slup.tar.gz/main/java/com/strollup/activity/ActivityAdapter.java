package com.strollup.activity;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.koushikdutta.ion.Ion;

import in.strollup.android.R;

public class ActivityAdapter extends ArrayAdapter<ActivityTypeDto> {

    private final LayoutInflater inflater;
    private Context context;

    public ActivityAdapter(Context context, int resource, ActivityTypeDto[] objects, GridView gridView) {
        super(context, resource, objects);
        this.context = context;
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.activity_list_single_item, null);
            viewHolder = new ViewHolder();

            viewHolder.title = (TextView) convertView.findViewById(R.id.activity_text);
            viewHolder.image = (ImageView) convertView.findViewById(R.id.activity_image);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        ActivityTypeDto activityTypeDto = getItem(position);
        viewHolder.title.setText(activityTypeDto.getName());

        if (viewHolder.image.getTag() == null ||
                !viewHolder.image.getTag().equals(activityTypeDto.getImage())) {

            Ion.with(viewHolder.image)
                    .placeholder(R.drawable.preloader)
                    .error(R.drawable.error_image)
                    .load(activityTypeDto.getImage());

            viewHolder.image.setTag(activityTypeDto.getImage());
        }

        return convertView;
    }

    private static class ViewHolder {
        protected TextView title;
        protected ImageView image;
    }
}