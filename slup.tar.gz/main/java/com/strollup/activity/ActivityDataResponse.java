package com.strollup.activity;

import java.util.ArrayList;
import java.util.List;

public class ActivityDataResponse {

	private List<ActivityTypeDto> activityTypeStrings = new ArrayList<ActivityTypeDto>();

	public List<ActivityTypeDto> getActivityTypeStrings() {
		return activityTypeStrings;
	}

	public void setActivityTypeStrings(List<ActivityTypeDto> activityTypeStrings) {
		this.activityTypeStrings = activityTypeStrings;
	}

}
