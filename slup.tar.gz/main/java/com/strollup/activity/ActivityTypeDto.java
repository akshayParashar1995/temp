package com.strollup.activity;

import com.strollup.utility.Constants;

import java.util.List;

public class ActivityTypeDto implements Comparable<ActivityTypeDto> {

	private String name;

	private String image;

	private String group;

	private int priority;

	private int id;

	private int locationCount;

	private List<ActivityDto> activities;

	public ActivityTypeDto(String name, int id, String image) {
		this.name = name;
		this.id = id;
		this.image = image;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getImage() {
		return (Constants.BASE_IMAGE_URL + image).replace(" ","%20").replace("é","&#233");
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getLocationCount() {
		return locationCount;
	}

	public void setLocationCount(int locationCount) {
		this.locationCount = locationCount;
	}

	public List<ActivityDto> getActivities() {
		return activities;
	}

	public void setActivities(List<ActivityDto> activities) {
		this.activities = activities;
	}

	@Override
	public int compareTo(ActivityTypeDto obj) {
		if (this.getPriority() < obj.getPriority()) {
			return 1;
		} else if (this.getPriority() > obj.getPriority()) {
			return -1;
		}
		return 0;
	}
}