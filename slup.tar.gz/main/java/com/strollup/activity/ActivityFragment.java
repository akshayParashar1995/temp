package com.strollup.activity;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.ProgressBar;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;
import com.android.volley.Cache;
import com.android.volley.Cache.Entry;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.getbase.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.strollup.floating_action_button.InviteFriends;
import com.strollup.main.AppController;
import com.strollup.main.ExploreTabListing;
import com.strollup.utility.Constants;
import com.strollup.utility.Globals;
import com.strollup.utility.GsonRequest;

import java.util.Collections;
import java.util.List;

import in.strollup.android.BuildConfig;
import in.strollup.android.R;

public class ActivityFragment extends Fragment {

    private View view;
    private GsonRequest<ActivityDataResponse> myReq;
    private ProgressBar mprogressBar;
    private static final String TAG = ActivityFragment.class.getSimpleName();
    private FloatingActionButton floatingActionButton;

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.activities_grid, container, false);
        mprogressBar = (ProgressBar) view.findViewById(R.id.progressBar);
        mprogressBar.setVisibility(View.VISIBLE);
        new ActivityTypeController(this, getActivity(),getActivity().getApplicationContext(),"ActivityFragment").fetchActivityTypes();
        return view;
    }
    public void onSuccess(ActivityDataResponse activityResult) {
        try {
            Globals.activityResult = activityResult;
            mprogressBar.setVisibility(View.INVISIBLE);
            List<ActivityTypeDto> activityTypes = activityResult.getActivityTypeStrings();
            Collections.sort(activityTypes);

            final ActivityTypeDto[] arr = new ActivityTypeDto[activityTypes.size()];
            for (int i = 0; i < activityTypes.size(); i++) {
                arr[i] = activityTypes.get(i);
            }
            int size = activityTypes.size();
            GridView gv = (GridView) view.findViewById((int) R.id.activity_grid);
            floatingActionButton = (FloatingActionButton)view.findViewById(R.id.floating_explore);
            floatingActionButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(getActivity(),InviteFriends.class);
                    getActivity().startActivity(intent);
                }
            });
            ActivityAdapter adapter = new ActivityAdapter(getActivity(), 0, arr, gv);
            gv.setAdapter(adapter);

            gv.setOnItemClickListener(new OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> gv, View arg1, int position, long arg3) {
                    gv.setEnabled(false);
                    Intent i = new Intent(getActivity(), ExploreTabListing.class);
                    ActivityTypeDto activityTypeDto = arr[position];
                    if (activityTypeDto.getId() >= 0) {
                        i.putExtra("activityTypeId", activityTypeDto.getId());
                        i.putExtra("tabPosition", position);
                        startActivity(i);
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!BuildConfig.DEBUG) {
            GoogleAnalytics analytics = GoogleAnalytics.getInstance(getActivity());
            Tracker tracker = analytics.newTracker(Constants.GOOGLE_ANALYTICS_URL);
            tracker.setScreenName("Explore");
            tracker.send(new HitBuilders.ScreenViewBuilder().build());
        }
        GridView gridView = (GridView) view.findViewById(R.id.activity_grid);
        gridView.setEnabled(true);
    }
}
