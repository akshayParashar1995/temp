package com.strollup.activity;

import java.util.ArrayList;
import java.util.List;

public class ActivityTagResponse {
	private List<TagDetailStrings> tagDetailStrings= new ArrayList<TagDetailStrings>();

	public List<TagDetailStrings> getTagDetailStrings() {
		return tagDetailStrings;
	}

	public void setTagDetailStrings(List<TagDetailStrings> tagDetailStrings) {
		this.tagDetailStrings = tagDetailStrings;
	}

}
