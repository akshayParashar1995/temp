package com.strollup.activity;

import com.strollup.model.location.TextValPair;

import java.util.List;

public class TagDetailStrings {
	String activityName;
	int activityId;
	List <TextValPair> activityTags;
	
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public int getActivityId() {
		return activityId;
	}
	public void setActivityId(int activityId) {
		this.activityId = activityId;
	}
	public List<TextValPair> getActivityTags() {
		return activityTags;
	}
	public void setActivityTags(List<TextValPair> activityTags) {
		this.activityTags = activityTags;
	}
	
}
