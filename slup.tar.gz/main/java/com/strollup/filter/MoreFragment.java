package com.strollup.filter;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.strollup.model.location.TextValPair;
import com.strollup.request.ActivityTagRequest;

import java.util.ArrayList;
import java.util.List;

import in.strollup.android.R;

@SuppressLint("ValidFragment")
public class MoreFragment extends Fragment {
	AllFilterString allFilterString;
	private FilterArrayAdapter adapter;
	private OnFilterChangedListener onFilterChangedListener;
	private int activityTypeId;
	private String TAG = MoreFragment.class.getSimpleName();
	private View view;
	private List<TextValPair> displayTags;

    public MoreFragment() {
    }

	public MoreFragment(AllFilterString allFilterString, OnFilterChangedListener onFilterChangedListener,
			int activityTypeId, List<TextValPair> displayTags) {
		this.onFilterChangedListener = onFilterChangedListener;
		this.allFilterString = allFilterString;
		this.activityTypeId = activityTypeId;
		this.displayTags = displayTags;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		ActivityTagRequest activityTagRequest = new ActivityTagRequest(getActivity().getApplicationContext());
		activityTagRequest.addActivityTypeIds(activityTypeId);

		view = inflater.inflate((Integer) R.layout.filter_display, container, false);
		ListView lv = (ListView) view.findViewById((int) R.id.listView1);
		lv.setPadding(2, 0, 2, 0);
		List<String> display = new ArrayList<String>();
		for (int i = 0; i < displayTags.size(); i++) {
			display.add(displayTags.get(i).getText());
		}

		adapter = new FilterArrayAdapter(getActivity().getApplicationContext(), 0, display, allFilterString, 6, lv,
				onFilterChangedListener, displayTags);
		lv.setAdapter(adapter);
		lv.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> gv, View arg1, int position, long arg3) {
				if (allFilterString == null)
					allFilterString = new AllFilterString(getActivity());
				TagFilter tagFilter = allFilterString.getTagFilter();
				if (tagFilter == null) {
					tagFilter = new TagFilter();
				}
				int selectedTagId = displayTags.get(position).getValue();
				List<Integer> tagIds = tagFilter.getTagIDs();
				if (tagIds == null) {
					tagIds = new ArrayList<Integer>();
				}
				if (tagIds.contains(selectedTagId)) {
					tagIds.remove((Integer) selectedTagId);
					tagFilter.setTagIDs(tagIds);
					adapter.setActivityTagList(displayTags);
				} else {
					tagFilter.addTagId(selectedTagId);
				}
				allFilterString.setTagFilter(tagFilter);
				adapter.notifyDataSetChanged();
			}
		});
		return view;

	}

	public void notifyDataChanged(List<TextValPair> displayTags) {
		this.displayTags = displayTags;
		List<String> display = new ArrayList<String>();
		for (int i = 0; i < displayTags.size(); i++) {
			display.add(displayTags.get(i).getText());
		}
		adapter.clear();
		adapter.addAll(display);
		adapter.setActivityTagList(displayTags);
		adapter.notifyDataSetChanged();
	}
}
