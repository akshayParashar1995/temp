package com.strollup.filter;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.strollup.utility.Constants;

import in.strollup.android.R;

@SuppressLint("ValidFragment")
public class SortFragment extends Fragment {
	AllFilterString allFilterString;
	private FilterArrayAdapter adapter;
	private OnFilterChangedListener onFilterChangedListener;

	public SortFragment(AllFilterString allFilterString, OnFilterChangedListener onFilterChangedListener) {
		this.onFilterChangedListener = onFilterChangedListener;
		this.allFilterString = allFilterString;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate((Integer) R.layout.filter_display, container, false);
		String arr[] = Constants.SORT_OPTIONS_FOR_PLACES;
		ListView lv = (ListView) view.findViewById((int) R.id.listView1);
		adapter = new FilterArrayAdapter(getActivity(), 0, arr, allFilterString, 5, lv, onFilterChangedListener, null);
		lv.setAdapter(adapter);
		lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> view, View arg1, int position, long arg3) {
				if (allFilterString == null)
					allFilterString = new AllFilterString(getActivity());
				String sortOption = allFilterString.getSortBy();
				if (sortOption == null) {
					sortOption = new String();
				}
				if(sortOption==Constants.SORT_OPTIONS_FOR_PLACES[position].toUpperCase()){
					sortOption=null;
				}else{
				sortOption = Constants.SORT_OPTIONS_FOR_PLACES[position];
				}
				
				allFilterString.setSortBy(sortOption.toUpperCase());
				adapter.notifyDataSetChanged();
				onFilterChangedListener.onFilterChanged(sortOption, 6);
			}
		});
		return view;

	}

}
