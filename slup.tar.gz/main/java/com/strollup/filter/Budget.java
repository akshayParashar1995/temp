package com.strollup.filter;

import java.io.Serializable;

public class Budget implements Serializable{
	private int minBudget;
	private int maxBudget;

	public int getMinBudget() {
		return minBudget;
	}

	public void setMinBudget(int minBudget) {
		this.minBudget = minBudget;
	}

	public int getMaxBudget() {
		return maxBudget;
	}

	public void setMaxBudget(int maxBudget) {
		this.maxBudget = maxBudget;
	}

}
