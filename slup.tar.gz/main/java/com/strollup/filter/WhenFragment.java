package com.strollup.filter;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.strollup.utility.Utils;

import in.strollup.android.R;

@SuppressLint("ValidFragment")
public class WhenFragment extends Fragment {
	AllFilterString allFilterString;
	private FilterArrayAdapter adapter;
	private OnFilterChangedListener onFilterChangedListener;

	public WhenFragment(AllFilterString allFilterString, OnFilterChangedListener onFilterChangedListener) {
		this.onFilterChangedListener = onFilterChangedListener;
		this.allFilterString = allFilterString;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate((Integer) R.layout.filter_display, container, false);
		String arr[] = Utils.getArrayOfWhenOptions();
		ListView lv = (ListView) view.findViewById((int) R.id.listView1);
		adapter = new FilterArrayAdapter(getActivity(), 0, arr, allFilterString, 0, lv, onFilterChangedListener, null);
		lv.setAdapter(adapter);
		lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> view, View arg1, int position, long arg3) {
				if (allFilterString == null) {
					allFilterString = new AllFilterString(getActivity());
				}
				PydOne pydOne = allFilterString.getPydOne();
				if (pydOne == null) {
					pydOne = new PydOne();
				}
				When when = pydOne.getWhen();
				if (when == null) {
					when = new When();
				}
				String dateString = Utils.getProperDateWithYear(position);
				String whenString=when.getWhen();
				if(whenString==null){
					whenString=new String();
				}
				if(whenString.equals(dateString)){
					when.setWhen(null);
				}else{
				when.setWhen(dateString);
				}
				pydOne.setWhen(when);
				allFilterString.setPydOne(pydOne);
				adapter.notifyDataSetChanged();
				onFilterChangedListener.onFilterChanged(dateString, 1);
			}
		});
		return view;
	}
}
