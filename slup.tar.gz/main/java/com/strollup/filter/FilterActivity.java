package com.strollup.filter;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Cache;
import com.android.volley.Cache.Entry;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.google.gson.Gson;
import com.strollup.activity.ActivityTagResponse;
import com.strollup.activity.TagDetailStrings;
import com.strollup.main.AppController;
import com.strollup.model.location.TextValPair;
import com.strollup.request.ActivityTagRequest;
import com.strollup.utility.Constants;
import com.strollup.utility.GsonRequest;
import com.strollup.utility.Utils;

import org.apache.commons.lang3.text.WordUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import in.strollup.android.R;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class FilterActivity extends AppCompatActivity implements OnFilterChangedListener {
	private LinearLayout linearLayout;
	private TextView whenText;
	private TextView startText;
	private TextView endText;
	private TextView costText;
	private TextView sortText;
	private TextView moreText;
	private TextView areaText;
	private int activityId;
	public AllFilterString allFilterString = null;
	private String TAG = FilterActivity.class.getSimpleName();
	private static FragmentManager fragMan;
	private MoreFragment moreFragment;
	private List<TextValPair> DisplayTags = new ArrayList<TextValPair>();
	private int callType;
	GsonRequest<ActivityTagResponse> myReq;
	private LinearLayout linearLayout1;
	private LinearLayout linearLayout2;
	private LinearLayout linearLayout3;
	private LinearLayout linearLayout4;
	private LinearLayout linearLayout5;
	private LinearLayout linearLayout6;
	private LinearLayout linearLayout7;

	private LinearLayout totalLayout;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		final FilterActivity filterActivity = this;
		super.onCreate(savedInstanceState);
		allFilterString = new AllFilterString(getApplicationContext());

		ActionBar actionBar = getSupportActionBar();
		actionBar.setTitle("Filter By");
		actionBar.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.filter_whole)));

		actionBar.setDisplayOptions(actionBar.getDisplayOptions() | ActionBar.DISPLAY_SHOW_CUSTOM);
		actionBar.setDisplayHomeAsUpEnabled(true);
		actionBar.setHomeButtonEnabled(true);

		ImageView imageView = new ImageView(actionBar.getThemedContext());
		imageView.setScaleType(ImageView.ScaleType.CENTER);
		imageView.setImageResource(R.drawable.ic_check_circle_white_36dp);
		ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(100, ActionBar.LayoutParams.WRAP_CONTENT,
				Gravity.RIGHT | Gravity.CENTER_VERTICAL);
		layoutParams.rightMargin = 0;
		imageView.setLayoutParams(layoutParams);
		actionBar.setCustomView(imageView);
		imageView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent returnIntent = new Intent();
				returnIntent.putExtra("allfilterstring", (Serializable) allFilterString);
				setResult(RESULT_OK, returnIntent);
                //overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
               // finish();
                onBackPressed();
			}
		});
		setContentView(R.layout.filter_whole);
		totalLayout=(LinearLayout) findViewById(R.id.totalLayout);
		linearLayout = (LinearLayout) findViewById(R.id.changeLayout);
		whenText = (TextView) findViewById(R.id.whenValue);
		startText = (TextView) findViewById(R.id.startTimeValue);
		endText = (TextView) findViewById(R.id.endTimeValue);
		costText = (TextView) findViewById(R.id.costValue);
		sortText = (TextView) findViewById(R.id.sortValue);
		moreText = (TextView) findViewById(R.id.moreValue);
		areaText = (TextView) findViewById(R.id.areaValue);
		fragMan = getFragmentManager();
		Intent i = getIntent();
		allFilterString = (AllFilterString) i.getSerializableExtra("allfilterstring");
		activityId = i.getIntExtra("activityType", 1);
		callType = i.getIntExtra("callType", 2);
		ActivityTagRequest activityTagRequest = new ActivityTagRequest(getApplicationContext());
		activityTagRequest.addActivityTypeIds(activityId);
		putFragment(new WhenFragment(allFilterString, filterActivity));
		linearLayout1 = (LinearLayout) findViewById(R.id.whenLayout);
		linearLayout2 = (LinearLayout) findViewById(R.id.startTimeLayout);
		linearLayout3 = (LinearLayout) findViewById(R.id.endTimeLayout);
		linearLayout4 = (LinearLayout) findViewById(R.id.costLayout);
		linearLayout5 = (LinearLayout) findViewById(R.id.areaLayout);
		linearLayout6 = (LinearLayout) findViewById(R.id.sortLayout);
		linearLayout7 = (LinearLayout) findViewById(R.id.moreLayout);

		resetColours(linearLayout1);
        TextView start= (TextView) findViewById(R.id.startTime);
        if(callType==1)
        {
            start.setText("Time");
        }
		if (callType == 1) {
			String url = Constants.BASE_SERVER_URL + "fetchActivityTags?activityListRequestString="
					+ new Gson().toJson(activityTagRequest);
			loadContent(url);
		}

		if (allFilterString != null) {
			String date = allFilterString.getWhen();
			if (date != null) {
				onFilterChanged(date, 1);
			}
			Integer startTime = allFilterString.getStartTime();
			if (startTime != null) {
				startTime = startTime / 60;
				onFilterChanged(Constants.TIME_SLOTS[startTime], 2);
			}
			Integer endTime = allFilterString.getEndTime();
			if (endTime != null) {
				endTime = endTime / 60;
				onFilterChanged(Constants.TIME_SLOTS[endTime], 3);
			}
			Budget budget = allFilterString.getBudget();
			if (budget != null) {
				int minBudget = budget.getMinBudget();
				int maxBudget = budget.getMaxBudget();
				int arrayIndex = getArrayIndex(minBudget, maxBudget);
				onFilterChanged(Constants.COST[arrayIndex], 4);
			}
			PydOne pydOne = allFilterString.getPydOne();
			if (pydOne != null) {
				List<Region> regionList = pydOne.getWhereList();
				if (regionList != null) {
					if (regionList.size() == 0) {
						onFilterChanged("", 5);
					} else {
						onFilterChanged(regionList.size() + " selected", 5);
					}
				}
			}
			String sort = allFilterString.getSortBy();
			if (sort != null) {
				onFilterChanged(sort, 6);
			}
			TagFilter tagFilter = allFilterString.getTagFilter();
			if (tagFilter != null) {
				List<Integer> activityIds = tagFilter.getTagIDs();
				if (activityIds != null) {
					if (activityIds.size() == 0) {
						onFilterChanged("", 7);
					} else {
						onFilterChanged(activityIds.size() + " selected", 7);
					}
				}
			}
		}

		linearLayout1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				putFragment(new WhenFragment(allFilterString, filterActivity));
				resetColours(linearLayout1);
				}

		});
		linearLayout2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				putFragment(new StartFragment(allFilterString, filterActivity));
				resetColours(linearLayout2);


			}
		});
		linearLayout3.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				putFragment(new EndFragment(allFilterString, filterActivity));
				resetColours(linearLayout3);


			}
		});
		linearLayout4.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				putFragment(new CostFragment(allFilterString, filterActivity));
				resetColours(linearLayout4);


			}
		});

		linearLayout5.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				putFragment(new AreaFragment(allFilterString, filterActivity));
				resetColours(linearLayout5);


			}
		});
		linearLayout6.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				putFragment(new SortFragment(allFilterString, filterActivity));
				resetColours(linearLayout6);


			}
		});

		linearLayout7.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				moreFragment = new MoreFragment(allFilterString, filterActivity, activityId, DisplayTags);
				putFragment(moreFragment);
				resetColours(linearLayout7);

			}
		});
		if (callType == 2) {
			linearLayout7.setVisibility(View.GONE);
		}
        if(callType==1)
        {
            linearLayout3.setVisibility(View.GONE);

        }
	}

	private void loadContent(String url) {
		Cache cache = AppController.getInstance().getRequestQueue().getCache();
		Entry entry = cache.get(url);
		if (entry != null && entry.serverDate + Constants.CACHE_EXPIRY_TIME > System.currentTimeMillis()) {
			try {
				String data = new String(entry.data, "UTF-8");
				ActivityTagResponse activityTagResponse = (ActivityTagResponse) Utils.getCachedResponse(
						ActivityTagResponse.class, data);
				onSuccess(activityTagResponse);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			AppController.getInstance().getRequestQueue().getCache().invalidate(url, true);
			myReq = new GsonRequest<ActivityTagResponse>(Request.Method.GET, url, ActivityTagResponse.class,
					createMyReqSuccessListener(), createMyReqErrorListener());
			AppController.getInstance().addToRequestQueue(myReq, TAG);
		}
	}

	@Override
	public void onFilterChanged(String s, int type) {
		if (s != null) {
			switch (type) {
			case 1:
				whenText.setText(s);
				return;
			case 2:
				startText.setText(s);
				return;
			case 3:
				endText.setText(s);
				return;
			case 4:
				costText.setText(s);
				return;
			case 5:
				areaText.setText(s);
				return;
			case 6:
				sortText.setText(WordUtils.capitalize(s.toLowerCase()));
				return;
			case 7:
				moreText.setText(s);
				return;

			}
		}
	}

	public static void putFragment(Fragment myFrag) {
		FragmentTransaction fragTransaction = fragMan.beginTransaction();
		fragTransaction.replace(R.id.changeLayout, myFrag, "fragment");
		fragTransaction.commit();
	}

	public static int getArrayIndex(int minBudget, int maxBudget) {
		if (maxBudget <= 250) {
			return 0;
		} else if (minBudget >= 250 && maxBudget <= 500) {
			return 1;
		} else if (minBudget >= 500 && maxBudget <= 1000) {
			return 2;
		} else if (minBudget >= 1000 && maxBudget <= 2000) {
			return 3;
		} else
			return 4;
	}

	private Response.Listener<ActivityTagResponse> createMyReqSuccessListener() {
		return new Response.Listener<ActivityTagResponse>() {
			@Override
			public void onResponse(ActivityTagResponse activityTagResponse) {
				onSuccess(activityTagResponse);
			};
		};
	}

	private Response.ErrorListener createMyReqErrorListener() {
		return new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {
				Log.e(TAG, "Error Occured while calling backend", error.getCause());
				Toast.makeText(getApplicationContext(), Constants.GENERAL_ERROR_MESSAGE, Toast.LENGTH_LONG).show();
				if (error instanceof NoConnectionError || error instanceof TimeoutError)
					Utils.noNetworkMessage(FilterActivity.this, myReq);
			}
		};
	}

	private void onSuccess(ActivityTagResponse activityTagResponse) {
		try {
			List<TagDetailStrings> Tags = activityTagResponse.getTagDetailStrings();
			DisplayTags = Tags.get(0).getActivityTags();
			if (moreFragment != null) {
				moreFragment.notifyDataChanged(DisplayTags);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
            onBackPressed();
            return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}
	public void resetColours(LinearLayout l ){
		linearLayout1.setBackgroundColor(getResources().getColor(R.color.filter_whole));
		linearLayout2.setBackgroundColor(getResources().getColor(R.color.filter_whole));
		linearLayout3.setBackgroundColor(getResources().getColor(R.color.filter_whole));
		linearLayout4.setBackgroundColor(getResources().getColor(R.color.filter_whole));
		linearLayout5.setBackgroundColor(getResources().getColor(R.color.filter_whole));
		linearLayout6.setBackgroundColor(getResources().getColor(R.color.filter_whole));
		linearLayout7.setBackgroundColor(getResources().getColor(R.color.filter_whole));
		l.setBackgroundColor(getResources().getColor(R.color.filter_display));

	}
    @Override
    public void onBackPressed()
    {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
