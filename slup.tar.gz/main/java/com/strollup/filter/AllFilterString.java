package com.strollup.filter;

import android.content.Context;

import com.strollup.utility.Utils;

import java.io.Serializable;

public class AllFilterString implements Serializable {
	private static final long serialVersionUID = 6303117222663717669L;
	private Budget budget;
	private String sortBy;
	private Region startLocation;
	private Region endLocation;
	private PydOne pydOne;
	private PydTwo pydTwo;
	private TagFilter tagFilter;

	public AllFilterString(Context mContext) {
		Region start = new Region(Utils.getDefaultArea(mContext), Utils.getDefaultAreaLatitude(mContext),
				Utils.getDefaultAreaLongitude(mContext));
		this.startLocation = start;
		this.endLocation = start;
	}

	public TagFilter getTagFilter() {
		return tagFilter;
	}

	public void setTagFilter(TagFilter tagFilter) {
		this.tagFilter = tagFilter;
	}

	public Budget getBudget() {
		return budget;
	}

	public void setBudget(Budget budget) {
		this.budget = budget;
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	public Region getStartLocation() {
		return startLocation;
	}

	public void setStartLocation(Region startLocation) {
		this.startLocation = startLocation;
	}

	public Region getEndLocation() {
		return endLocation;
	}

	public void setEndLocation(Region endLocation) {
		this.endLocation = endLocation;
	}

	public PydOne getPydOne() {
		return pydOne;
	}

	public String getWhen() {
		if (pydOne == null) {
			return null;
		}
		return pydOne.getWhenString();
	}

	public Integer getStartTime() {
		if (pydOne == null) {
			return null;
		}
		return pydOne.getStart();
	}

	public Integer getEndTime() {
		if (pydOne == null) {
			return null;
		}
		return pydOne.getEnd();
	}

	public void setPydOne(PydOne pydOne) {
		this.pydOne = pydOne;
	}

	public PydTwo getPydTwo() {
		return pydTwo;
	}

	public void setPydTwo(PydTwo pydTwo) {
		this.pydTwo = pydTwo;
	}
}
