package com.strollup.filter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class TagFilter implements Serializable {
	private List<Integer> tagIDs;
	private boolean isPersonalizedTagApplied = false;

	public void addTagId(int tagId) {
		if (tagIDs == null) {
			tagIDs = new ArrayList<Integer>();
		}
		tagIDs.add(tagId);
	}

	public List<Integer> getTagIDs() {
		return tagIDs;
	}

	public void setTagIDs(List<Integer> tagIDs) {
		this.tagIDs = tagIDs;
	}

	public boolean isPersonalizedTagApplied() {
		return isPersonalizedTagApplied;
	}

	public void setPersonalizedTagApplied(boolean isPersonalizedTagApplied) {
		this.isPersonalizedTagApplied = isPersonalizedTagApplied;
	}

}
