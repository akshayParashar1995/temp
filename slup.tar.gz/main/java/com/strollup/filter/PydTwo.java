package com.strollup.filter;

import java.io.Serializable;
import java.util.List;

public class PydTwo implements Serializable{
	private List<Integer> activityIds;
	private List<Integer>	activityTypeIds;

	public List<Integer> getActivityTypeIds() {
		return activityTypeIds;
	}

	public void setActivityTypeIds(List<Integer> activityTypeIds) {
		this.activityTypeIds = activityTypeIds;
	}

	public List<Integer> getActivityIds() {
		return activityIds;
	}

	public void setActivityIds(List<Integer> activityIds) {
		this.activityIds = activityIds;
	}


}
