package com.strollup.filter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PydOne implements Serializable{
	private When when;
	private List<Region> where;
	private String goingWith;

	public When getWhen() {
		return when;
	}
	public String getWhenString() {
		if (when == null) {
			return null;
		}
		return when.getWhen();
	}

	public Integer getStart() {
		if (when == null) {
			return null;
		}
		return when.getStartTime();

	}

	public Integer getEnd() {
		if (when == null) {
			return null;
		}
		return when.getEndTime();

	}

	public void setWhen(When when) {
		this.when = when;
	}
	public List<Region> getWhereList(){
		if(where==null){
			where=new ArrayList<Region>();
		}
		return where;
	}
	public Region getRegion() {
		if (where == null || where.isEmpty()) {
			return null;
		}
		return where.get(0);
	}

	public String getArea() {
		if (getRegion() == null) {
			return null;
		}
		return getRegion().getArea();
	}

	public String getLatitude() {
		if (getRegion() == null) {
			return null;
		}
		return getRegion().getLatitude();
	}

	public String getLongitude() {
		if (getRegion() == null) {
			return null;
		}
		return getRegion().getLongitude();
	}

	public void setWhereList(List<Region> region) {
		this.where = region;
	}
	
	public void setWhere(Region region) {
		this.where = new ArrayList<Region>();
		this.where.add(region);
	}

	public String getGoingWith() {
		if (this.goingWith == null) {
			return null;
		}
		return goingWith;
	}

	public void setGoingWith(String goingWith) {
		if(goingWith == null) {
			this.goingWith = null;
		} else if(goingWith.contains("Friends")){
			this.goingWith = "FR";
		} else if(goingWith.contains("Signi")){
			this.goingWith = "DA";
		} else if(goingWith.contains("Family")){
			this.goingWith = "FM";
		}
	}
}
