package com.strollup.filter;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.strollup.utility.Constants;

import in.strollup.android.R;

@SuppressLint("ValidFragment")
public class StartFragment extends Fragment {
	AllFilterString allFilterString;
	int type;
	private FilterArrayAdapter adapter;
	private OnFilterChangedListener onFilterChangedListener;

	public StartFragment(AllFilterString allFilterString, OnFilterChangedListener onFilterChangedListener) {
		this.onFilterChangedListener = onFilterChangedListener;
		this.allFilterString = allFilterString;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate((Integer) R.layout.filter_display, container, false);
		ListView lv = (ListView) view.findViewById((int) R.id.listView1);
		adapter = new FilterArrayAdapter(getActivity().getApplicationContext(), 0, Constants.TIME_SLOTS,
				allFilterString, 1, lv, onFilterChangedListener, null);
		lv.setAdapter(adapter);
		lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> view, View arg1, int position, long arg3) {
				// TODO Auto-generated method stub
				String startTime = (String) view.getItemAtPosition(position);
				for (int i = 0; i < Constants.TIME_SLOTS.length; i++) {
					if (startTime.equals(Constants.TIME_SLOTS[i])) {
						if (allFilterString == null)
							allFilterString = new AllFilterString(getActivity());
						PydOne pydOne = allFilterString.getPydOne();
						if (pydOne == null) {
							pydOne = new PydOne();
						}
						When when = pydOne.getWhen();
						if (when == null) {
							when = new When();
						}
						Integer setTime=when.getStartTime();
						if(setTime!=null&&setTime==i*60){
							when.setStartTime(null);
						}else{
						when.setStartTime(i * 60);
						}
						pydOne.setWhen(when);
						allFilterString.setPydOne(pydOne);
						adapter.notifyDataSetChanged();
						onFilterChangedListener.onFilterChanged(startTime, 2);
						break;
					}
				}
			}
		});
		return view;

	}
}
