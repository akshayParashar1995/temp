package com.strollup.filter;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.strollup.utility.Globals;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import in.strollup.android.R;

@SuppressLint("ValidFragment")
public class AreaFragment extends Fragment {
	AllFilterString allFilterString;
	private FilterArrayAdapter adapter;
	private OnFilterChangedListener onFilterChangedListener;
	private String TAG = AreaFragment.class.getSimpleName();
	private View view;
	private List<Region> regionList;

    public AreaFragment() {
    }

	public AreaFragment(AllFilterString allFilterString, OnFilterChangedListener onFilterChangedListener) {
		this.onFilterChangedListener = onFilterChangedListener;
		this.allFilterString = allFilterString;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		view = inflater.inflate((Integer) R.layout.filter_display, container, false);
		ListView lv = (ListView) view.findViewById((int) R.id.listView1);
		lv.setPadding(2, 0, 2, 0);
		List<String> display = new ArrayList<String>();
		regionList = new ArrayList<Region>(Globals.suggestedAreas);
		Collections.sort(regionList);
		for (int i = 0; i < Globals.suggestedAreas.size(); i++) {
			display.add(regionList.get(i).getArea());
		}
		adapter = new FilterArrayAdapter(getActivity().getApplicationContext(), 0, display, allFilterString, 4, lv,
				onFilterChangedListener, null);
		lv.setAdapter(adapter);
		lv.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> gv, View arg1, int position, long arg3) {
				if (allFilterString == null)
					allFilterString = new AllFilterString(getActivity());
				PydOne pydOne = allFilterString.getPydOne();
				if (pydOne == null) {
					pydOne = new PydOne();
				}
				List<Region> where = pydOne.getWhereList();
				if (where == null) {
					where = new ArrayList<Region>();
				}
				Region region = regionList.get(position);
				if (where.contains(region)) {
					where.remove(region);
					if (where.size() == 0) {
						where = null;
					}
				} else {
					where.add(region);
				}
				pydOne.setWhereList(where);
				allFilterString.setPydOne(pydOne);
				adapter.notifyDataSetChanged();
			}
		});
		return view;

	}

}
