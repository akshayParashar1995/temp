package com.strollup.filter;

import java.io.Serializable;
import java.util.Date;

public class When implements Serializable{



	private String when;
	private Integer startTime = new Date().getHours() * 60 +  new Date().getMinutes();
	private Integer endTime = 1380;

	public String getWhen() {
		return when;
	}

	public void setWhen(String when) {
		this.when = when;
	}

	public Integer getStartTime() {
		return startTime;
	}

	public void setStartTime(Integer startTime) {
		this.startTime = startTime;
	}

	public Integer getEndTime() {
		return endTime;
	}

	public void setEndTime(Integer endTime) {
		this.endTime = endTime;
	}
}