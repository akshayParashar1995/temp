package com.strollup.filter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.strollup.model.location.TextValPair;
import com.strollup.utility.Constants;
import com.strollup.utility.Utils;

import org.apache.commons.lang3.text.WordUtils;

import java.util.HashMap;
import java.util.List;

import in.strollup.android.R;

public class FilterArrayAdapter extends ArrayAdapter<String> {

	private final LayoutInflater inflater;
	private RelativeLayout layout;
	private int fragType;
	private AllFilterString allFilterString;
	private OnFilterChangedListener onFilterChangedListener;
	private HashMap<String, Integer> textIdMap;
	private List<TextValPair> activityTagsList;

	public FilterArrayAdapter(Context context, int resource, String[] objects, AllFilterString allFilterString,
			int fragType, ListView listView, OnFilterChangedListener onFilterChangedListener,
			List<TextValPair> activityTagsList) {
		super(context, resource, objects);
		this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		this.fragType = fragType;
		this.allFilterString = allFilterString;
		this.onFilterChangedListener = onFilterChangedListener;
		this.textIdMap = Utils.getHashMapFromTextValPairList(activityTagsList);
		this.activityTagsList = activityTagsList;
	}

	public FilterArrayAdapter(Context context, int resource, List<String> objects, AllFilterString allFilterString,
			int fragType, ListView listView, OnFilterChangedListener onFilterChangedListener,
			List<TextValPair> activityTagsList) {
		super(context, resource, objects);
		this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		this.fragType = fragType;
		this.allFilterString = allFilterString;
		this.onFilterChangedListener = onFilterChangedListener;
		this.textIdMap = Utils.getHashMapFromTextValPairList(activityTagsList);
		this.activityTagsList = activityTagsList;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.simple_list_item, null);
		}

		String string = getItem(position);
		TextView tv = (TextView) convertView.findViewById(R.id.textView1);
		tv.setText(string);
		tv.setTextColor(Color.WHITE);
		CheckBox cb = (CheckBox) convertView.findViewById(R.id.check1);
		// if(fragType!=5)
		cb.setChecked(false);
		switch (fragType) {
		case 0:
			if (allFilterString != null) {
				String date = allFilterString.getWhen();
				if(date==null){
					onFilterChangedListener.onFilterChanged("", 1);

				}
				if (date != null && string.charAt(string.length() - 5) == date.charAt(date.length() - 1)
						&& string.charAt(string.length() - 6) == date.charAt(date.length() - 2)) {
					cb.setChecked(true);
					tv.setTextColor(Color.parseColor("#26B865"));
					onFilterChangedListener.onFilterChanged(date, 1);
				}
			}
			break;
		case 1:
			if (allFilterString != null) {
				Integer startTime = allFilterString.getStartTime();
				if(startTime==null){
					onFilterChangedListener.onFilterChanged("", 2);
				}
				if (startTime != null) {
					startTime = startTime / 60;
					if (string.equals(Constants.TIME_SLOTS[startTime])) {
						cb.setChecked(true);
						tv.setTextColor(Color.parseColor("#26B865"));
						onFilterChangedListener.onFilterChanged(string, 2);

					}
				}
			}
			break;
		case 2:
			if (allFilterString != null) {
				Integer endTime = allFilterString.getEndTime();
				if(endTime==null){
					onFilterChangedListener.onFilterChanged("", 3);
				}
				if (endTime != null) {
					endTime = endTime / 60;
					if (string.equals(Constants.TIME_SLOTS[endTime])) {
						cb.setChecked(true);
						tv.setTextColor(Color.parseColor("#26B865"));
						onFilterChangedListener.onFilterChanged(string, 3);

					}
				}
			}
			break;
		case 3:
			if (allFilterString != null) {
				Budget budget = allFilterString.getBudget();
				if(budget==null){
					onFilterChangedListener.onFilterChanged("", 4);
				}
				if (budget != null) {
					int minBudget = budget.getMinBudget();
					int maxBudget = budget.getMaxBudget();
					int arrayIndex = getArrayIndex(minBudget, maxBudget);
					if (string.equals(Constants.COST[arrayIndex])) {
						cb.setChecked(true);
						tv.setTextColor(Color.parseColor("#26B865"));
						onFilterChangedListener.onFilterChanged(string, 4);

					}
				}
			}
			break;
		case 4:
			if (allFilterString != null) {
				PydOne pydOne = allFilterString.getPydOne();
				if (pydOne != null) {
					List<Region> regionList = pydOne.getWhereList();
					if (regionList.size() == 0) {
						onFilterChangedListener.onFilterChanged("", 5);
					}
					for (int i = 0; i < regionList.size(); i++) {
						if (string.equals(regionList.get(i).getArea())) {
							if (cb.isChecked()) {
								cb.setChecked(false);
								tv.setTextColor(Color.parseColor("#ffffff"));
							} else {
								cb.setChecked(true);
								tv.setTextColor(Color.parseColor("#26B865"));
								onFilterChangedListener.onFilterChanged(string, 5);

							}

						}
					}
				}
			}
			break;
		case 5:
			if (allFilterString != null) {
				String sortOption = allFilterString.getSortBy();
				if(sortOption==null){
					onFilterChangedListener.onFilterChanged("", 6);
				}
				if (sortOption != null) {
					if (string.equals(WordUtils.capitalize(sortOption.toLowerCase()))) {
						cb.setChecked(true);
						tv.setTextColor(Color.parseColor("#26B865"));
						onFilterChangedListener.onFilterChanged(sortOption, 6);

					}
				}
			}
			break;
		case 6:
			if (allFilterString != null) {
				TagFilter tagFilter = allFilterString.getTagFilter();
				if (tagFilter != null) {
					List<Integer> Ids = tagFilter.getTagIDs();
					if (Ids.size() == 0) {
						onFilterChangedListener.onFilterChanged("", 7);
					}
					for (int i = 0; i < Ids.size(); i++) {
						if (activityTagsList != null) {
							for (int j = 0; j < activityTagsList.size(); j++) {
								if (Ids.get(i) == activityTagsList.get(j).getValue()
										&& activityTagsList.get(j).getText().equals(string)) {
									if (cb.isChecked()) {
										cb.setChecked(false);
										tv.setTextColor(Color.parseColor("#ffffff"));
									} else {
										cb.setChecked(true);
										tv.setTextColor(Color.parseColor("#26B865"));
										onFilterChangedListener.onFilterChanged(string, 7);
									}
								}
							}
						}
					}
				}
			}
			break;
		}
		return convertView;
	}

	public static int getArrayIndex(int minBudget, int maxBudget) {
		if (maxBudget <= 250) {
			return 0;
		} else if (minBudget >= 250 && maxBudget <= 500) {
			return 1;
		} else if (minBudget >= 500 && maxBudget <= 1000) {
			return 2;
		} else if (minBudget >= 1000 && maxBudget <= 2000) {
			return 3;
		} else
			return 4;
	}

	public void setActivityTagList(List<TextValPair> activityTagsList) {
		this.activityTagsList = activityTagsList;
	}

}
