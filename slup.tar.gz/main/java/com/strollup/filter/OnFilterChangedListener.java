package com.strollup.filter;

public interface OnFilterChangedListener {
	public void onFilterChanged(String s, int type);
}
