package com.strollup.filter;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.strollup.utility.Constants;

import java.util.Arrays;
import java.util.List;

import in.strollup.android.R;

@SuppressLint("ValidFragment")
public class CostFragment extends Fragment {
	AllFilterString allFilterString;
	private FilterArrayAdapter adapter;
	private OnFilterChangedListener onFilterChangedListener;

    public CostFragment() {
    }

	public CostFragment(AllFilterString allFilterString, OnFilterChangedListener onFilterChangedListener) {
		this.onFilterChangedListener = onFilterChangedListener;
		this.allFilterString = allFilterString;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate((Integer) R.layout.filter_display, container, false);
		ListView lv = (ListView) view.findViewById((int) R.id.listView1);
		lv.setPadding(2, 0, 2, 0);
		adapter = new FilterArrayAdapter(getActivity().getApplicationContext(), 0, Constants.COST, allFilterString, 3,
				lv, onFilterChangedListener, null);
		lv.setAdapter(adapter);
		lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> view, View arg1, int position, long arg3) {
				String cost = (String) view.getItemAtPosition(position);
				for (int i = 0; i < Constants.COST.length; i++) {
					if (cost.equals(Constants.COST[i])) {
						Budget budget = null;
						if (allFilterString != null)
							budget = allFilterString.getBudget();
						else
							allFilterString = new AllFilterString(getActivity());
						if (budget == null) {
							budget = new Budget();
						}
						int minBudget = getMinBudget(i);
						int maxBudget = getMaxBudget(i);
						int minb=budget.getMinBudget();
						int maxb=budget.getMaxBudget();
						if(budget.getMinBudget()==getMinBudget(i)&&budget.getMaxBudget()==getMaxBudget(i)){
							
							allFilterString.setBudget(null);
						}else{
						budget.setMaxBudget(maxBudget);
						budget.setMinBudget(minBudget);
						allFilterString.setBudget(budget);
						}
						onFilterChangedListener.onFilterChanged(Constants.COST[i], 4);
						adapter.notifyDataSetChanged();
						break;
					}
				}
			}
		});
		return view;

	}

	private int getMinBudget(int index) {
		List<Integer> minBudgets = Arrays.asList(0, 250, 500, 1000, 2000);
		return minBudgets.get(index);
	}

	private int getMaxBudget(int index) {
		List<Integer> maxBudgets = Arrays.asList(250, 500, 1000, 2000, 10000);
		return maxBudgets.get(index);
	}

}
