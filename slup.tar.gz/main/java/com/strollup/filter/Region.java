package com.strollup.filter;

import com.strollup.utility.Globals;

import java.io.Serializable;

public class Region extends LatLong implements Serializable,Comparable<Region> {

	private String area;

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public Region(String area, String latitude, String longitude) {
		super(latitude, longitude);
		this.area = area;
	}

	@Override
	public boolean equals(Object obj) {
		Region location = (Region) obj;
		if(this == null && location == null)
				return true;
		if(this.getLatitude() == null && location.getLatitude() != null) 
			return false;
		if(this.getLatitude() != null && location.getLatitude() == null)
			return false;
		if(this.getLatitude() == null && location.getLatitude() == null) 
			return true;
		if (this.getLatitude().equals(location.getLatitude()) && this.getLongitude().equals(location.getLongitude())) {
			return true;
		}
		return false;
	}

	public static Region getRegionObject(String area) {
		for (Region region : Globals.suggestedAreas) {
			if (region.getArea().toLowerCase().equals(area.toLowerCase())) {
				return region;
			}
		}
		return null;
	}

	@Override
	public int compareTo(Region another) {
		return area.compareTo(another.getArea());
	}
}
