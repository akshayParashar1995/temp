package com.strollup.main;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import in.strollup.android.R;

@SuppressLint("ValidFragment")
public class ScreenShotFragment extends Fragment {

	private Button done;
	private int position;
	private ImageView iv;

	public ScreenShotFragment(int position) {
		this.position = position;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		View v = inflater.inflate(R.layout.screenshot_fragment_layout, null);
		done = (Button) v.findViewById(R.id.next_button);
//		iv = (ImageView) v.findViewById(R.id.screenshot_image);
//		int sdk = android.os.Build.VERSION.SDK_INT;
		
//		if (position == 0) {
//			if(sdk < android.os.Build.VERSION_CODES.JELLY_BEAN) {
//				iv.setBackgroundDrawable(getResources().getDrawable(R.drawable.screenshot1));
//			} else {
//				iv.setBackground( getResources().getDrawable(R.drawable.screenshot1));
//			}
//		} else if (position == 1) {
//			if(sdk < android.os.Build.VERSION_CODES.JELLY_BEAN) {
//				iv.setBackgroundDrawable(getResources().getDrawable(R.drawable.screenshot3));
//			} else {
//				iv.setBackground( getResources().getDrawable(R.drawable.screenshot3));
//			}
//		} else if (position == 2) {
//			if(sdk < android.os.Build.VERSION_CODES.JELLY_BEAN) {
//				iv.setBackgroundDrawable(getResources().getDrawable(R.drawable.screenshot2));
//			} else {
//				iv.setBackground( getResources().getDrawable(R.drawable.screenshot2));
//			}
//		}  
//		iv.setScaleType(ScaleType.CENTER_CROP);
//		if (position < 2) {
//			done.setOnClickListener(new View.OnClickListener() {
//				@Override
//				public void onClick(View v) {
//					ScreenShotActivity.viewpager.setCurrentItem(position + 1, true);
//				}
//			});
//		}
//		if (position == 2) {
//			done.setOnClickListener(new View.OnClickListener() {
//				@Override
//				public void onClick(View v) {
//					Intent i = new Intent();
//					i.setClass(getActivity(), CreateAccountActivity.class);
//					getActivity().finish();
//				}
//			});
//		}
//
//		if (position == 2) {
//			done.setText("Let's Go");
//		}
		return v;
	}

}
