package com.strollup.main;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.database.MatrixCursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.provider.BaseColumns;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.AutoCompleteTextView;
import android.widget.LinearLayout;

import com.android.volley.Cache;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.github.florent37.materialviewpager.MaterialViewPager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.strollup.activity.ActivityDataResponse;
import com.strollup.activity.ActivityTypeController;
import com.strollup.activity.ActivityTypeDto;
import com.strollup.filter.AllFilterString;
import com.strollup.place.PlaceDetailActivity;
import com.strollup.place.PlaceListingFragment;
import com.strollup.request.ActivityAtLocation;
import com.strollup.request.ListingSearchRequest;
import com.strollup.search.CustomCursorAdapter;
import com.strollup.search.ListingContext;
import com.strollup.search.ListingContextAdapter;
import com.strollup.search.ListingSearchDto;
import com.strollup.search.ListingSearchResponse;
import com.strollup.search.LocationContext;
import com.strollup.search.SearchResponse;
import com.strollup.utility.Constants;
import com.strollup.utility.Globals;
import com.strollup.utility.GsonRequest;
import com.strollup.utility.Utils;

import java.io.Serializable;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import in.strollup.android.R;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class ExploreTabListing extends AppCompatActivity {

    private MaterialViewPager mViewPager;
    private SectionsPagerAdapter mSectionsPagerAdapter;
    public int noOfActivities;
    private int tabPosition;
    private List<ListingSearchDto> suggestions;
    private GsonRequest<SearchResponse> myReq;
    public List<ActivityTypeDto> activityTypes;
    private AllFilterString allFilterString;
    private static final String TAG = ExploreTabListing.class.getSimpleName();
    private SearchView searchView;
    private final Handler handler = new Handler();
    private Menu menu;
    private String mSearchString;
    private String customString = "";
    private MatrixCursor mCursor = null;
    private CustomCursorAdapter suggestionAdapter;

    public void refresh() {
        Intent i = new Intent(getApplicationContext(), DummyClass.class);
        i.putExtra("allfilterstring", (Serializable) allFilterString);
        i.putExtra("tabPosition", mViewPager.getViewPager().getCurrentItem());
        i.putExtra("customString", customString);
        startActivity(i);
        finish();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 0 && resultCode == RESULT_OK) {
            allFilterString = (AllFilterString) data.getSerializableExtra("allfilterstring");
            refresh();
        }
    }

    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        setContentView(R.layout.sliding_tabs_layout);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        allFilterString = new AllFilterString(getApplicationContext());
        mViewPager = (MaterialViewPager) findViewById(R.id.pager);
        suggestions = new ArrayList<ListingSearchDto>();
        Intent i = getIntent();
        if (Intent.ACTION_SEARCH.equals(i.getAction())) {
            handleIntent(getIntent());
        }
        Typeface font = Typeface.createFromAsset(this.getAssets(), Constants.BASE_FONT);
        mViewPager.getPagerTitleStrip().setTypeface(font, 0);
        mViewPager.getViewPager().setCurrentItem(tabPosition);
        if (Globals.activityResult.getActivityTypeStrings().size() == 0) {
            new ActivityTypeController(this, ExploreTabListing.this, ExploreTabListing.this, "ExploreTabListing").fetchActivityTypes();
        } else {
            success(Globals.activityResult);
        }
    }

    public void success(ActivityDataResponse activityDataResponse) {
        Globals.activityResult = activityDataResponse;
        noOfActivities = Globals.activityResult.getActivityTypeStrings().size();
        activityTypes = Globals.activityResult.getActivityTypeStrings();
        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());
        mViewPager.getViewPager().setAdapter(mSectionsPagerAdapter);
        Intent i = getIntent();
        Bundle bundle = i.getExtras();
        if ((AllFilterString) i.getSerializableExtra("allfilterstring") != null)
            allFilterString = (AllFilterString) i.getSerializableExtra("allfilterstring");
        int tabPosition = bundle.getInt("tabPosition", 0);
        customString = bundle.getString("customString");
        if (bundle.getString("allFilter") != null) {
            allFilterString = new Gson().fromJson(bundle.getString("allFilter"), AllFilterString.class);
        }
        mViewPager.getPagerTitleStrip().setViewPager(mViewPager.getViewPager());
        mViewPager.getViewPager().setCurrentItem(tabPosition);
    }

    public class SectionsPagerAdapter extends FragmentPagerAdapter {
        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            Fragment fragment = new PlaceListingFragment(activityTypes.get(position).getId(), allFilterString, customString);
            return fragment;
        }

        @Override
        public int getCount() {
            return activityTypes.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                default:
                    return activityTypes.get(position).getName();
            }
        }
    }

    public void doSearch(ListingContext listingContext) {
        if (listingContext instanceof LocationContext) {
            LocationContext locationContext = (LocationContext) listingContext;
            ActivityAtLocation activityAtLocation = locationContext.getActivityLocation();
            int location_detail_id = activityAtLocation.getLocationDetailId();
            hideFilter();
            initializeDropDown();
            int activity_id = activityAtLocation.getActivityId();
            Intent i = new Intent(getApplicationContext(), PlaceDetailActivity.class);
            i.putExtra("activity_id", activity_id);
            i.putExtra("location_detail_id", location_detail_id);
            i.putExtra("inApp", true);
            startActivity(i);
        } else           //check if instance of plan context
        {
        }
    }

    public void onNewIntent(Intent intent) {
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (Intent.ACTION_SEARCH.equals(intent.getAction())) {
            String query =
                    intent.getStringExtra(SearchManager.QUERY);
            doSearchSoftKey(query);
        }
    }

    private void doSearchSoftKey(String queryStr) {
        customString = queryStr;
        refresh();
    }

    public void initializeDropDown() {
        LinearLayout linearLayout1 = (LinearLayout) (searchView.getChildAt(0));
        LinearLayout linearLayout2 = (LinearLayout) (linearLayout1.getChildAt(2));
        LinearLayout linearLayout3 = (LinearLayout) (linearLayout2.getChildAt(1));
        AutoCompleteTextView autoCompleteTextView = (AutoCompleteTextView) (linearLayout3.getChildAt(0));
        autoCompleteTextView.setTextColor(Color.WHITE);
        autoCompleteTextView.setHintTextColor(Color.WHITE);

        // autoCompleteTextView.setDropDownBackgroundDrawable(drawable);
        autoCompleteTextView.setDropDownWidth(-1);
    }

    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {
        final MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.explore_menu, menu);
        this.menu = menu;
        SearchManager searchManager =
                (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchView = (SearchView) menu.findItem(R.id.action_search).getActionView();
        LinearLayout linearLayout1 = (LinearLayout) (searchView.getChildAt(0));

        searchView.setSearchableInfo(
                searchManager.getSearchableInfo(getComponentName()));
        suggestionAdapter = new CustomCursorAdapter(this,
                R.layout.search_list_simple_item,
                null,
                new String[]{SearchManager.SUGGEST_COLUMN_TEXT_1, SearchManager.SUGGEST_COLUMN_TEXT_2, SearchManager.SUGGEST_URI_PATH_QUERY},
                new int[]{R.id.title, R.id.type, R.id.location}
        );

        searchView.setSuggestionsAdapter(suggestionAdapter);
        searchView.setOnSuggestionListener(new SearchView.OnSuggestionListener() {
            @Override
            public boolean onSuggestionSelect(int position) {
                hideFilter();
                initializeDropDown();
                return false;
            }

            @Override
            public boolean onSuggestionClick(int position) {
                searchView.setQuery((CharSequence) suggestions.get(position).getName(), false);
                searchView.clearFocus();
                hideFilter();
                initializeDropDown();
                ListingContext listingContext = (ListingContext) suggestions.get(position).getListingContext();
                doSearch(listingContext);
                return true;
            }
        });


        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {
                showFilter();
                initializeDropDown();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String searchString) {
                mSearchString = searchString;
                ListingSearchRequest listingSearchRequest = new ListingSearchRequest(getApplicationContext());
                listingSearchRequest.setSearchString(searchString);
                listingSearchRequest.setContext(1);
                GsonBuilder builder = new GsonBuilder();
                builder.registerTypeAdapter(ListingContext.class, new ListingContextAdapter());

                Gson gson = builder.create();
                final String url = Constants.BASE_SERVER_URL + "fetchListingSearchData?" + "listingSearchRequestString="
                        + gson.toJson(listingSearchRequest);
                handler.removeCallbacksAndMessages(null);

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        loadContent(url);

                    }
                }, 200);


                return false;
            }
        });
        MenuItem searchMenuItem = menu.findItem(R.id.action_search);
        MenuItemCompat.setOnActionExpandListener(searchMenuItem, new MenuItemCompat.OnActionExpandListener() {

            @Override
            public boolean onMenuItemActionExpand(MenuItem item) {
                hideFilter();
                return true;
            }

            @Override
            public boolean onMenuItemActionCollapse(MenuItem item) {
                showFilter();
                initializeDropDown();
                return true;
            }
        });
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_search:
                getSupportActionBar().setIcon(android.R.color.transparent);
                getSupportActionBar().setDisplayShowHomeEnabled(false);
                hideFilter();
                initializeDropDown();
                return true;
            case R.id.action_filter:
                Intent i = new Intent();
                i.putExtra("allfilterstring", (Serializable) allFilterString);
                int currentActivityTypeId = activityTypes.get(mViewPager.getViewPager().getCurrentItem()).getId();
                i.putExtra("activityType", currentActivityTypeId);
                i.putExtra("callType", 1);
                i.setClass(getApplicationContext(), com.strollup.filter.FilterActivity.class);
                startActivityForResult(i, 0);
                overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);

                return true;
            case android.R.id.home:
                showFilter();
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }

    public void showFilter() {
        MenuItem item = menu.findItem(R.id.action_filter);
        item.setVisible(true);
    }

    public void hideFilter() {
        MenuItem item = menu.findItem(R.id.action_filter);
        item.setVisible(false);
    }

    public void loadContent(String url) {
        url = Utils.urlParser(url);
        Cache cache = AppController.getInstance().getRequestQueue().getCache();
        Cache.Entry entry = cache.get(url);
        Map<Type, Object> adapterMap = new HashMap<>();
        adapterMap.put(ListingContext.class, new ListingContextAdapter());
        if (entry != null && entry.serverDate + Constants.BIG_CACHE_EXPIRY_TIME > System.currentTimeMillis()) {
            try {
                String data = new String(entry.data, "UTF-8");
                SearchResponse searchResponse = (SearchResponse) Utils.getCachedResponse(
                        SearchResponse.class, data, adapterMap);
                onSuccess(searchResponse);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            AppController.getInstance().getRequestQueue().getCache().invalidate(url, true);
            myReq = new GsonRequest<SearchResponse>(Request.Method.GET, url, adapterMap, SearchResponse.class,
                    createMyReqSuccessListener(), createMyReqErrorListener());
            AppController.getInstance().addToRequestQueue(myReq, TAG);
        }
    }

    private Response.Listener<SearchResponse> createMyReqSuccessListener() {
        return new Response.Listener<SearchResponse>() {
            @Override
            public void onResponse(SearchResponse searchResponse) {
                onSuccess(searchResponse);
            }
        };
    }

    private Response.ErrorListener createMyReqErrorListener() {
        return new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Error Occured while calling backend", error.getCause());
                if (error instanceof NoConnectionError || error instanceof TimeoutError)
                    Utils.noNetworkMessage(getApplicationContext(), myReq);
            }
        };
    }

    private void onSuccess(SearchResponse listingResult) {
        try {
            hideFilter();
            ListingSearchResponse listingSearchResponse = listingResult.getListingSearchResponseString();
            suggestions = listingSearchResponse.getDtos();
            String[] columns = {
                    BaseColumns._ID, SearchManager.SUGGEST_COLUMN_TEXT_1, SearchManager.SUGGEST_COLUMN_TEXT_2, SearchManager.SUGGEST_URI_PATH_QUERY
            };

            MatrixCursor cursor = new MatrixCursor(columns);
            if (suggestions != null) {

                for (int i = 0; i < suggestions.size(); i++) {
                    String[] tmp = {Integer.toString(i), suggestions.get(i).getName(), suggestions.get(i).getResultType(), suggestions.get(i).getRegion()};
                    cursor.addRow(tmp);
                }
                mCursor = cursor;
                if (cursor != null) {
                    suggestionAdapter.swapCursor(cursor);
                    suggestionAdapter.setPattern(mSearchString);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        showFilter();
        super.onBackPressed();
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}