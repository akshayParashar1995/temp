package com.strollup.main;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.google.gson.Gson;
import com.strollup.request.SavedLocationRequest;
import com.strollup.utility.Constants;
import com.strollup.utility.Globals;
import com.strollup.utility.GsonRequest;
import com.strollup.utility.Utils;

public class FetchSavedMobilePlans {
	private Context context;
	private Activity act;
	private GsonRequest<SavedPlanDataResponse> myReq;

	public void fetchPlans(Context context, Activity activity) {
		this.context = context;
		act = activity;
		SavedLocationRequest savedLocationRequest = new SavedLocationRequest(context);
		savedLocationRequest.setLimit(1000);
		String versionUrl = Constants.BASE_SERVER_URL + "savedPlanMobileWithFilter?savedPlanRequestString="
				+ new Gson().toJson(savedLocationRequest);
		myReq = new GsonRequest<SavedPlanDataResponse>(Request.Method.GET, versionUrl, SavedPlanDataResponse.class,
				createMyReqSuccessListener(), createMyReqErrorListener());
		AppController.getInstance().getRequestQueue().add(myReq);
		SplashScreen.incrementNoOfVolleyRequests();
	}

	private Response.Listener<SavedPlanDataResponse> createMyReqSuccessListener() {
		return new Response.Listener<SavedPlanDataResponse>() {
			@Override
			public void onResponse(SavedPlanDataResponse savedPlanDataResponse) {

				SavedPlanResponse savedPlanResponse = savedPlanDataResponse.getSavedPlanResponse();
				Globals.savedPlans = savedPlanResponse;
				SplashScreen.decrementNoOfVolleyRequests();
			};
		};
	}

	private Response.ErrorListener createMyReqErrorListener() {
		return new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {
				Log.e("Error", "Error occured in backend in fetching saved plans", error.getCause());
				if (error instanceof NoConnectionError || error instanceof TimeoutError)
					Utils.noNetworkMessageSplashScreen(act, myReq);
				SplashScreen.setBooleanTrue();
			}
		};

	}

}
