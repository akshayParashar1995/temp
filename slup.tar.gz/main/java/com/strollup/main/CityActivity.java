package com.strollup.main;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.strollup.utility.AppPreferences;
import com.strollup.utility.Constants;
import com.strollup.utility.Utils;

import in.strollup.android.R;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class CityActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.city_layout);

		final Button delhiCity = (Button) findViewById(R.id.delhi_city_button);
		final Button bangaloreCity = (Button) findViewById(R.id.bangalore_city_button);

		if (AppPreferences.isCitySet(getApplicationContext())) {
			int selectedCityId = AppPreferences.getCityId(getApplicationContext());
			if (selectedCityId == 1) {
				Utils.selectButton(delhiCity, getResources());
			} else {
				Utils.selectButton(bangaloreCity, getResources());
			}
		}
		delhiCity.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				AppPreferences.setCityId(getApplicationContext(), Constants.DELHI_CITY_ID);
				Utils.selectButton(delhiCity, getResources());
				Utils.unselectButton(bangaloreCity, getResources());
				Intent i = new Intent();
				i.setClass(getApplicationContext(), SplashScreen.class);
				startActivity(i);
				finish();
			}
		});

		bangaloreCity.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				AppPreferences.setCityId(getApplicationContext(), Constants.BANGALORE_CITY_ID);
				Utils.selectButton(bangaloreCity, getResources());
				Utils.unselectButton(delhiCity, getResources());
				Intent i = new Intent();
				i.setClass(getApplicationContext(), SplashScreen.class);
				startActivity(i);
				finish();
			}
		});

	}

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}