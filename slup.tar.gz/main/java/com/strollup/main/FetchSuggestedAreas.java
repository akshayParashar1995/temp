package com.strollup.main;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.android.volley.Cache;
import com.android.volley.Cache.Entry;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.google.gson.Gson;
import com.strollup.filter.Region;
import com.strollup.plan.SuggestionsStringDataResponse;
import com.strollup.request.BaseRequest;
import com.strollup.utility.Constants;
import com.strollup.utility.Globals;
import com.strollup.utility.GsonRequest;
import com.strollup.utility.Utils;

import java.util.HashSet;
import java.util.Set;

public class FetchSuggestedAreas {
	private Context context;
	private Activity act;
	private GsonRequest<SuggestionsStringDataResponse> myReq;

	public void fetchAreas(Context context, Activity activity) {
		this.context = context;
		act = activity;
		BaseRequest baseRequest = new BaseRequest(context);
		String versionUrl = Constants.BASE_SERVER_URL + "getRegions?regionBaseRequestString="
				+ new Gson().toJson(baseRequest);
		Cache cache = AppController.getInstance().getRequestQueue().getCache();
		Entry entry = cache.get(versionUrl);
		if (entry != null && entry.serverDate + Constants.BIG_CACHE_EXPIRY_TIME > System.currentTimeMillis()) {
			try {
				SplashScreen.incrementNoOfVolleyRequests();
				String data = new String(entry.data, "UTF-8");
				SuggestionsStringDataResponse suggestionsStringDataResponse = (SuggestionsStringDataResponse) Utils
						.getCachedResponse(SuggestionsStringDataResponse.class, data);
				onSuccess(suggestionsStringDataResponse);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			AppController.getInstance().getRequestQueue().getCache().invalidate(versionUrl, true);
			myReq = new GsonRequest<SuggestionsStringDataResponse>(Request.Method.GET, versionUrl,
					SuggestionsStringDataResponse.class, createMyReqSuccessListener(), createMyReqErrorListener());
			AppController.getInstance().addToRequestQueue(myReq);
			SplashScreen.incrementNoOfVolleyRequests();
		}
	}

	private void onSuccess(SuggestionsStringDataResponse suggestionsStringDataResponse) {
		Set<Region> regions = new HashSet<Region>();
		regions.addAll(suggestionsStringDataResponse.getSuggestionsString());
		Globals.suggestedAreas = regions;
		SplashScreen.decrementNoOfVolleyRequests();
	}

	private Response.Listener<SuggestionsStringDataResponse> createMyReqSuccessListener() {
		return new Response.Listener<SuggestionsStringDataResponse>() {
			@Override
			public void onResponse(SuggestionsStringDataResponse suggestionsStringDataResponse) {
				onSuccess(suggestionsStringDataResponse);
			};
		};
	}

	private Response.ErrorListener createMyReqErrorListener() {
		return new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {
				Log.e("Error", "Error occured in backend", error.getCause());
				if (error instanceof NoConnectionError || error instanceof TimeoutError)
					Utils.noNetworkMessageSplashScreen(act, myReq);
				SplashScreen.setBooleanTrue();
			}
		};

	}
}
