package com.strollup.main;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;

import in.strollup.android.R;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class ScreenShotActivity extends FragmentActivity {
	public static ViewPager viewpager;
	public static ScreenShotAdapter mSectionsPagerAdapter;

	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);
		setContentView(R.layout.sliding_tabs_layout);
		mSectionsPagerAdapter = new ScreenShotAdapter(getSupportFragmentManager());
		viewpager = (ViewPager) findViewById(R.id.pager);
		viewpager.setAdapter(mSectionsPagerAdapter);
		//PagerSlidingTabStrip tabs = (PagerSlidingTabStrip) findViewById(R.id.tabs);
		//tabs.setVisibility(View.GONE);
	}

	public class ScreenShotAdapter extends FragmentPagerAdapter {

		public ScreenShotAdapter(FragmentManager fm) {
			super(fm);
		}

		@Override
		public Fragment getItem(int position) {
			Fragment fragment = new ScreenShotFragment(position);
			return fragment;
		}

		@Override
		public int getCount() {
			return 3;
		}

		@Override
		public CharSequence getPageTitle(int position) {
			switch (position) {
			default:
				return "Tutorial";
			}
		}
	}

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
