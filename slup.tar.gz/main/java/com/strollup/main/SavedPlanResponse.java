package com.strollup.main;

import com.strollup.plan.MobilePlan;

import java.util.ArrayList;
import java.util.List;

public class SavedPlanResponse {
	private List<MobilePlan> plans = new ArrayList<MobilePlan>();
	private List<Integer> planInfoIds = new ArrayList<Integer>();
	private int count;

	public List<MobilePlan> getPlans() {
		return plans;
	}

	public void setPlans(List<MobilePlan> plans) {
		this.plans = plans;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public List<Integer> getPlanInfoIds() {
		return planInfoIds;
	}

	public void setPlanInfoIds(List<Integer> planInfoIds) {
		this.planInfoIds = planInfoIds;
	}

}
