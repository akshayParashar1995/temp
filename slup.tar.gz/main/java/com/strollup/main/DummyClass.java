package com.strollup.main;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

import com.strollup.filter.AllFilterString;

import java.io.Serializable;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class DummyClass extends FragmentActivity{
@Override
	public void onCreate(Bundle arg0)
	{
		super.onCreate(arg0);
		Intent i1=getIntent();
		AllFilterString allFilterString = (AllFilterString) i1.getSerializableExtra("allfilterstring");
		int tabPosition=i1.getIntExtra("tabPosition",0);
        String customString=i1.getStringExtra("customString");
		Intent i2 = new Intent(getApplicationContext(), ExploreTabListing.class);
		i2.putExtra("allfilterstring",(Serializable)allFilterString );
		i2.putExtra("tabPosition",tabPosition);
        i2.putExtra("customString",customString);

        startActivity(i2);
		finish();
	}

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
