package com.strollup.main;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.strollup.utility.Constants;

import in.strollup.android.R;

public class AppRater {
	private final static String APP_TITLE = "StrollUp";
	private final static int DAYS_UNTIL_PROMPT = 3;
	private final static int LAUNCHES_UNTIL_PROMPT = 7;

	public static void app_launched(Context mContext) {
		SharedPreferences prefs = mContext.getSharedPreferences("apprater", 0);
		if (prefs.getBoolean("dontshowagain", false)) {
			return;
		}
		SharedPreferences.Editor editor = prefs.edit();
		long launch_count = prefs.getLong("launch_count", 0) + 1;
		editor.putLong("launch_count", launch_count);

		Long date_firstLaunch = prefs.getLong("date_firstlaunch", 0);
		if (date_firstLaunch == 0) {
			date_firstLaunch = System.currentTimeMillis();
			editor.putLong("date_firstlaunch", date_firstLaunch);
		}

		if (launch_count >= LAUNCHES_UNTIL_PROMPT) {
			if (System.currentTimeMillis() >= date_firstLaunch + (DAYS_UNTIL_PROMPT * 24 * 60 * 60 * 1000)) {
				Log.i("rater", "show dialog");
				showRateDialog(mContext, editor);
			}
		}

		editor.commit();
	}

	public static void showRateDialog(final Context mContext, final SharedPreferences.Editor editor) {
		final Dialog dialog2 = new Dialog(mContext, android.R.style.Theme_DeviceDefault_Light_Dialog);
		dialog2.setContentView(R.layout.custom_app_rater_dialog);
		dialog2.setTitle("Rate " + APP_TITLE);

		TextView appRateText = (TextView) dialog2.findViewById(R.id.rate_app_text);
		Button rateAppButton = (Button) dialog2.findViewById(R.id.rate_now);
		// Button laterButton = (Button) dialog2.findViewById(R.id.rate_later);
		Button notNowButton = (Button) dialog2.findViewById(R.id.no_thanks);

		appRateText.setText("Love " + APP_TITLE + " app?" + "\n\nPlease take a moment to rate us.");
		rateAppButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				mContext.startActivity(new Intent(Intent.ACTION_VIEW, Uri
						.parse("https://play.google.com/store/apps/details?id=" + Constants.APP_PACKAGE_NAME)));
				if (editor != null) {
					editor.putBoolean("dontshowagain", true);
					editor.commit();
				}
				dialog2.dismiss();
			}
		});

		notNowButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (editor != null) {
					editor.putBoolean("dontshowagain", true);
					editor.commit();
				}
				dialog2.dismiss();
			}
		});
		dialog2.show();
	}
}
