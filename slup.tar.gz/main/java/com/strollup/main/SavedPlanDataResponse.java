package com.strollup.main;

public class SavedPlanDataResponse {
	private SavedPlanResponse savedPlanResponse;

	public SavedPlanResponse getSavedPlanResponse() {
		return savedPlanResponse;
	}

	public void setSavedPlanResponse(SavedPlanResponse savedPlanResponse) {
		this.savedPlanResponse = savedPlanResponse;
	}

}
