package com.strollup.main;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import com.strollup.login.CreateAccountActivity;
import com.strollup.place.PlaceDetailActivity;
import com.strollup.utility.AppPreferences;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class DeepLinkingActivity extends Activity {
	int activity_id;
	int location_detail_id;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Intent intent = getIntent();
		String action = intent.getAction();
		Uri data = intent.getData();
		String path = data.toString();
		if (openPlaceDetailActivity(path)) {
			if (AppPreferences.isLoggedIn(getApplicationContext())) {
				Intent i = new Intent(DeepLinkingActivity.this, PlaceDetailActivity.class);
				i.putExtra("activity_id", activity_id);
				i.putExtra("location_detail_id", location_detail_id);
				i.putExtra("inApp", false);
				startActivity(i);
				finish();
			} else {

				Intent i = new Intent(DeepLinkingActivity.this, CreateAccountActivity.class);
				i.putExtra("redirect_url", PlaceDetailActivity.class);
				i.putExtra("activity_id", activity_id);
				i.putExtra("location_detail_id", location_detail_id);
				i.putExtra("inApp", false);
				startActivity(i);
				finish();

			}

		} else {

			Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(path));
			i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			i.setPackage("com.android.chrome");
			try {
				startActivity(i);
			} catch (ActivityNotFoundException ex) {
				// Chrome browser presumably not installed so allow user to
				// choose instead
				i.setPackage(null);
				startActivity(i);
				Log.e("chrome not found", "shesh");

			}
		}

		data.toString().lastIndexOf("-");
	}

	boolean openPlaceDetailActivity(String path) {
		if (path.contains("movies")||path.contains("events")) {
			int pos = path.lastIndexOf("-");
			String id = path.substring(pos + 1);
			activity_id = Integer.parseInt(id);
			location_detail_id = -1;
			return true;

		} else if (path.contains("-places")) {
			int pos = path.lastIndexOf("-");
			String id = path.substring(pos + 1);
			activity_id = -1;
			location_detail_id = Integer.parseInt(id);
			return true;

		} else {
			return false;
		}
	}

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
