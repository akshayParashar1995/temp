package com.strollup.main;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;

import java.util.List;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class ContactUs extends Activity {
	private Intent sendIntent;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		sendIntent = new Intent(Intent.ACTION_SEND);
		sendIntent.setType("plain/text");
//		sendIntent.setClassName("com.google.android.gm", "com.google.android.gm.ComposeActivityGmail");
		sendIntent.putExtra(Intent.EXTRA_SUBJECT, "Contact StrollUp");
		sendIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[] { "connect@strollup.in" });

		PackageManager packageManager = getPackageManager();
		List<ResolveInfo> activities = packageManager.queryIntentActivities(sendIntent, 0);
		boolean isIntentSafe = activities.size() > 0;
		if (isIntentSafe) {
			startActivity(Intent.createChooser(sendIntent, "Choose an Email Client"));
		}
		finish();
	}

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
