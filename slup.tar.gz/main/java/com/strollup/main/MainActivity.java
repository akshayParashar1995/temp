package com.strollup.main;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.strollup.login.CreateAccountActivity;
import com.strollup.utility.AppPreferences;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Intent intent = new Intent();
		if(AppPreferences.isLoggedIn(getApplicationContext())) {
			intent = new Intent(getApplicationContext(), SplashScreen.class);
		} else {
			intent = new Intent(getApplicationContext(), CreateAccountActivity.class);
		}		
		startActivity(intent);
		finish();
	}

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
