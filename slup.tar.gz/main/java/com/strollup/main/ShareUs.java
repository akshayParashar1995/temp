package com.strollup.main;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.strollup.utility.Constants;

import java.util.List;

import in.strollup.android.R;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class ShareUs extends AppCompatActivity {
	private Button whatsappShare;
	private Button facebookShare;
	private Button emailShare;
	private Button more;
	private Intent sendIntent;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.share_us_layout);
		whatsappShare = (Button) findViewById(R.id.whatsapp_button);
		facebookShare = (Button) findViewById(R.id.facebook_button);
		emailShare = (Button) findViewById(R.id.email_button);
		more = (Button) findViewById(R.id.more_options_button);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setTitle("Invite Friends");

		whatsappShare.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				sendIntent = new Intent();
				sendIntent.setAction(Intent.ACTION_SEND);
				sendIntent.putExtra(Intent.EXTRA_TEXT, Constants.SHARE_APP_TEXT);
				sendIntent.setType("text/plain");
				sendIntent.setPackage("com.whatsapp");
				PackageManager packageManager = getPackageManager();
				List<ResolveInfo> activities = packageManager.queryIntentActivities(sendIntent, 0);
				boolean isIntentSafe = activities.size() > 0;
				if (isIntentSafe)
					startActivity(sendIntent);
				else
					Toast.makeText(getApplicationContext(), "Whatsapp not installed", Toast.LENGTH_LONG).show();
			}
		});

		emailShare.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				sendIntent = new Intent(Intent.ACTION_VIEW);
				sendIntent.setType("plain/text");
				sendIntent.setClassName("com.google.android.gm", "com.google.android.gm.ComposeActivityGmail");
				sendIntent.putExtra(Intent.EXTRA_SUBJECT, "StrollUp");
				sendIntent.putExtra(Intent.EXTRA_TEXT, Constants.SHARE_APP_TEXT);

				PackageManager packageManager = getPackageManager();
				List<ResolveInfo> activities = packageManager.queryIntentActivities(sendIntent, 0);
				boolean isIntentSafe = activities.size() > 0;
				if (isIntentSafe)
					startActivity(sendIntent);
				else
					Toast.makeText(getApplicationContext(), "Gmail not installed", Toast.LENGTH_LONG).show();
			}
		});

		facebookShare.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				sendIntent = new Intent(Intent.ACTION_SEND);
				sendIntent.setType("text/plain");
				sendIntent.putExtra(Intent.EXTRA_TEXT, Constants.SHARE_APP_TEXT);
				sendIntent.setPackage("com.facebook.katana");

				PackageManager packageManager = getPackageManager();
				List<ResolveInfo> activities = packageManager.queryIntentActivities(sendIntent, 0);
				boolean isIntentSafe = activities.size() > 0;
				if (isIntentSafe)
					startActivity(sendIntent);
				else
					Toast.makeText(getApplicationContext(), "Facebook not installed", Toast.LENGTH_LONG).show();
			}
		});

		more.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				sendIntent = new Intent();
				sendIntent.setAction(Intent.ACTION_SEND);
				sendIntent.putExtra(Intent.EXTRA_TEXT, Constants.SHARE_US_TEXT);
				sendIntent.setType("text/plain");
				startActivity(sendIntent);
			}
		});

	}

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }
}

