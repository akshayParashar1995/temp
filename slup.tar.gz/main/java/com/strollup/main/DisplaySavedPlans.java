package com.strollup.main;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.strollup.personal.DisplayPlansAdapter;
import com.strollup.plan.MobilePlan;
import com.strollup.utility.Globals;

import java.util.List;

import in.strollup.android.R;

public class DisplaySavedPlans extends Fragment {
	List<MobilePlan> plans;
	RelativeLayout layout;

	@Override
	public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View v = inflater.inflate(R.layout.display_saved_plans_layout, null);
		layout = (RelativeLayout) v.findViewById(R.id.no_saved_plans_layout);

		plans = Globals.savedPlans.getPlans();
		if (plans.size() == 0) {
			TextView noText = (TextView) v.findViewById(R.id.no_save_text);
			layout.setVisibility(View.VISIBLE);

		} else {
			final ListView lv = (ListView) v.findViewById(R.id.plans_list_view);
			DisplayPlansAdapter adapter = new DisplayPlansAdapter(getActivity(), 0, plans, lv);
			lv.setAdapter(adapter);
		}

		return v;

	}

}
