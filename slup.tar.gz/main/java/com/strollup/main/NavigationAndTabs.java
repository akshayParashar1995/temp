package com.strollup.main;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.strollup.blogs.BlogActivity;
import com.strollup.personal.PersonalMainActivity;
import com.strollup.utility.AppPreferences;
import com.strollup.utility.Constants;

import java.util.List;

import in.strollup.android.R;
import it.neokree.materialnavigationdrawer.MaterialNavigationDrawer;
import it.neokree.materialnavigationdrawer.elements.MaterialAccount;
import it.neokree.materialnavigationdrawer.elements.MaterialSection;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

/**
 * Created by chhavi on 6/7/15.
 */
public class NavigationAndTabs extends MaterialNavigationDrawer {
    private Bitmap userImage;
    private Bitmap backgroundImage;
    private MaterialAccount account;
    private boolean fromGcm = false;
    private boolean isCalledByOutingDiscuss=false;

    @Override
    public void init(Bundle bundle) {
        Bundle extras = getIntent().getExtras();
        if(extras!=null){
            if(extras.getBoolean("isCalledByGcm"))
                fromGcm = true;
            if(extras.getBoolean("isCalledByOutingDiscuss"))
                isCalledByOutingDiscuss=true;
        }
        this.disableLearningPattern();

        View view = LayoutInflater.from(this).inflate(R.layout.custom_drawer_header, null);
        setDrawerHeaderCustom(view);
        ImageView iv = (ImageView) view.findViewById(R.id.user_image);
        TextView userName = (TextView) view.findViewById(R.id.user_name);
        userName.setText(AppPreferences.getUsername(this));
        String userPhotoUrl = AppPreferences.getUserPhoto(NavigationAndTabs.this);
        if (userPhotoUrl != null) {
            Picasso.with(this).load(userPhotoUrl).placeholder(R.drawable.profile_placeholder).error(R.drawable.error_image).into(iv);
        }

        final MaterialNavigationDrawer drawer = this;
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), PersonalMainActivity.class);
                startActivity(intent);
                drawer.closeDrawer();
            }
        });
        android.support.v4.app.Fragment tabbedFragment = TabbedActivity.newInstance();
        if (fromGcm) {
            Bundle tabBundle = new Bundle();
            int tabbedPos = extras.getInt("tabbedPosition");
            tabBundle.putBoolean("isCalledByGcm",true);
            tabBundle.putInt("tabbedPosition",tabbedPos);
            tabbedFragment.setArguments(tabBundle);

        }
        else if(isCalledByOutingDiscuss){
            Bundle tabBundle=new Bundle();
            tabBundle.putBoolean("isCalledByOutingDiscuss",true);
            tabbedFragment.setArguments(tabBundle);
        }

        this.addSection(newSection("Home", R.drawable.ic_home_white_18dp, tabbedFragment));
        String currentCityName = Constants.CITY_MAP.get(AppPreferences.getCityId(getApplicationContext()));
        Intent intent = new Intent(this, CityActivity.class);

        this.addSection(newSection("Change City", R.drawable.ic_place_white_18dp, intent).setSectionColor(getResources().getColor(R.color.white)));

        intent = new Intent(this, PersonalMainActivity.class);
        this.addSection(newSection("Personalize", R.drawable.ic_wb_incandescent_white_18dp, intent).setSectionColor(getResources().getColor(R.color.white)));

        intent = new Intent(this, PersonalMainActivity.class);
        intent.putExtra("tabbedPosition", 1);
        this.addSection(newSection("Bookmarks", R.drawable.ic_bookmark_white_18dp, intent).setSectionColor(getResources().getColor(R.color.white)));

        intent = new Intent(this, BlogActivity.class);
        this.addSection(newSection("Collections", R.drawable.ic_apps_white_18dp, intent).setSectionColor(getResources().getColor(R.color.white)));

        intent = new Intent(this, ShareUs.class);
        this.addSection(newSection("Invite Friends", R.drawable.ic_people_white_18dp, intent).setSectionColor(getResources().getColor(R.color.white)));

        intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id="
                + Constants.APP_PACKAGE_NAME));
        this.addSection(newSection("Rate Our App", R.drawable.ic_star_white_18dp, intent).setSectionColor(getResources().getColor(R.color.white)));


        intent = new Intent(this, ContactUs.class);
        this.addSection(newSection("Contact Us", R.drawable.ic_email_white_18dp, intent).setSectionColor(Color.parseColor("#FFFFFF")));

        Typeface font = Typeface.createFromAsset(this.getAssets(), Constants.BOLD_FONT);
        this.getToolbar().setTitleTextColor(getResources().getColor(R.color.white));
        this.getToolbar().setTitle("StrollUp");
        this.changeToolbarColor(R.color.dark_green, R.color.white);

        List<MaterialSection> sectionList = this.getSectionList();

        for (MaterialSection section : sectionList) {
            section.setTypeface(font);
        }
        this.setDrawerBackgroundColor(Color.parseColor("#FFFFFF"));
        allowArrowAnimation();
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
