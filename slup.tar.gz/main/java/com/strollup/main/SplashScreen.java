package com.strollup.main;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.crashlytics.android.Crashlytics;
import com.strollup.gcm.CreateRegisterId;
import com.strollup.gcm.NotificationHandler;
import com.strollup.notification.CheckForNotifications;
import com.strollup.save.SaveLocationController;
import com.strollup.update.CheckForUpdates;

import in.strollup.android.R;
import io.fabric.sdk.android.Fabric;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class SplashScreen extends Activity {

    public static int noOfVolleyRequests = 0;
    public static boolean isError = false;

    public static void incrementNoOfVolleyRequests() {
        noOfVolleyRequests++;
    }

    public static void decrementNoOfVolleyRequests() {
        noOfVolleyRequests--;
    }

    public static void setBooleanTrue() {
        if (!isError)
            isError = true;

    }

    public static void setBooleanFalse() {
        if (isError)
            isError = false;

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        noOfVolleyRequests = 0;
        isError = false;
        Fabric.with(this, new Crashlytics());

        setContentView(R.layout.splash_screen);

        new CreateRegisterId().getRegisterId(getApplicationContext());
        new CheckForUpdates().checkIfThereIsAnyUpdate(getApplicationContext(), SplashScreen.this);
        new CheckForNotifications().checkIfThereIsAnyNotification(getApplicationContext(), SplashScreen.this);
        new SaveLocationController().fetchAllSavedLocations(getApplicationContext(), SplashScreen.this);
        new FetchSuggestedAreas().fetchAreas(getApplicationContext(), SplashScreen.this);
        new FetchSavedMobilePlans().fetchPlans(getApplicationContext(), SplashScreen.this);
        Thread splashTread = new Thread() {
            @Override
            public void run() {
                try {
                    while (noOfVolleyRequests != 0) {
                        sleep(300);
                    }
                } catch (InterruptedException e) {

                } finally {
                    Bundle bundle = getIntent().getExtras();
                    if (bundle != null && "gcm_notification".equals(bundle.getString("called_by"))) {
                        NotificationHandler.handleNotification(bundle, getApplicationContext());
                        setBooleanFalse();
                        finish();
                    } else {
                        startActivity(new Intent(getApplicationContext(), NavigationAndTabs.class));
                        setBooleanFalse();
                        finish();
                    }
                }
            }
        };
        splashTread.start();
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
