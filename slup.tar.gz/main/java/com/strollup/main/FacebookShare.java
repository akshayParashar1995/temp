package com.strollup.main;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.share.Sharer;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.widget.ShareDialog;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;
import com.strollup.utility.AppPreferences;
import com.strollup.utility.Constants;

import in.strollup.android.BuildConfig;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class FacebookShare extends Activity {

	private CallbackManager callbackManager;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		FacebookSdk.sdkInitialize(getApplicationContext());
		callbackManager = CallbackManager.Factory.create();

		ShareDialog shareDialog = new ShareDialog(this);
		shareDialog.registerCallback(callbackManager, new FacebookCallback<Sharer.Result>() {
			@Override
			public void onSuccess(Sharer.Result result) {
				// TODO Auto-generated method stub
				if (result.getPostId() != null) {
					AppPreferences.setIsSharedSucessfullyOnFb(getApplicationContext());
                    if (!BuildConfig.DEBUG) {
                        GoogleAnalytics analytics = GoogleAnalytics.getInstance(getApplicationContext());
                        Tracker tracker = analytics.newTracker(Constants.GOOGLE_ANALYTICS_URL);
                        tracker.setScreenName("Plan Page");
                        tracker.send(new HitBuilders.EventBuilder().setCategory("UX").setAction("click").setLabel("restrictedShare").build());
                    }
				}
				finish();
			}

			@Override
			public void onCancel() {
				// TODO Auto-generated method stub
				finish();
			}

			@Override
			public void onError(FacebookException error) {
				// TODO Auto-generated method stub
				finish();
			}

		});
		if (ShareDialog.canShow(ShareLinkContent.class)) {
			ShareLinkContent linkContent = new ShareLinkContent.Builder().setContentTitle("Strollup - Plan your day out")
					.setContentDescription("Easiest way to plan your awesome day out. Get personalized plans based on mood, likes and interests in just 2 taps.")
					.setContentUrl(Uri.parse(Constants.SHARE_APP_LINK)).build();
			shareDialog.show(linkContent, ShareDialog.Mode.FEED);
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		callbackManager.onActivityResult(requestCode, resultCode, data);
	}

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
