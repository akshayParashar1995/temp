package com.strollup.main;

import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.github.florent37.materialviewpager.MaterialViewPager;
import com.strollup.activity.ActivityFragment;
import com.strollup.plan.PlanMyDayFirst;
import com.strollup.trending.TrendingFragment;
import com.strollup.utility.Constants;

import java.util.Locale;

import in.strollup.android.R;
import it.neokree.materialnavigationdrawer.MaterialNavigationDrawer;

public class TabbedActivity extends Fragment {

	public static final String TAG = TabbedActivity.class.getSimpleName();
	private SectionsPagerAdapter mSectionsPagerAdapter;
	private MaterialViewPager mViewPager;
	private View v;
    private boolean isCalledByOutingDiscuss=false;

	Bundle extras;

	public static TabbedActivity newInstance() {
		return new TabbedActivity();
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.setHasOptionsMenu(true);

	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		((MaterialNavigationDrawer)this.getActivity()).getToolbar().setTitle("StrollUp");

		v = inflater.inflate(R.layout.sliding_tabs_layout, container, false);
		mSectionsPagerAdapter = new SectionsPagerAdapter(getFragmentManager());
		mViewPager = (MaterialViewPager)v.findViewById(R.id.pager);
		mViewPager.getViewPager().setAdapter(mSectionsPagerAdapter);
		mViewPager.getViewPager().setOffscreenPageLimit(3);
		mViewPager.getToolbar().setVisibility(View.GONE);
		mViewPager.getViewPager().setCurrentItem(Constants.HOME_TAB_POSITION);
		Typeface font = Typeface.createFromAsset(getActivity().getAssets(), Constants.BASE_FONT);
		mViewPager.getPagerTitleStrip().setTypeface(font,0);
		mViewPager.getPagerTitleStrip().setViewPager(mViewPager.getViewPager());
		Bundle bundle=getArguments();
		if(bundle!=null){

            if(bundle.getBoolean("isCalledByOutingDiscuss")) {
                isCalledByOutingDiscuss=true;
                mViewPager.getViewPager().setCurrentItem(0);
            }
            int position = bundle.getInt("tabbedPosition");
            mViewPager.getViewPager().setCurrentItem(position);
		}

		return v;

	}

	public class SectionsPagerAdapter extends FragmentPagerAdapter {

		public SectionsPagerAdapter(FragmentManager fm) {
			super(fm);
		}

		@Override
		public Fragment getItem(int position) {
			switch (position) {
			case 0:
				Fragment fragment = new PlanMyDayFirst();
                if(isCalledByOutingDiscuss){
                    Bundle args = new Bundle();
                    args.putBoolean("isCalledByOutingDiscuss",true);
                    fragment.setArguments(args);
                }
				return fragment;
			case 1:
				fragment = new ActivityFragment();
				return fragment;
			case 2:
				fragment = new TrendingFragment();
				return fragment;
			default:
				fragment = new TabbedContentFragment();
				Bundle args = new Bundle();
				args.putInt(TabbedContentFragment.ARG_SECTION_NUMBER, position);
				fragment.setArguments(args);
				return fragment;
			}
		}

		@Override
		public int getCount() {
			return 3;
		}

		@Override
		public CharSequence getPageTitle(int position) {
			Locale l = Locale.getDefault();
			switch (position) {
			case 0:
				return getString(R.string.tabs_plan_my_day);
			case 1:
				return getString(R.string.tabs_explore);
			case 2:
				return getString(R.string.tabs_themes);
			}
			return null;
		}
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		super.onCreateOptionsMenu(menu, inflater);
		menu.clear();
		inflater.inflate(R.menu.fragment_menu, menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		// if (id == R.id.filter) {
		// Intent i = new Intent(getActivity(), FilterActivity.class);
		// startActivity(i);
		//
		// }
		return super.onOptionsItemSelected(item);
	}

	public static class TabbedContentFragment extends Fragment {

		public static final String ARG_SECTION_NUMBER = "section_number";

		public TabbedContentFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
			View rootView = null;
			switch (getArguments().getInt(ARG_SECTION_NUMBER)) {
			case 0:
				rootView = inflater.inflate(R.layout.plan_my_day, null);
				break;
			case 1:
				rootView = inflater.inflate(R.layout.activities_grid, null);
				break;
			case 2:
				rootView = inflater.inflate(R.layout.trending_whole, null);
				break;
			}
			return rootView;
		}
	}

}
