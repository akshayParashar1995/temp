package com.strollup.search;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import java.lang.reflect.Type;

/**
 * Created by DELL LAPTOP on 7/22/2015.
 */
public class ListingContextAdapter implements JsonSerializer<ListingContext>, JsonDeserializer<ListingContext> {

    /**
     * Deserialize the json locationDetail into locationdetail Object It takes into account of polymorphism as
     * locationDetail { type: ClassName properties: All other member variables }
     * */
    @Override
    public ListingContext deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) {
        JsonObject jsonObject = json.getAsJsonObject();
        String type = jsonObject.get("type").getAsString();
        try {
            if (jsonObject.get("properties") != null) {
                jsonObject = jsonObject.get("properties").getAsJsonObject();
            }
            return context.deserialize(jsonObject, Class.forName("com.strollup.search." + type));
        } catch (ClassNotFoundException cnfe) {
            throw new JsonParseException("Unknown element type: " + type, cnfe);
        }

    }

    /**
     * serialize the locationDetail into json locationdetail It takes into account of polymorphism as locationDetail {
     * type: ClassName properties: All other member variables }
     * */
    @Override
    public JsonElement serialize(ListingContext src, Type typeOfSrc, JsonSerializationContext context) {
        JsonObject result = new JsonObject();
        result.add("type", new JsonPrimitive(src.getClass().getSimpleName()));
        result.add("properties", context.serialize(src, src.getClass()));
        return result;
    }
}