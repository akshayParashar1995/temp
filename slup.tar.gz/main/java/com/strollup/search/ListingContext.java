package com.strollup.search;

/**
 * Created by DELL LAPTOP on 7/13/2015.
 */
public class ListingContext {
}
