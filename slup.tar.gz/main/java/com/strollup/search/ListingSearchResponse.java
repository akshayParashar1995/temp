package com.strollup.search;

import java.util.List;
/**
 * Created by DELL LAPTOP on 7/13/2015.
 */


/**
 * This object is given as response to search suggestion on listing page. and is used to populate by
 * {@link
 *
 * @author siddharth
 */
public class ListingSearchResponse {

    private List<ListingSearchDto> dtos;

    public List<ListingSearchDto> getDtos() {
        return dtos;
    }

    public void setDtos(List<ListingSearchDto> dtos) {
        this.dtos = dtos;
    }

}

