package com.strollup.search;

/**
 * Created by DELL LAPTOP on 7/13/2015.
 */
public class ListingSearchDto {

    private ListingContext listingContext;
    private String name;
    private String region;

    public String getResultType() {
        return resultType;
    }

    public void setResultType(String resultType) {
        this.resultType = resultType;
    }

    private String resultType;
    public ListingContext getListingContext() {
        return listingContext;
    }

    public void setListingContext(ListingContext listingContext) {
        this.listingContext = listingContext;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }
}

