package com.strollup.search;

/**
 * Created by DELL LAPTOP on 7/13/2015.
 */


/**
 * This object is given as response to search suggestion on listing page. and is used to populate by
 * {@link
 *
 * @author siddharth
 */
public class SearchResponse {

    private ListingSearchResponse listingSearchResponseString;

    public ListingSearchResponse getListingSearchResponseString() {
        return listingSearchResponseString;
    }

    public void setListingSearchResponseString(ListingSearchResponse listingSearchResponseString) {
        this.listingSearchResponseString = listingSearchResponseString;
    }



}

