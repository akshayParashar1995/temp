package com.strollup.search;


public class PlanContext extends ListingContext {

}
