package com.strollup.search;

import com.strollup.request.ActivityAtLocation;

public class LocationContext extends ListingContext {

	private ActivityAtLocation activityLocation;

	public ActivityAtLocation getActivityLocation() {
		return activityLocation;
	}

	public void setActivityLocation(ActivityAtLocation activityLocation) {
		this.activityLocation = activityLocation;
	}

}
