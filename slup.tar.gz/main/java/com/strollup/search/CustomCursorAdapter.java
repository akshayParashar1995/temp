package com.strollup.search;

import android.content.Context;
import android.database.MatrixCursor;
import android.support.v4.widget.SimpleCursorAdapter;
import android.text.Html;
import android.view.LayoutInflater;
import android.widget.TextView;

import java.util.Locale;

import in.strollup.android.R;

/**
 * Created by DELL LAPTOP on 7/14/2015.
 */

public class CustomCursorAdapter extends SimpleCursorAdapter {
    private String[] from;

    public String getPattern() {
        return pattern;
    }

    public void setPattern(String pattern) {
        this.pattern = pattern;
    }

    private String pattern = null;
    private Context context;
    private final LayoutInflater inflater;


    public MatrixCursor getC() {
        return c;
    }

    public void setC(MatrixCursor c) {
        this.c = c;
    }

    private MatrixCursor c;

    public CustomCursorAdapter(Context context, int layout, MatrixCursor c, String[] from, int[] to) {
        super(context, layout, c, from, to);
        this.from = from;
        this.c = c;
        this.context = context;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public void setViewText(TextView v, String text) {
        v.setText(Html.fromHtml(convText(v, text)));
//        super.setViewText(v, convText(v, text));
//        super.setViewText(v, convText(v, text));
    }


    private String convText(TextView v, String text) {

        switch (v.getId()) {
            case R.id.title:
                String itemValue = text;
                String filter = pattern;
                if(filter==null||filter.equals(""))
                {
                    return text;
                }
                int startPos = itemValue.toLowerCase(Locale.US).indexOf(filter.toLowerCase(Locale.US));
                int endPos = startPos + filter.length();

                if (startPos != -1) // This should always be true, just a sanity check
                {
                    itemValue = itemValue.substring(0, startPos) + "<font color=\"#0099CC\"><b>" + itemValue.substring(startPos, endPos) + "</b></font>" + itemValue.substring(endPos , itemValue.length());

                    return itemValue;
                }
                return itemValue;
        }
        return text;
    }


}