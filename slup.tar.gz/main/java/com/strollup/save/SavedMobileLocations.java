package com.strollup.save;

import java.util.List;

public class SavedMobileLocations {

	private int locationCount;
	private List<SavedMobileLocationDto> locations;

	public int getLocationCount() {
		return locationCount;
	}

	public void setLocationCount(int locationCount) {
		this.locationCount = locationCount;
	}

	public List<SavedMobileLocationDto> getLocations() {
		return locations;
	}

	public void setLocations(List<SavedMobileLocationDto> locations) {
		this.locations = locations;
	}
}
