package com.strollup.save;

public class SaveLocationResponseString {

	private boolean saveLocationResponseString;

	public boolean isSaveLocationResponseString() {
		return saveLocationResponseString;
	}

	public void setSaveLocationResponseString(boolean saveLocationResponseString) {
		this.saveLocationResponseString = saveLocationResponseString;
	}
	
}
