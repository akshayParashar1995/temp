package com.strollup.save;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.google.gson.Gson;
import com.strollup.main.AppController;
import com.strollup.main.SplashScreen;
import com.strollup.model.location.LocationDto;
import com.strollup.request.ActivityLocation;
import com.strollup.request.SaveLocationRequest;
import com.strollup.request.SavedLocationRequest;
import com.strollup.utility.Constants;
import com.strollup.utility.Globals;
import com.strollup.utility.GsonRequest;
import com.strollup.utility.Utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SaveLocationController {
	private Activity act;
	private GsonRequest<SavedListingMobileResponse> myReq;
	private static final String TAG = SaveLocationController.class.getSimpleName();

	public List<ActivityLocation> fetchAllSavedLocations(Context context, Activity activity) {
		act = activity;
		SavedLocationRequest locationRequest = new SavedLocationRequest(context);
		String url = Constants.BASE_SERVER_URL + "savedLocationMobile?savedLocationRequestString="
				+ new Gson().toJson(locationRequest);
		myReq = new GsonRequest<SavedListingMobileResponse>(Request.Method.GET, url, SavedListingMobileResponse.class,
				createMyReqSuccessListener(), createMyReqErrorListener());
		AppController.getInstance().addToRequestQueue(myReq, TAG);
		SplashScreen.incrementNoOfVolleyRequests();
		return Globals.listOfSavedLocations;

	}

	private Response.Listener<SavedListingMobileResponse> createMyReqSuccessListener() {
		return new Response.Listener<SavedListingMobileResponse>() {
			@Override
			public void onResponse(SavedListingMobileResponse savedListingMobileResponse) {
				List<ActivityLocation> activityLocations = new ArrayList<ActivityLocation>();
				List<SavedMobileLocationDto> savedLocations = savedListingMobileResponse
						.getSavedLocationResponseString().getLocations();
				for (SavedMobileLocationDto savedMobileLocationDto : savedLocations) {
					ActivityLocation activityLocation = new ActivityLocation(savedMobileLocationDto.getLocation()
							.getId(), savedMobileLocationDto.getLocation().getActivityId());
					activityLocations.add(activityLocation);
				}
				Globals.listOfSavedLocations = activityLocations;
				Globals.savedLoacations = savedLocations;
				SplashScreen.decrementNoOfVolleyRequests();
			};
		};
	}

	public void addLocationToListOfSavedLocations(LocationDto locationDto, ActivityLocation location, Context context) {
		if (Globals.listOfSavedLocations == null) {
			Globals.listOfSavedLocations = new ArrayList<ActivityLocation>();
		}
		Globals.listOfSavedLocations.add(location);
		SavedMobileLocationDto savedMobileLocationDto = new SavedMobileLocationDto();
		savedMobileLocationDto.setLocation(locationDto);
		String date=new SimpleDateFormat(Utils.SAVED_DATE_FORMAT).format(new Date());
		savedMobileLocationDto.setSavedDate(date);
		Globals.savedLoacations.add(savedMobileLocationDto);
		sendIsBookmarkedDataToBackend(location, context, true);

	}

	public void removeFromSavedLocations(LocationDto locationDto, ActivityLocation location, Context context) {
		if (Globals.listOfSavedLocations.contains(location)) {
			int index=Globals.listOfSavedLocations.indexOf(location);
			Globals.listOfSavedLocations.remove(location);

			Globals.savedLoacations.remove(index);
			sendIsBookmarkedDataToBackend(location, context, false);
		}
	}

	public boolean isThisLocationAlreadyPresent(ActivityLocation location) {
		if (Globals.listOfSavedLocations == null || Globals.listOfSavedLocations.size() == 0) {
			return false;
		}
		if (Globals.listOfSavedLocations.contains(location)) {
			return true;
		}
		return false;
	}

	private void sendIsBookmarkedDataToBackend(ActivityLocation location, Context context, boolean isBookmarked) {
		SaveLocationRequest locationRequest = new SaveLocationRequest(context, isBookmarked, location);
		String versionUrl = Constants.BASE_SERVER_URL + "saveLocation?saveLocationRequestString="
				+ new Gson().toJson(locationRequest);
		GsonRequest<SaveLocationResponseString> saveRequestResponse = new GsonRequest<SaveLocationResponseString>(
				Request.Method.GET, versionUrl, SaveLocationResponseString.class, createMyReqSuccessListener(context),
				createBookmarkErrorListener());
		AppController.getInstance().addToRequestQueue(saveRequestResponse, TAG);
	}

	private static Response.Listener<SaveLocationResponseString> createMyReqSuccessListener(final Context context) {
		return new Response.Listener<SaveLocationResponseString>() {
			@Override
			public void onResponse(SaveLocationResponseString saveLocationResponseString) {
			}
		};
	}

	private Response.ErrorListener createMyReqErrorListener() {
		return new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {
				Log.e("Error", "Error occured in backend controller", error.getCause());
				// SplashScreen.decrementNoOfVolleyRequests();
				if (error instanceof NoConnectionError || error instanceof TimeoutError)
					Utils.noNetworkMessageSplashScreen(act, myReq);
				SplashScreen.setBooleanTrue();

			}
		};
	}

	private Response.ErrorListener createBookmarkErrorListener() {
		return new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {
				Log.e("Error", "Error occured in backend controller", error.getCause());
				if (error instanceof NoConnectionError || error instanceof TimeoutError)
					Utils.noNetworkMessage(act, myReq);

			}
		};
	}
}
