package com.strollup.save;

public class SavedListingMobileResponse {

	private SavedMobileLocations savedLocationResponseString;

	public SavedMobileLocations getSavedLocationResponseString() {
		return savedLocationResponseString;
	}

	public void setSavedLocationResponseString(SavedMobileLocations savedLocationResponseString) {
		this.savedLocationResponseString = savedLocationResponseString;
	}

}
