package com.strollup.save;

import com.strollup.model.location.LocationDto;
import com.strollup.utility.Utils;

public class SavedMobileLocationDto {

	private String savedDate;
	private LocationDto location;

	public String getSavedDate() {
		return Utils.getSavedProperDate(savedDate);
	}

	public void setSavedDate(String savedDate) {
		this.savedDate = savedDate;
	}

	public LocationDto getLocation() {
		return location;
	}

	public void setLocation(LocationDto location) {
		this.location = location;
	}
}
