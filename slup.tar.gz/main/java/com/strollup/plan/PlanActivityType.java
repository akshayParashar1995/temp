package com.strollup.plan;

import java.util.List;

public class PlanActivityType {

	private String name;
	private int id;
	private boolean isSelected;
	private List<PlanActivity> planActivities;

	public PlanActivityType(String name, int id, boolean isSelected, List<PlanActivity> planActivities) {
		this.name = name;
		this.id = id;
		this.isSelected = isSelected;
		this.planActivities = planActivities;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public boolean isSelected() {
		return isSelected;
	}

	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}

	public List<PlanActivity> getPlanActivities() {
		return planActivities;
	}

	public void setPlanActivities(List<PlanActivity> planActivities) {
		this.planActivities = planActivities;
	}

}
