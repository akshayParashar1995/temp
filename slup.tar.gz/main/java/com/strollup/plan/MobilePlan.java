package com.strollup.plan;

import android.content.Context;
import android.widget.Toast;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import com.strollup.filter.Region;
import com.strollup.floating_action_button.PopupInterface;
import com.strollup.model.location.LocationDto;
import com.strollup.request.ActivityAtLocation;
import java.util.ArrayList;
import java.util.List;

public class MobilePlan implements Serializable,PopupInterface{

	private String description;
	private String highlights;
	private String duration;
	private int rating;
	private List<MobilePlanDetail> planDetails;
	private boolean isRecommended;
	private UserInputDto userInput;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getHighlights() {
		return highlights;
	}

	public void setHighlights(String highlights) {
		this.highlights = highlights;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public List<MobilePlanDetail> getPlanDetails() {
		return planDetails;
	}

	public void setPlanDetails(List<MobilePlanDetail> planDetails) {
		this.planDetails = planDetails;
	}

	public boolean isRecommended() {
		return isRecommended;
	}

	public void setRecommended(boolean isRecommended) {
		this.isRecommended = isRecommended;
	}

	public UserInputDto getUserInput() {
		if (userInput == null) {
			userInput = new UserInputDto();
		}
		return userInput;
	}

	public Region getStartLocation() {
		if (userInput == null) {
			return null;
		}
		return userInput.getStartLocation();
	}
	
	public Region getEndLocation() {
		if (userInput == null) {
			return null;
		}
		return userInput.getEndLocation();
	}
	
	public void setUserInput(UserInputDto userInput) {
		this.userInput = userInput;
	}

	public List<ActivityAtLocation> getActivityAtLocation() {
		List<ActivityAtLocation> activityAtLocations = new ArrayList<ActivityAtLocation>();
		if (planDetails == null || planDetails.isEmpty()) {
			return new ArrayList<ActivityAtLocation>();
		}
		for (MobilePlanDetail planDetail : planDetails) {
			int locationNumber = planDetails.indexOf(planDetail);
			int locationDetailId = planDetail.getLocation().getId();
			int activityId = planDetail.getLocation().getActivityId();
			ActivityAtLocation activityAtLocation = new ActivityAtLocation(locationDetailId, activityId, locationNumber);
			activityAtLocations.add(activityAtLocation);
		}
		return activityAtLocations;
	}

	@Override
	public boolean equals(Object obj) {
		MobilePlan mobilePlan = (MobilePlan) obj;
		if(this.planDetails == mobilePlan.getPlanDetails() && this.planDetails == null) {
			return true;
		}
		if (this.planDetails != null && mobilePlan.getPlanDetails() != null && this.planDetails.size() == mobilePlan.getPlanDetails().size()
				&& this.getUserInput().equals(mobilePlan.getUserInput())) {
			for (int i = 0; i < this.planDetails.size(); i++) {
				LocationDto loc1 = this.getPlanDetails().get(i).getLocation();
				LocationDto loc2 = mobilePlan.getPlanDetails().get(i).getLocation();
				if (loc1.getActivityId() != loc2.getActivityId() || loc1.getId() != loc2.getId()) {
					return false;
				}
			}
			return true;
		}
		return false;
	}

    @Override
    public void onPopupDropDownclick(Context context) {
//        Toast.makeText(context, "MobilePlan clicked", Toast.LENGTH_LONG).show();
    }
}
