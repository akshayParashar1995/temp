package com.strollup.plan;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.koushikdutta.ion.Ion;
import com.strollup.filter.LatLong;
import com.strollup.filter.Region;
import com.strollup.model.location.LocationDto;
import com.strollup.place.PlaceDetailActivity;
import com.strollup.plan.DisplayPlanModels.headerType;
import com.strollup.plan.DisplayPlanModels.separatorinfo;
import com.strollup.utility.AppPreferences;
import com.strollup.utility.Constants;
import com.strollup.utility.GoogleMapsUtility;
import com.strollup.utility.Utils;

import org.apache.commons.lang3.text.WordUtils;

import java.util.ArrayList;
import java.util.List;

import in.strollup.android.R;

public class DisplayPlansListAdapter extends BaseAdapter {

    private Context context;
    View greenLine;
    private MobilePlan mobilePlan;
    private List<MobilePlan> mobilePlans;
    private Activity activity;
    private View convertView;
    Intent i;

    public DisplayPlansListAdapter(Context context, Activity activity, List<MobilePlan> mobilePlans, int position) {
        this.context = context;
        this.activity = activity;
        this.mobilePlans = mobilePlans;
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        mobilePlan = mobilePlans.get(position);
        Region startLocation;
        DisplayPlanModels model = new DisplayPlanModels();
        if (AppPreferences.getStartLocation(context) != null) {
            startLocation = AppPreferences.getStartLocation(context);
        } else if (Utils.isGpsEnabled(context)) {
            Region nearMyLocationArea = null;
            nearMyLocationArea = Utils.getNearByRegion(context);
            startLocation = nearMyLocationArea;
        } else {
            startLocation = Utils.getDefaultRegion(context);
        }
        if (mobilePlan.getUserInput() == null) {
            mobilePlan.setUserInput(new UserInputDto());
        }
        Region startRegion = mobilePlan.getUserInput().getStartLocation();
        if (startRegion == null) {
            Region defaultRegion = startLocation;
            startRegion = defaultRegion;
            mobilePlan.getUserInput().setStartLocation(startRegion);
            for (MobilePlan plan : mobilePlans) {
                plan.getUserInput().setStartLocation(startRegion);
            }
        }
        addHeader(model.new headerType("Starting Point", startRegion.getArea()));
        MobilePlanDetail firstPlan = mobilePlan.getPlanDetails().get(0);

        String distance = Utils.getDistanceFromLatAndLong(startRegion.getLatitude(), firstPlan.getLocation()
                .getLatitude(), startRegion.getLongitude(), firstPlan.getLocation().getLongitude());
        LatLong start = new LatLong(startRegion.getLatitude(), startRegion.getLongitude());
        LatLong end = new LatLong(firstPlan.getLocation().getLatitude(), firstPlan.getLocation().getLongitude());
        addSeparator(model.new separatorinfo(distance, Utils.getTimeEstimated(distance), start, end));
        List<MobilePlanDetail> planDetails = mobilePlan.getPlanDetails();
        for (MobilePlanDetail planDetail : planDetails) {
            addCard(planDetail);
            if (planDetails.indexOf(planDetail) != planDetails.size() - 1) {
                start = end;
                end = new LatLong(planDetails.get(planDetails.indexOf(planDetail) + 1).getLocation().getLatitude(),
                        planDetails.get(planDetails.indexOf(planDetail) + 1).getLocation().getLongitude());
                addSeparator(model.new separatorinfo(planDetail.getDistance(), Utils.getTimeEstimated(planDetail
                        .getDistance()), start, end));
            }
        }
        MobilePlanDetail lastMobilePlanDetail = planDetails.get(planDetails.size() - 1);
        start = new LatLong(lastMobilePlanDetail.getLocation().getLatitude(), lastMobilePlanDetail.getLocation()
                .getLongitude());
        Region endRegion = mobilePlan.getUserInput().getEndLocation();
        if (endRegion == null) {
            endRegion = startLocation;
            if (AppPreferences.getEndLocation(context) != null) {
                endRegion = AppPreferences.getEndLocation(context);
            }
            mobilePlan.getUserInput().setEndLocation(endRegion);
            for (MobilePlan plan : mobilePlans) {
                plan.getUserInput().setEndLocation(endRegion);
            }
        }
        MobilePlanDetail lastPlan = mobilePlan.getPlanDetails().get(mobilePlan.getPlanDetails().size() - 1);
        String endDistance = Utils.getDistanceFromLatAndLong(endRegion.getLatitude(), lastPlan.getLocation()
                .getLatitude(), endRegion.getLongitude(), lastPlan.getLocation().getLongitude());
        end = new LatLong(endRegion.getLatitude(), endRegion.getLongitude());
        addSeparator(model.new separatorinfo(endDistance, Utils.getTimeEstimated(endDistance), start, end));
        addHeader(model.new headerType("Ending Point", endRegion.getArea()));
    }

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_CARD = 1;
    private static final int TYPE_SEPARATOR = 2;
    private static final int TYPE_MAX_COUNT = TYPE_SEPARATOR + 1;

    private ArrayList mData = new ArrayList();
    private LayoutInflater mInflater;

    public void addHeader(headerType location) {
        mData.add(location);
        notifyDataSetChanged();

    }

    public void addCard(MobilePlanDetail mobilePlanDetail) {
        mData.add(mobilePlanDetail);
        notifyDataSetChanged();

    }

    public void addSeparator(separatorinfo separatorInfo) {
        mData.add(separatorInfo);
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        if (position == 0 || position == (mData.size() - 1))
            return 0;
        else if (position % 2 == 1)
            return 2;

        else
            return 1;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        int type = getItemViewType(position);
        Typeface font = Typeface.createFromAsset(context.getAssets(), Constants.BASE_FONT);
        Typeface boldFont = Typeface.createFromAsset(context.getAssets(), Constants.BOLD_FONT);
        switch (type) {
            case TYPE_HEADER:
                convertView = mInflater.inflate(R.layout.display_plan_header, null);
                this.convertView = convertView;
                TextView option = (TextView) convertView.findViewById(R.id.option_text);
                TextView location = (TextView) convertView.findViewById(R.id.location_text);
                final headerType header = (headerType) getItem(position);
                option.setTypeface(boldFont, 0);
                location.setTypeface(font, 0);
                option.setText(header.getType());
                location.setText(header.getLocation().replace("%20", " "));
                Button changeButton = (Button) convertView.findViewById(R.id.change_button);
                changeButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent(context, PlacesSearchAutocomplete.class);
                        i.putExtra("type", header.getType());
                        activity.startActivityForResult(i, (int) getItemId(position));

                    }
                });
                break;
            case TYPE_CARD:
                convertView = mInflater.inflate(R.layout.display_plan_card, null);
                final MobilePlanDetail mobilePlanDetail = (MobilePlanDetail) getItem(position);
                final LocationDto locationDto = mobilePlanDetail.getLocation();
                LinearLayout placeLayout = (LinearLayout) convertView.findViewById(R.id.place_layout);
                TextView placeAreaTv = (TextView) convertView.findViewById(R.id.place_area);
                TextView placeCostTv = (TextView) convertView.findViewById(R.id.place_cost);
                TextView placeNameTv = (TextView) convertView.findViewById(R.id.place_name);
                TextView placeSmallDescTv = (TextView) convertView.findViewById(R.id.place_small_desc);
                ImageView placeImage = (ImageView) convertView.findViewById(R.id.activity_image);
                TextView ratingTv = (TextView) convertView.findViewById(R.id.place_rating4);
                placeImage.setScaleType(ScaleType.FIT_XY);
                Ion.with(placeImage)
                        .placeholder(R.drawable.preloader)
                        .error(R.drawable.error_image)
                        .load(locationDto.getImage());

                placeNameTv.setTypeface(font, 0);
                placeAreaTv.setTypeface(font, 0);
                placeCostTv.setTypeface(font, 0);
                ratingTv.setTypeface(font, 0);
                placeSmallDescTv.setTypeface(font, 0);

                placeCostTv.setText(locationDto.getCostText());
                placeAreaTv.setText(locationDto.getRegion());
                ratingTv.setText(locationDto.getRating());
                if (locationDto.getName().contains("@") || mobilePlanDetail.getActivityName() == null) {
                    placeNameTv.setText(Html.fromHtml("<font color=#FF9933>" + locationDto.getName() + "</font>"));
                } else {
                    String activityName = mobilePlanDetail.getActivityName();
                    placeNameTv.setText(Html.fromHtml(WordUtils.capitalize(activityName.toLowerCase()) + "<font color=#FF9933> @ " + locationDto.getName() + "</font>"));
                }
                if (locationDto.getSmallDescription() != null) {
                    placeSmallDescTv.setText(Html.fromHtml(locationDto.getSmallDescription()));
                } else {
                    placeSmallDescTv.setText("");
                }
                convertView.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent(context, PlaceDetailActivity.class);
                        i.putExtra("activity_id", locationDto.getActivityId());
                        i.putExtra("location_detail_id", locationDto.getId());
                        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(i);
                    }
                });
                break;
            case TYPE_SEPARATOR:
                convertView = mInflater.inflate(R.layout.display_plan_separator, null);
                LinearLayout linearLayout1 = (LinearLayout) convertView.findViewById(R.id.plan_separator_shape);
                final separatorinfo separatorInfo = (separatorinfo) getItem(position);
                TextView distanceTv = (TextView) convertView.findViewById(R.id.distance_text);
                TextView timeTv = (TextView) convertView.findViewById(R.id.time_text);
                distanceTv.setTypeface(font, 0);
                timeTv.setTypeface(font, 0);
                distanceTv.setText(separatorInfo.getDistance());
                timeTv.setText(separatorInfo.getTime());
                linearLayout1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        GoogleMapsUtility.showDirections(separatorInfo.getStartRegion(), separatorInfo.getEndRegion(),
                                context);
                    }
                });
                break;

        }

        return convertView;
    }

    @Override
    public int getViewTypeCount() {
        return 3;
    }

    public MobilePlan onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            final Region region = (Region) data.getSerializableExtra("region");
            if (requestCode == 0) {
                headerType header = (headerType) getItem(0);
                header.setLocation(region.getArea());
                mobilePlan.getUserInput().setStartLocation(region);
                for (MobilePlan plan : mobilePlans) {
                    plan.getUserInput().setStartLocation(region);
                }
                String distance = Utils.getDistanceFromLatAndLong(region.getLatitude(), mobilePlan.getPlanDetails()
                        .get(0).getLocation().getLatitude(), region.getLongitude(), mobilePlan.getPlanDetails().get(0)
                        .getLocation().getLongitude());
                separatorinfo separator = (separatorinfo) getItem(1);
                separator.setDistance(distance);
                separator.setTime(Utils.getTimeEstimated(distance));
                separator.setStartRegion(new LatLong(region.getLatitude(), region.getLongitude()));
                separator.setEndRegion(new LatLong(mobilePlan.getPlanDetails().get(0).getLocation().getLatitude(),
                        mobilePlan.getPlanDetails().get(0).getLocation().getLongitude
                                ()));
            } else if (requestCode == (mData.size() - 1)) {
                headerType header = (headerType) getItem(mData.size() - 1);
                header.setLocation(region.getArea());
                mobilePlan.getUserInput().setEndLocation(region);
                for (MobilePlan plan : mobilePlans) {
                    plan.getUserInput().setEndLocation(region);
                }
                String distance = Utils.getDistanceFromLatAndLong(region.getLatitude(), mobilePlan.getPlanDetails()
                                .get(mobilePlan.getPlanDetails().size() - 1).getLocation().getLatitude(),
                        region.getLongitude(), mobilePlan.getPlanDetails().get(mobilePlan.getPlanDetails().size() - 1)
                                .getLocation().getLongitude());
                separatorinfo separator = (separatorinfo) getItem(mData.size() - 2);
                separator.setDistance(distance);
                separator.setTime(Utils.getTimeEstimated(distance));
                separator.setStartRegion(new LatLong(region.getLatitude(), region.getLongitude()));
                separator.setEndRegion(new LatLong(mobilePlan.getPlanDetails()
                        .get(mobilePlan.getPlanDetails().size() - 1).getLocation().getLatitude(), mobilePlan
                        .getPlanDetails().get(mobilePlan.getPlanDetails().size() - 1).getLocation().getLongitude()));
            }
        }
        return mobilePlan;
    }
}

