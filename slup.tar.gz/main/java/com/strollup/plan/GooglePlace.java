package com.strollup.plan;

public class GooglePlace {
	public GooglePlace(String placeDescription, String placeId) {
		super();
		this.placeDescription = placeDescription;
		this.placeId = placeId;
	}

	private String placeDescription;
	private String placeId;

	public String getPlaceDescription() {
		return placeDescription;
	}

	public void setPlaceDescription(String placeDescription) {
		this.placeDescription = placeDescription;
	}

	public String getPlaceId() {
		return placeId;
	}

	public void setPlaceId(String placeId) {
		this.placeId = placeId;
	}

}
