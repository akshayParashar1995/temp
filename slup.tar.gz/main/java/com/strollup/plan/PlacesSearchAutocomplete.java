package com.strollup.plan;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.strollup.filter.Region;
import com.strollup.main.AppController;
import com.strollup.utility.AppPreferences;
import com.strollup.utility.Constants;
import com.strollup.utility.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import in.strollup.android.R;

public class PlacesSearchAutocomplete extends AppCompatActivity {

	private static final String LOG_TAG = PlacesSearchAutocomplete.class.getSimpleName();
	private Region selectedRegion;

	private static final String PLACES_API_BASE = "https://maps.googleapis.com/maps/api/place";
	private static final String TYPE_AUTOCOMPLETE = "/autocomplete";
	private static final String OUT_JSON = "/json";
	private AutoCompleteTextView autoCompView;
	private static final String API_KEY = "AIzaSyB6TAhHFw8-J6POWa10euMnydQpm1qSWDU";
	JsonObjectRequest myReq;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        Bundle b = intent.getExtras();
        final String type = b.getString("type");
		setContentView(R.layout.places_search_layout);
		ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle(type);
		autoCompView = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView);

		autoCompView.setAdapter(new GooglePlacesAutocompleteAdapter(this, R.layout.places_list_item));
		autoCompView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				GooglePlace place = onDropDownItemClick(parent, view, position, id);
				autoCompView.setText(place.getPlaceDescription());
			}
		});
	}

	public GooglePlace onDropDownItemClick(AdapterView<?> adapterView, View view, int position, long id) {
		final GooglePlace selectedPlace = (GooglePlace) adapterView.getItemAtPosition(position);
		autoCompView.setText(selectedPlace.getPlaceDescription());
		if (selectedPlace.getPlaceDescription().equals(Constants.CURRENT_LOCATION)) {
			if (Utils.isGpsEnabled(getApplicationContext())) {
				selectedRegion = Utils.getNearByRegion(getApplicationContext());
				selectedPlace.setPlaceDescription(selectedRegion.getArea());
				Intent returnIntent = new Intent();
				returnIntent.putExtra("region", selectedRegion);
				setResult(RESULT_OK, returnIntent);
				finish();
			} else {
				Utils.buildAlertMessageNoGps(PlacesSearchAutocomplete.this);

			}
		} else {

			StringBuilder sb = new StringBuilder(PLACES_API_BASE + "/details" + OUT_JSON);
			sb.append("?placeid=" + selectedPlace.getPlaceId());
			sb.append("&key=" + API_KEY);

			myReq = new JsonObjectRequest(Request.Method.GET, sb.toString(),null,
					createMyReqSuccessListener(selectedPlace), createMyReqErrorListener());
			AppController.getInstance().addToRequestQueue(myReq);
		}
		return selectedPlace;
	}

	private Response.ErrorListener createMyReqErrorListener() {
		return new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {
				Log.e("Error", "Error occured", error.getCause());

			}
		};
	}

	private Response.Listener<JSONObject> createMyReqSuccessListener(final GooglePlace selectedPlace) {
		return new Response.Listener<JSONObject>() {
			@Override
			public void onResponse(JSONObject jsonObj) {
				try {
					JSONObject resultObj = jsonObj.getJSONObject("result");
					JSONObject geometryObj = resultObj.getJSONObject("geometry");
					JSONObject locationObj = geometryObj.getJSONObject("location");
					String latitude = locationObj.getString("lat");
					String longitude = locationObj.getString("lng");
					Region selectedRegion = new Region(selectedPlace.getPlaceDescription(), latitude, longitude);
					Intent returnIntent = new Intent();
					returnIntent.putExtra("region", selectedRegion);
					setResult(RESULT_OK, returnIntent);
					finish();

				} catch (JSONException e) {
					e.printStackTrace();
				}
			};
		};
	}

	@Override
	public void onResume() {
		super.onResume();
		if (Utils.isGpsEnabled(getApplicationContext()) && autoCompView.getText().equals(Constants.CURRENT_LOCATION)) {
			selectedRegion = Utils.getNearByRegion(getApplicationContext());
			autoCompView.setText(selectedRegion.getArea());

			Intent returnIntent = new Intent();
			returnIntent.putExtra("region", selectedRegion);
			setResult(RESULT_OK, returnIntent);
			finish();
		}
	}

	private ArrayList<GooglePlace> autocomplete(String input) {
		ArrayList<GooglePlace> resultList = null;

		HttpURLConnection conn = null;
		StringBuilder jsonResults = new StringBuilder();
		try {
			int cityId = AppPreferences.getCityId(getApplicationContext());
			StringBuilder sb = new StringBuilder(PLACES_API_BASE + TYPE_AUTOCOMPLETE + OUT_JSON);
			sb.append("?key=" + API_KEY);
			sb.append("&location=");
			sb.append(Constants.DEFAULT_AREA_LATITUDE_LONGITUDE.get(cityId));
			sb.append("&input=" + URLEncoder.encode(input, "utf8"));

			URL url = new URL(sb.toString());
			conn = (HttpURLConnection) url.openConnection();
			InputStreamReader in = new InputStreamReader(conn.getInputStream());

			int read;
			char[] buff = new char[1024];
			while ((read = in.read(buff)) != -1) {
				jsonResults.append(buff, 0, read);
			}
		} catch (MalformedURLException e) {
			Log.e(LOG_TAG, "Error processing Places API URL", e);
			return resultList;
		} catch (IOException e) {
			Log.e(LOG_TAG, "Error connecting to Places API", e);
			return resultList;
		} finally {
			if (conn != null) {
				conn.disconnect();
			}
		}

		try {

			JSONObject jsonObj = new JSONObject(jsonResults.toString());
			JSONArray predsJsonArray = jsonObj.getJSONArray("predictions");

			resultList = new ArrayList<GooglePlace>(predsJsonArray.length() + 1);
			resultList.add(new GooglePlace(Constants.CURRENT_LOCATION, "0"));
			for (int i = 1; i <= predsJsonArray.length(); i++) {
				resultList.add(new GooglePlace(predsJsonArray.getJSONObject(i - 1).getString("description"),
						predsJsonArray.getJSONObject(i - 1).getString("place_id")));
			}
		} catch (JSONException e) {
			Log.e(LOG_TAG, "Cannot process JSON results", e);
		}

		return resultList;
	}

	class GooglePlacesAutocompleteAdapter extends ArrayAdapter<GooglePlace> implements Filterable {
		private ArrayList<GooglePlace> resultList;
		private Context context;

		public GooglePlacesAutocompleteAdapter(Context context, int textViewResourceId) {
			super(context, textViewResourceId);
			this.context = context;
		}

		@Override
		public int getCount() {
			return resultList.size();
		}

		@Override
		public GooglePlace getItem(int index) {
			return resultList.get(index);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = mInflater.inflate(R.layout.custom_drop_down, null);
			TextView tv = (TextView) convertView.findViewById(R.id.textView1);
			GooglePlace place = getItem(position);
			tv.setText(place.getPlaceDescription());
			return convertView;
		}

		@Override
		public android.widget.Filter getFilter() {
			Filter filter = new Filter() {
				@Override
				protected FilterResults performFiltering(CharSequence constraint) {
					FilterResults filterResults = new FilterResults();
					if (constraint != null) {
						resultList = autocomplete(constraint.toString());
						filterResults.values = resultList;
						filterResults.count = resultList.size();
					}
					return filterResults;
				}

				@Override
				protected void publishResults(CharSequence constraint, FilterResults results) {
					if (results != null && results.count > 0) {
						notifyDataSetChanged();
					} else {
						notifyDataSetInvalidated();
					}
				}

			};
			return filter;
		}
	}
}
