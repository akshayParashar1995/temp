package com.strollup.plan;

import com.strollup.filter.Region;

import java.util.List;

public class SuggestionsStringDataResponse {
	private  List<Region> suggestionsString;

	public List<Region> getSuggestionsString() {
		return suggestionsString;
	}

	public void setSuggestionsString(List<Region> suggestionsString) {
		this.suggestionsString = suggestionsString;
	}

	
	
}
