package com.strollup.plan;

import com.strollup.filter.LatLong;

public class DisplayPlanModels {

	public class headerType {
		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String getLocation() {
			return location;
		}

		public void setLocation(String location) {
			this.location = location;
		}

		public headerType(String type, String location) {
			super();
			this.type = type;
			this.location = location;
		}

		String type;
		String location;

	}

	public class separatorinfo {

		String distance;
		String time;
		LatLong startRegion;
		LatLong endRegion;

		public separatorinfo(String distance, String time, LatLong start, LatLong end) {
			super();
			this.distance = distance;
			this.time = time;
			this.startRegion = start;
			this.endRegion = end;

		}

		public String getDistance() {
			return distance;
		}

		public void setDistance(String distance) {
			this.distance = distance;
		}

		public String getTime() {
			return time;
		}

		public void setTime(String time) {
			this.time = time;
		}

		public LatLong getStartRegion() {
			return startRegion;
		}

		public void setStartRegion(LatLong startRegion) {
			this.startRegion = startRegion;
		}

		public LatLong getEndRegion() {
			return endRegion;
		}

		public void setEndRegion(LatLong endRegion) {
			this.endRegion = endRegion;
		}

	}

}
