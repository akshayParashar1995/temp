package com.strollup.plan;

import java.util.List;

public class MobilePlanResponse {

	private List<MobilePlan> mobilePlans;

	public MobilePlanResponse(List<MobilePlan> mobilePlans) {
		super();
		this.mobilePlans = mobilePlans;
	}

	public List<MobilePlan> getMobilePlans() {
		return mobilePlans;
	}

	public void setMobilePlans(List<MobilePlan> mobilePlans) {
		this.mobilePlans = mobilePlans;
	}
}
