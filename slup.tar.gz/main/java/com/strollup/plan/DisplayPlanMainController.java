package com.strollup.plan;

import android.content.Context;

import com.google.gson.Gson;
import com.strollup.filter.AllFilterString;
import com.strollup.request.ActivityAtLocation;
import com.strollup.request.ActivityLocation;
import com.strollup.request.BaseRequest;
import com.strollup.request.ShowPlansRequest;
import com.strollup.request.TrendingDataRequest;
import com.strollup.utility.Constants;

public class DisplayPlanMainController {

	public static String getPlanYourDayUrl(AllFilterString allFilterString, Context context) {
		BaseRequest baseRequest = new BaseRequest(context);
		String planUrl = Constants.BASE_SERVER_URL + "planYourDay?planMyDayRequestString="
				+ new Gson().toJson(baseRequest) + "&allFilterString=" + new Gson().toJson(allFilterString);
		planUrl = planUrl.replaceAll(" ", "%20");
		return planUrl;
	}

    public static String getPlanWithLocationUrl(String url, AllFilterString allFilterString, Context context) {
        String planUrl = "";
        if(url.contains("&allFilterString")) {
            int index = url.indexOf("&allFilterString");
            url = url.substring(0, index);
        }
        planUrl = url + "&allFilterString=" + new Gson().toJson(allFilterString);
        planUrl = planUrl.replaceAll(" ", "%20");
        return planUrl;
    }

    public static String getPlansWithThisLocation(ActivityLocation activityLocation, boolean isFilterApplied,
			int locationNumber,AllFilterString allFilterString, Context context) {
		ActivityAtLocation activityAtLocation = new ActivityAtLocation(activityLocation.getLocationDetailId(),
				activityLocation.getActivityId(), locationNumber);
		ShowPlansRequest planRequest = new ShowPlansRequest(context, activityAtLocation, isFilterApplied);
		String planUrl = Constants.BASE_SERVER_URL
				+ "getPlansWithThisLocationAndFilter?showHangoutWithLocationRequestString="
				+ new Gson().toJson(planRequest) + "&allFilterString=" + new Gson().toJson(allFilterString);
		planUrl = planUrl.replaceAll(" ", "%20");
		return planUrl;
	}

    public static String getTrendingPlan(Context context,int tableNameId,int tableRowId){
        TrendingDataRequest planRequest = new TrendingDataRequest(context,tableNameId,tableRowId);
        String planUrl = Constants.BASE_SERVER_URL
                + "getTrendingData?trendingDataRequestString="
                + new Gson().toJson(planRequest);
        planUrl = planUrl.replaceAll(" ", "%20");
        return planUrl;
    }
}
