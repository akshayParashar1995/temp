package com.strollup.plan;

/**
 * Created by Akshay on 10-07-2015.
 */
public class TrendingPlanDataResponse {
    private MobilePlanResponse trendingDataResponseString;

    public MobilePlanResponse getTrendingDataResponseString() {
        return trendingDataResponseString;
    }

    public void setTrendingDataResponseString(MobilePlanResponse trendingDataResponseString) {
        this.trendingDataResponseString = trendingDataResponseString;
    }
}
