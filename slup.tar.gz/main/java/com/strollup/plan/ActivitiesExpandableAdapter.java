package com.strollup.plan;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.TextView;

import com.strollup.activity.ActivityDataResponse;
import com.strollup.activity.ActivityDto;
import com.strollup.activity.ActivityTypeDto;
import com.strollup.utility.Constants;
import com.strollup.utility.Globals;

import java.util.ArrayList;
import java.util.List;

import in.strollup.android.R;

public class ActivitiesExpandableAdapter extends BaseExpandableListAdapter {

	private Context _context;
	private List<PlanActivityType> planActivityTypes;
	private static final int[] EMPTY_STATE_SET = {};
	private static final int[] GROUP_EXPANDED_STATE_SET = { android.R.attr.state_expanded };
	private static final int[][] GROUP_STATE_SETS = { EMPTY_STATE_SET, // 0
			GROUP_EXPANDED_STATE_SET // 1
	};

	public ActivitiesExpandableAdapter(Context context, ActivityDataResponse activityResult) {
		this._context = context;
		planActivityTypes = new ArrayList<PlanActivityType>();
		List<ActivityTypeDto> activityTypeDtos = activityResult.getActivityTypeStrings();

		for (ActivityTypeDto activityTypeDto : activityTypeDtos) {
			List<ActivityDto> activities = activityTypeDto.getActivities();
			List<PlanActivity> planActivities = new ArrayList<PlanActivity>();

			if (activities.size() <= 1 || Constants.PLAN_ACTIVITY_TYPES.contains(activityTypeDto.getId())) {
				planActivityTypes.add(new PlanActivityType(activityTypeDto.getName(), activityTypeDto.getId(), false,
						planActivities));
			} else {
				for (ActivityDto activityDto : activities) {
					PlanActivity planActivity = new PlanActivity(activityDto.getName(), activityDto.getId(), false);
					if (!planActivity.getName().toLowerCase().equals(activityTypeDto.getName().toLowerCase())) {
						planActivities.add(planActivity);
					}
				}
				planActivities.add(0, new PlanActivity(Constants.SELECT_ALL, activityTypeDto.getId(), false));
				PlanActivityType planActivityType = new PlanActivityType(activityTypeDto.getName(),
						activityTypeDto.getId(), false, planActivities);
				planActivityTypes.add(planActivityType);
			}
		}
		planActivityTypes.add(0, new PlanActivityType(Constants.ANYTHING_ACTIVITY, 0, false,
				new ArrayList<PlanActivity>()));

		Globals.planActivityTypes = planActivityTypes;
	}

	@Override
	public int getGroupCount() {
		return this.planActivityTypes.size();
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		return this.planActivityTypes.get(groupPosition).getPlanActivities().size();
	}

	@Override
	public Object getGroup(int groupPosition) {
		return this.planActivityTypes.get(groupPosition);
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		return this.planActivityTypes.get(groupPosition).getPlanActivities().get(childPosition);
	}

	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	@Override
	public boolean hasStableIds() {
		return false;
	}

	@Override
	public View getGroupView(final int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
		convertView = null;
		final PlanActivityType parentGroup = (PlanActivityType) getGroup(groupPosition);
		String headerTitle = parentGroup.getName();
		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater) this._context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(R.layout.expandable_group_row_layout, null);
		}

		TextView lblListHeader = (TextView) convertView.findViewById(R.id.groupname);
		lblListHeader.setText(headerTitle);
		View ind = convertView.findViewById(R.id.group_indicator);

		if (getChildrenCount(groupPosition) == 0) {

			ImageView indicator = (ImageView) ind;
			indicator.setVisibility(View.INVISIBLE);
			CheckBox groupCheckBox = (CheckBox) convertView.findViewById(R.id.group_checkbox);
			groupCheckBox.setVisibility(View.VISIBLE);
			groupCheckBox.setChecked(parentGroup.isSelected());
			groupCheckBox.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					parentGroup.setSelected(isChecked);
					notifyDataSetChanged();
				}
			});

		} else {
			CheckBox groupCheckBox = (CheckBox) convertView.findViewById(R.id.group_checkbox);
			groupCheckBox.setVisibility(View.INVISIBLE);

			if (ind != null) {
				ImageView indicator = (ImageView) ind;
				indicator.setVisibility(View.VISIBLE);
				int stateSetIndex = (isExpanded ? 1 : 0);
				Drawable drawable = indicator.getDrawable();
				drawable.setState(GROUP_STATE_SETS[stateSetIndex]);
			}
		}
		MyListener myHandleClickListener = new MyListener(groupPosition, isExpanded, parent);
		convertView.setOnClickListener(myHandleClickListener);
		return convertView;
	}

	@Override
	public View getChildView(final int groupPosition, final int childPosition, boolean isLastChild, View convertView,
			ViewGroup parent) {
		convertView = null;
		final PlanActivity child = (PlanActivity) getChild(groupPosition, childPosition);
		String childText = child.getName();

		if (convertView == null) {
			LayoutInflater infalInflater = (LayoutInflater) this._context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = infalInflater.inflate(R.layout.expandable_child_row_layout, null);
		}

		TextView txtListChild = (TextView) convertView.findViewById(R.id.childname);
		txtListChild.setText(childText);
		CheckBox checkBox = (CheckBox) convertView.findViewById(R.id.check1);
		checkBox.setChecked(child.isSelected());
		checkBox.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				child.setSelected(isChecked);
				if (child.getId() == ((PlanActivityType) getGroup(groupPosition)).getId()) {
					markAllChildItems(groupPosition, (PlanActivityType) getGroup(groupPosition), isChecked);
				}
				checkForSelectAllOption(groupPosition, childPosition);
				notifyDataSetChanged();
			}
		});
		return convertView;
	}

	public void checkForSelectAllOption(int groupPosition, int childPosition) {
		PlanActivityType parentGroup = (PlanActivityType) getGroup(groupPosition);
		List<PlanActivity> list = parentGroup.getPlanActivities();
		PlanActivity selectAllOption = list.get(0);
		if (selectAllOption.isSelected()) {
			for (PlanActivity listOption : list) {
				if (!listOption.isSelected()) {
					selectAllOption.setSelected(false);
					break;
				}
			}
		}
	}

	@Override
	public void notifyDataSetChanged() {
		super.notifyDataSetChanged();
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}

	public void markAllChildItems(int groupPosition, PlanActivityType groupParent, boolean isSelected) {
		List<PlanActivity> childrens = groupParent.getPlanActivities();
		for (PlanActivity childActivity : childrens) {
			childActivity.setSelected(isSelected);
		}
	}

	public class MyListener implements OnClickListener {

		private int groupPosition;
		boolean isExpanded;
		ExpandableListView parent;

		public MyListener(int groupPosition, boolean isExpanded, ViewGroup parent) {
			this.groupPosition = groupPosition;
			this.isExpanded = isExpanded;
			this.parent = (ExpandableListView) parent;
		}

		@Override
		public void onClick(View v) {
			PlanActivityType parentGroup = (PlanActivityType) getGroup(groupPosition);
			if (parentGroup.getPlanActivities().size() == 0) {
				parentGroup.setSelected(!parentGroup.isSelected());
			} else {
				if (parent.isGroupExpanded(groupPosition)) {
					parent.collapseGroup(groupPosition);
				} else {
					parent.expandGroup(groupPosition);
				}
			}
			notifyDataSetChanged();
		}
	}
}
