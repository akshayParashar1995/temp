package com.strollup.plan;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ExpandableListView.OnGroupCollapseListener;
import android.widget.ExpandableListView.OnGroupExpandListener;

import com.strollup.filter.AllFilterString;
import com.strollup.filter.PydOne;
import com.strollup.filter.PydTwo;
import com.strollup.utility.Globals;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import in.strollup.android.R;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class PlanMyDayActivities extends AppCompatActivity {

	private ActivitiesExpandableAdapter listAdapter;
	private ExpandableListView expListView;
	private int lastExpandedGroupId = -1;
	private Button planMyDayButton;
	private PydOne pydOne;
    private boolean isCalledByOutingDiscuss=false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.plan_my_day_activities);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		Intent i = getIntent();
		pydOne = (PydOne) i.getSerializableExtra("PydOne");
        if(i.getExtras().getBoolean("isCalledByOutingDiscuss")){
            isCalledByOutingDiscuss=true;
        }
		expListView = (ExpandableListView) findViewById(R.id.activities_expandable_list_view);
		listAdapter = new ActivitiesExpandableAdapter(this, Globals.activityResult);
		planMyDayButton = (Button) findViewById(R.id.plan_my_day);
		expListView.setAdapter(listAdapter);

		expListView.setOnGroupExpandListener(new OnGroupExpandListener() {

			@Override
			public void onGroupExpand(int groupPosition) {
				if (lastExpandedGroupId != -1) {
					expListView.collapseGroup(lastExpandedGroupId);
					expListView.setSelection(groupPosition);
				}
				lastExpandedGroupId = groupPosition;
			}
		});
		expListView.setOnGroupCollapseListener(new OnGroupCollapseListener() {
			@Override
			public void onGroupCollapse(int groupPosition) {
				lastExpandedGroupId = -1;
			}
		});

		expListView.setOnChildClickListener(new OnChildClickListener() {
			@Override
			public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
				PlanActivity child = (PlanActivity) listAdapter.getChild(groupPosition, childPosition);
				PlanActivityType groupParent = (PlanActivityType) listAdapter.getGroup(groupPosition);
				if (child.getId() == groupParent.getId()) {
					listAdapter.markAllChildItems(groupPosition, groupParent, child.isSelected());
				}
				child.setSelected(!child.isSelected());
				listAdapter.checkForSelectAllOption(groupPosition, childPosition);
				listAdapter.notifyDataSetChanged();
				return true;
			}
		});

		planMyDayButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				PydTwo pydTwo = new PydTwo();
				List<Integer> activityIds = new ArrayList<Integer>();
				List<Integer> activityTypeIds = new ArrayList<Integer>();

				if (!Globals.planActivityTypes.get(0).isSelected()) {
					for (PlanActivityType planActivityType : Globals.planActivityTypes) {
						if (planActivityType.getPlanActivities().size() == 0 && planActivityType.isSelected()) {
							activityTypeIds.add(planActivityType.getId());
						} else {
							for (PlanActivity planActivity : planActivityType.getPlanActivities()) {
								if (planActivity.getId() == planActivityType.getId() && planActivity.isSelected()) {
									activityTypeIds.add(planActivityType.getId());
									break;
								}
								if (planActivity.isSelected()) {
									activityIds.add(planActivity.getId());
								}
							}
						}
					}
				}
				if (activityIds.size() != 0 || activityTypeIds.size() != 0) {
					pydTwo.setActivityIds(activityIds);
					pydTwo.setActivityTypeIds(activityTypeIds);

				}
				AllFilterString allFilterString = new AllFilterString(getApplicationContext());
				allFilterString.setPydOne(pydOne);
				allFilterString.setPydTwo(pydTwo);
				String url=DisplayPlanMainController.getPlanYourDayUrl(allFilterString, getApplicationContext());
				Intent intent=new Intent(getApplicationContext(),DisplayPlanMain.class);
			    intent.putExtra("url",url);
                if(isCalledByOutingDiscuss){
                    intent.putExtra("isCalledByOutingDiscuss",true);
                }
			    intent.putExtra("allFilterString",(Serializable)allFilterString);
				startActivity(intent);
			}
		});

	}

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }
}
