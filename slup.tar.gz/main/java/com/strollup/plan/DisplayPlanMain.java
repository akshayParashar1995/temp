package com.strollup.plan;

import in.strollup.android.R;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.graphics.drawable.LayerDrawable;
import android.os.Bundle;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.strollup.filter.AllFilterString;
import com.strollup.filter.FilterActivity;
import com.strollup.filter.Region;
import com.strollup.floating_action_button.OutingDiscuss;
import com.strollup.floating_action_button.PopupInterface;
import com.strollup.main.AppController;
import com.strollup.utility.AppPreferences;
import com.strollup.utility.Constants;
import com.strollup.utility.FontsOverride;
import com.strollup.utility.Globals;
import com.strollup.utility.GsonRequest;
import com.strollup.utility.Utils;

import java.io.Serializable;
import java.util.List;

import in.strollup.android.R;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class DisplayPlanMain extends AppCompatActivity {
    private ListView plansList;
    private String url;
    private List<MobilePlan> mobilePlans;
    private static int position = 0;
    private DisplayPlansListAdapter adapter;
    private Button next;
    private Button previous;
    private ProgressBar progressBar;
    private int mNotifCount=0;
    private LinearLayout layout;
    private Button bookmark;
    private AllFilterString allFilterString;
    private LinearLayout buttonsLayout;
    private TextView notifCount;
    private Button shortListButton;
    GsonRequest<PlanDataResponse> planDataResponseRequest;
    float scale = 0.0f;
    private boolean isCalledByOutingDiscuss=false;
    // private RelativeLayout tut_layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_plans_layout);
        plansList = (ListView) findViewById(R.id.plan_list);
        FontsOverride.setDefaultFont(this, "MONOSPACE", "fonts/Montserrat-Light.otf");
        scale = getResources().getDisplayMetrics().density;
        // tut_layout = (RelativeLayout) findViewById(R.id.tut_layout_plan);
        // tut_layout.setOnClickListener(new View.OnClickListener() {
        //
        // @Override
        // public void onClick(View v) {
        // // TODO Auto-generated method stub
        // tut_layout.setVisibility(View.INVISIBLE);
        // AppPreferences.setIsThisPageDisplayedFirst(getApplicationContext(),
        // Constants.PLAN_DISPLAY_ACTIVITY_NO);
        // }
        // });
        Intent i = getIntent();
        url = i.getExtras().getString("url");
        if(i.getExtras().getBoolean("isCalledByOutingDiscuss")){
            isCalledByOutingDiscuss=true;
        }
        allFilterString = (AllFilterString) i.getSerializableExtra("allFilterString");
        if (allFilterString == null)
            allFilterString = new AllFilterString(getApplicationContext());
        next = (Button) findViewById(R.id.next_plan);
        bookmark = (Button) findViewById(R.id.bookmark_plan);
        previous = (Button) findViewById(R.id.previous_plan);
        buttonsLayout= (LinearLayout) findViewById(R.id.buttons_layout);
        layout = (LinearLayout) findViewById(R.id.plan_linear_layout);
        progressBar = (ProgressBar) findViewById(R.id.progressBar_plan_display);
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowCustomEnabled(true);
        imageView = new ImageView(actionBar.getThemedContext());
        imageView.setScaleType(ImageView.ScaleType.CENTER);
        imageView.setImageResource(R.drawable.ic_filter);
        android.support.v7.app.ActionBar.LayoutParams layoutParams = new android.support.v7.app.ActionBar.LayoutParams(ActionBar.LayoutParams.WRAP_CONTENT,
                ActionBar.LayoutParams.WRAP_CONTENT, Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        layoutParams.rightMargin = 25;
        imageView.setLayoutParams(layoutParams);
        imageView.setVisibility(View.GONE);
        actionBar.setCustomView(imageView);

        loadMobilePlans(url);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (position == mobilePlans.size() - 1) {
                    return;
                }
                if (AppPreferences.getIsSharedSucessfullyOnFb(getApplicationContext())) {
                    moveTonextPage();
                } else {
                    if (position + 1 > Constants.NO_OF_TRIES_BEFORE_SHARE_POPUP) {
                        AppPreferences.addToListOfDisplayPlanHits(getApplicationContext(), url);

                        if (AppPreferences.getNoOfDisplayPlanHits(getApplicationContext()) >= Constants.NO_OF_URL_HITS_SHARE_POPUP) {
                            Utils.buildAlertMessageShareFacebook(DisplayPlanMain.this);
                        } else {
                            moveTonextPage();
                        }
                    } else {
                        moveTonextPage();
                    }
                }
            }
        });
        previous.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (position == 0) {
                    return;
                }
                position--;
                adapter = new DisplayPlansListAdapter(getApplicationContext(), DisplayPlanMain.this, mobilePlans,
                        position);
                if(isCalledByOutingDiscuss)
                    setShortListStatus(position);
                else
                    setBookMark(position);
                plansList.setAdapter(adapter);
                getSupportActionBar()
                        .setTitle(Constants.SHOWING_PLANS + "(" + (position + 1) + "/" + mobilePlans.size() + ")");
            }
        });

        bookmark.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                MobilePlan mobilePlan = mobilePlans.get(position);
                if (!SavePlanController.isAlreadySavedLocation(mobilePlan)) {
                    SavePlanController.saveCurrentPlan(getApplicationContext(), mobilePlan, position, allFilterString);
                    bookmark.setText("Bookmarked");
                } else {
                    int index = SavePlanController.getIndexOfMobilePlan(mobilePlan);
                    SavePlanController.UnsaveCurrentPlan(getApplicationContext(), Globals.savedPlans.getPlanInfoIds()
                            .get(index), mobilePlan);
                    bookmark.setText("Bookmark");
                }
            }

        });
        if(isCalledByOutingDiscuss){

            bookmark.setVisibility(View.GONE);
            float scale = getResources().getDisplayMetrics().density;
            LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(0, (int)(50*scale));
            params.weight=1;
            params.setMargins(1,0,1,0);
            shortListButton=new Button(this);
            shortListButton.setLayoutParams(params);
            shortListButton.setBackground(getResources().getDrawable(R.drawable.button));
            shortListButton.setText("Shortlist");
            shortListButton.setTextColor(getResources().getColor(R.color.white));
            buttonsLayout.addView(shortListButton,1);
            shortListButton.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.i("outingDiscuss","shortListed");
                    if(Globals.outingDto.getPlans()==null){
                        Globals.outingDto.setPlans(new ArrayList<PopupInterface>());
                    }
                    if(!Globals.outingDto.getPlans().contains(mobilePlans.get(position))) {
                        Globals.outingDto.getPlans().add(mobilePlans.get(position ));
                        shortListButton.setText("ShortListed");
                    }
                    else{
                        Globals.outingDto.getPlans().remove(Globals.outingDto.getPlans().indexOf(mobilePlans.get(position)));
                        shortListButton.setText("ShortList");
                    }
                    setNotifCount(Globals.outingDto.getPlans().size());
                    Log.i("outingDiscuss","size of outing plans "+Globals.outingDto.getPlans().size());
                }
            });
        }

    }

    private void moveTonextPage() {
        position++;
        adapter = new DisplayPlansListAdapter(getApplicationContext(), DisplayPlanMain.this, mobilePlans, position);
        plansList.setAdapter(adapter);
        if(isCalledByOutingDiscuss)
            setShortListStatus(position);
        else
            setBookMark(position);
        getSupportActionBar().setTitle(Constants.SHOWING_PLANS + "(" + (position + 1) + "/" + mobilePlans.size() + ")");
    }

    private void setShortListStatus(int position){
        if(Globals.outingDto.getPlans().contains(mobilePlans.get(position))){
            shortListButton.setText("ShortListed");
            Log.i("shortList","present");
        }
        else{
            shortListButton.setText("ShortList");
            Log.i("shortList","not present");
        }
    }

    private void setBookMark(int position) {
        if (SavePlanController.isAlreadySavedLocation(mobilePlans.get(position))) {
            bookmark.setText("Bookmarked");
        } else {
            bookmark.setText("Bookmark");
        }
    }

    private void loadMobilePlans(String url) {
        layout.setVisibility(View.GONE);
        progressBar.setVisibility(View.VISIBLE);
        if ("trending".equals(getIntent().getExtras().getString("called_by"))) {
            GsonRequest<TrendingPlanDataResponse> trendingPlanDataResposeGsonRequest = new GsonRequest<TrendingPlanDataResponse>(Request.Method.GET, url, TrendingPlanDataResponse.class,
                    createMyTrendingReqSuccessListener(), createMyReqErrorListener());
            AppController.getInstance().addToRequestQueue(trendingPlanDataResposeGsonRequest);
        } else {
            planDataResponseRequest = new GsonRequest<PlanDataResponse>(Request.Method.GET, url, PlanDataResponse.class,
                    createMyReqSuccessListener(), createMyReqErrorListener());
            AppController.getInstance().addToRequestQueue(planDataResponseRequest);
        }
    }

    private Response.Listener<TrendingPlanDataResponse> createMyTrendingReqSuccessListener() {
        return new Response.Listener<TrendingPlanDataResponse>() {
            @Override
            public void onResponse(TrendingPlanDataResponse trendingPlanDataResponse) {
                mobilePlans = trendingPlanDataResponse.getTrendingDataResponseString().getMobilePlans();
                displayListOfPlans(mobilePlans);
            }
        };
    }

    private Response.Listener<PlanDataResponse> createMyReqSuccessListener() {
        return new Response.Listener<PlanDataResponse>() {
            @Override
            public void onResponse(PlanDataResponse planDataResponse) {
                mobilePlans = planDataResponse.getPlanResponseString().getMobilePlans();
                displayListOfPlans(mobilePlans);
            }
        };
    }

    private Response.ErrorListener createMyReqErrorListener() {
        return new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Error", "Error occured in backend controller in fetching plans", error.getCause());
                if (error instanceof NoConnectionError || error instanceof TimeoutError)
                    Utils.noNetworkMessage(DisplayPlanMain.this, planDataResponseRequest);
            }
        };
    }

    private void displayListOfPlans(List<MobilePlan> mobilePlans) {
        if (mobilePlans == null || mobilePlans.isEmpty()) {
            TextView noText = (TextView) findViewById(R.id.no_plan_text);
            noText.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.GONE);
            return;
        }
        position = 0;
        TextView noText = (TextView) findViewById(R.id.no_plan_text);
        noText.setVisibility(View.GONE);
        layout.setVisibility(View.VISIBLE);
        progressBar.setVisibility(View.GONE);
               /* if (AppPreferences.getIsThisPageDisplayedFirst(getApplicationContext(),
                        Constants.PLAN_DISPLAY_ACTIVITY_NO)) {
                    tut_layout.setVisibility(View.VISIBLE);
                }*/
        adapter = new DisplayPlansListAdapter(getApplicationContext(), DisplayPlanMain.this, mobilePlans,
                position);
        plansList.setAdapter(adapter);

        if (SavePlanController.isAlreadySavedLocation(mobilePlans.get(position))) {
            bookmark.setText("Bookmarked");
        } else {
            bookmark.setText("Bookmark");
        }
        int pageNo = position + 1;
        getSupportActionBar()
                .setTitle(Constants.SHOWING_PLANS + "(" + (position + 1) + "/" + mobilePlans.size() + ")");
    }


    @Override
    protected void onActivityResult(final int requestCode, final int resultCode, final Intent data) {
        if (data != null && resultCode == RESULT_OK) {
            if (requestCode == 107) {
                allFilterString = (AllFilterString) data.getSerializableExtra("allfilterstring");
                if (url != null && url.contains("planYourDay")) {
                    url = DisplayPlanMainController.getPlanYourDayUrl(allFilterString, getApplicationContext());
                } else if (url != null && url.contains("getPlansWithThisLocation")) {
                    url = DisplayPlanMainController.getPlanWithLocationUrl(url, allFilterString, getApplicationContext());
                }
                loadMobilePlans(url);
            } else {
                if (resultCode == Activity.RESULT_OK) {
                    mobilePlans.set(position, adapter.onActivityResult(requestCode, resultCode, data));
                    updateStartAndEndPoint();;

                    if (!mobilePlans.get(position).getStartLocation().getArea().equals(mobilePlans.get(position).getEndLocation().getArea())) {
                        String textToDisplay = "Update Starting Point";
                        int requestCodeToSent = 0;
                        if(requestCode == 0) {
                            textToDisplay = "Update Ending Point";
                            requestCodeToSent = (int) (mobilePlans.get(position).getPlanDetails().size() * 2) + 2;
                        }
                        final int requestCodeToSent1 = requestCodeToSent;
                        Snackbar snack = Snackbar.make(findViewById(R.id.snackbarPosition), textToDisplay, Snackbar.LENGTH_LONG)
                                .setAction("Allow", new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        mobilePlans.set(position, adapter.onActivityResult(requestCodeToSent1, resultCode, data));
                                        updateStartAndEndPoint();
                                    }
                                })
                                .setActionTextColor(Color.parseColor("#11F0FD"));
                        View view = snack.getView();
                        TextView tv = (TextView) view.findViewById(android.support.design.R.id.snackbar_text);
                        tv.setTextColor(Color.WHITE);
                        tv.setTextSize(14);
                        TextView tv1 = (TextView) view.findViewById(android.support.design.R.id.snackbar_action);
                        tv1.setTextSize(14);
                        tv1.setAllCaps(true);
                        view.setMinimumHeight((int) (53 * scale));
                        snack.show();
                    }
                }
            }
        }
    }

    private void updateStartAndEndPoint() {
        Region startLocation = mobilePlans.get(position).getStartLocation();
        startLocation.setArea(startLocation.getArea());
        Region endLocation = mobilePlans.get(position).getEndLocation();
        endLocation.setArea(endLocation.getArea());
        AppPreferences.setStartLocation(getBaseContext(), startLocation);
        AppPreferences.setEndLocation(getBaseContext(), endLocation);
        allFilterString.setStartLocation(startLocation);
        allFilterString.setEndLocation(endLocation);
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        final MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.display_plan_main_menu, menu);

        MenuItem item = menu.findItem(R.id.badge);
        MenuItemCompat.setActionView(item, R.layout.feed_update_count);
        notifCount = (TextView) MenuItemCompat.getActionView(item).findViewById(R.id.hotlist_hot);
        RelativeLayout notifLayout= (RelativeLayout) MenuItemCompat.getActionView(item).findViewById(R.id.hotlist_layout);
        notifLayout.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(DisplayPlanMain.this, OutingDiscuss.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
            }
        });
        if(Globals.outingDto.getPlans()!=null){
            mNotifCount=Globals.outingDto.getPlans().size();
        }
        notifCount.setText(String.valueOf(mNotifCount));
        return super.onCreateOptionsMenu(menu);
    }

    private void setNotifCount(int count){
        mNotifCount = count;
        invalidateOptionsMenu();
    }

    /*@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.filtter:
                Intent i = new Intent();
                i.putExtra("allfilterstring", (Serializable) allFilterString);
                i.putExtra("callType", 2);
                i.setClass(getApplicationContext(), FilterActivity.class);
                startActivityForResult(i, 107);
                break;
        }
        return true;
    }*/
}

