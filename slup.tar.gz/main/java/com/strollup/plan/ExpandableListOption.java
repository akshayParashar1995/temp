package com.strollup.plan;

public class ExpandableListOption {

	public String option = null;

	public boolean state = false;

	public ExpandableListOption(String option, boolean state) {
		this.option = option;

		this.state = state;
	}

	public String getOption() {
		return option;
	}

	public boolean getState() {
		return state;
	}

}
