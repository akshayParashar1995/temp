package com.strollup.plan;

public class SavePlanDataResponse {
	private String savePlanResponse;
	private String unSavePlanResponeString;

	public String getSavePlanResponse() {
		return savePlanResponse;
	}

	public void setSavePlanResponse(String savePlanResponse) {
		this.savePlanResponse = savePlanResponse;
	}

	public String getUnSavePlanResponeString() {
		return unSavePlanResponeString;
	}

	public void setUnSavePlanResponeString(String unSavePlanResponeString) {
		this.unSavePlanResponeString = unSavePlanResponeString;
	}

}
