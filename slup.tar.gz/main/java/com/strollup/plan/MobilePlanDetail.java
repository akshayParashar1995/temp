package com.strollup.plan;

import com.strollup.model.location.LocationDto;

import java.io.Serializable;

public class MobilePlanDetail implements Serializable{

	private String activityName;
	private String locationName;
	private LocationDto location;
	private String distance;
	private String time;

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public LocationDto getLocation() {
		this.location.setName(locationName);
		return location;
	}

	public void setLocation(LocationDto location) {
		this.location = location;
		this.location.setName(locationName);
	}

	public String getDistance() {
		return distance;
	}

	public void setDistance(String distance) {
		this.distance = distance;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}
}