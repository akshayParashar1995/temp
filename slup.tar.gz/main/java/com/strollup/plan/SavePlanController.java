package com.strollup.plan;

import android.content.Context;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;
import com.google.gson.Gson;
import com.strollup.filter.AllFilterString;
import com.strollup.main.AppController;
import com.strollup.request.SaveUserPlanRequest;
import com.strollup.request.UnsaveUserPlanRequest;
import com.strollup.utility.Constants;
import com.strollup.utility.Globals;
import com.strollup.utility.GsonRequest;

import in.strollup.android.BuildConfig;

public class SavePlanController {

	public static void addToList(MobilePlan mobilePlan, int id) {
		Globals.savedPlans.getPlans().add(mobilePlan);
		Globals.savedPlans.getPlanInfoIds().add(id);
		Globals.savedPlans.setCount(Globals.savedPlans.getCount() + 1);
	}

	public static int getIndexOfMobilePlan(MobilePlan mobilePlan) {
		for (MobilePlan plan : Globals.savedPlans.getPlans()) {
			if (plan.equals(mobilePlan)) {
				return Globals.savedPlans.getPlans().indexOf(plan);
			}
		}
		return -1;
	}

	public static void removeFromList(MobilePlan mobilePlan) {
		for (MobilePlan plan : Globals.savedPlans.getPlans()) {
			if (plan.equals(mobilePlan)) {
				int position = getIndexOfMobilePlan(plan);
				Globals.savedPlans.getPlans().remove(position);
				Globals.savedPlans.getPlanInfoIds().remove(position);
				Globals.savedPlans.setCount(Globals.savedPlans.getCount() - 1);
				return;
			}
		}
	}

	public static boolean isAlreadySavedLocation(MobilePlan mobilePlan) {
		for (MobilePlan plan : Globals.savedPlans.getPlans()) {
			if (plan.equals(mobilePlan)) {
				return true;
			}
		}
		return false;
	}

	public static void UnsaveCurrentPlan(Context context, int planInfoID, MobilePlan mobilePlan) {
		UnsaveUserPlanRequest unsaveUserPlanRequest = new UnsaveUserPlanRequest(context, planInfoID);
		String unsaveUrl = Constants.BASE_SERVER_URL + "unSavePlan?saveUserPlanRequestString="
				+ new Gson().toJson(unsaveUserPlanRequest);
		GsonRequest<SavePlanDataResponse> planDataResponseRequest = new GsonRequest<SavePlanDataResponse>(
				Request.Method.GET, unsaveUrl, SavePlanDataResponse.class, createMyReqSuccessListener("unsave",
						mobilePlan), createMyReqErrorListener());
		AppController.getInstance().addToRequestQueue(planDataResponseRequest);
	}

	public static void saveCurrentPlan(Context context, MobilePlan mobilePlan, int planSequenceNumber,
			AllFilterString allFilterString) {
        if(!BuildConfig.DEBUG) {
            GoogleAnalytics analytics = GoogleAnalytics.getInstance(context);
            Tracker tracker = analytics.newTracker(Constants.GOOGLE_ANALYTICS_URL);
            tracker.setScreenName("Plan Page");
            tracker.send(new HitBuilders.EventBuilder().setCategory("UX").setAction("click").setLabel("bookmark").build());
        }
		SaveUserPlanRequest saveUserPlanRequest = new SaveUserPlanRequest(context, mobilePlan.getActivityAtLocation(),
				planSequenceNumber);
		String saveUrl = Constants.BASE_SERVER_URL + "savePlanWithFilter?allFilterString="
				+ new Gson().toJson(allFilterString) + "&saveUserPlanRequestString="
				+ new Gson().toJson(saveUserPlanRequest);
		saveUrl = saveUrl.replaceAll(" ", "%20");
		GsonRequest<SavePlanDataResponse> planDataResponseRequest = new GsonRequest<SavePlanDataResponse>(
				Request.Method.GET, saveUrl, SavePlanDataResponse.class,
				createMyReqSuccessListener("save", mobilePlan), createMyReqErrorListener());
		AppController.getInstance().addToRequestQueue(planDataResponseRequest);

	}

	private static Response.Listener<SavePlanDataResponse> createMyReqSuccessListener(final String tag,
			final MobilePlan mobilePlan) {
		return new Response.Listener<SavePlanDataResponse>() {
			@Override
			public void onResponse(SavePlanDataResponse savePlanDataResponse) {
				String savePlanResponseId = savePlanDataResponse.getSavePlanResponse();
				if (tag.equals("save")) {
					addToList(mobilePlan, Integer.parseInt(savePlanResponseId));
				}
				if (tag.equals("unsave")) {
					removeFromList(mobilePlan);
				}
			}
		};
	}

	private static Response.ErrorListener createMyReqErrorListener() {
		return new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {
				Log.e("Error", "Error occured in backend controller in saving plan", error.getCause());
			}
		};
	}

}
