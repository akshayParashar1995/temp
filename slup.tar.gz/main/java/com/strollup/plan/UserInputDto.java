package com.strollup.plan;

import com.strollup.filter.Region;
import com.strollup.filter.When;

public class UserInputDto {

	private Region startLocation;
	private Region endLocation;
	private Region planLocation;
	private When when;

	public Region getStartLocation() {
		return startLocation;
	}

	public void setStartLocation(Region startLocation) {
		this.startLocation = startLocation;
	}

	public Region getEndLocation() {
		return endLocation;
	}

	public void setEndLocation(Region endLocation) {
		this.endLocation = endLocation;
	}

	public Region getPlanLocation() {
		return planLocation;
	}

	public void setPlanLocation(Region planLocation) {
		this.planLocation = planLocation;
	}

	public When getWhen() {
		return when;
	}

	public void setWhen(When when) {
		this.when = when;
	}

	@Override
	public boolean equals(Object obj) {
		UserInputDto userInputDto = (UserInputDto) obj;
		if(this.getStartLocation()==null|userInputDto.getStartLocation()==null||this.getEndLocation()==null||userInputDto.getEndLocation()==null){
			return false;
		}
		if (this.getStartLocation().equals(userInputDto.getStartLocation())
				&& this.getEndLocation().equals(userInputDto.getEndLocation())) {
			return true;
		}
		return false;
	}
}