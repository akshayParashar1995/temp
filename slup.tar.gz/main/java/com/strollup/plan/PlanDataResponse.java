package com.strollup.plan;

public class PlanDataResponse {

	private MobilePlanResponse planResponseString;

	public MobilePlanResponse getPlanResponseString() {
		return planResponseString;
	}

	public void setPlanResponseString(MobilePlanResponse planResponseString) {
		this.planResponseString = planResponseString;
	}

}
