package com.strollup.plan;

import android.app.Activity;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Rect;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;

import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;
import com.getbase.floatingactionbutton.FloatingActionButton;
import com.strollup.filter.PydOne;
import com.strollup.filter.Region;
import com.strollup.filter.When;
import com.strollup.floating_action_button.InviteFriends;
import com.strollup.utility.AppPreferences;
import com.strollup.utility.Constants;
import com.strollup.utility.Globals;
import com.strollup.utility.Utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import in.strollup.android.BuildConfig;
import in.strollup.android.R;

public class PlanMyDayFirst extends android.support.v4.app.Fragment {

    private Spinner whenOptions;
    private AutoCompleteTextView whereOptions;
    private EditText endTime;
    private Calendar myCalendar;
    private Button chooseActivities;
    private Spinner goingOutWithOptions;
    private ScrollView scrollView;
    private EditText startTime;
    private int selectedStartTime;
    private int selectedEndTime;
    private EditText ed;
    private TextView whenText;
    private View separator;
    private FloatingActionButton floatingActionButton;
    private boolean isCalledByOutingDiscuss=false;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View layout = inflater.inflate(R.layout.plan_my_day, null);
        whenOptions = (Spinner) layout.findViewById(R.id.when_options);
        floatingActionButton = (FloatingActionButton)layout.findViewById(R.id.floating_plan_day);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(),InviteFriends.class);
                getActivity().startActivity(intent);
            }
        });
        Bundle bundle=getArguments();
        if(bundle!=null){
            if(bundle.getBoolean("isCalledByOutingDiscuss")) {
                isCalledByOutingDiscuss=true;
            }
        }
        whenText = (TextView) layout.findViewById(R.id.when_text);
        separator = (View) layout.findViewById(R.id.separator);
        whereOptions = new AutoCompleteTextView(inflater.getContext()) {
            @Override
            public boolean onKeyPreIme(int keyCode, KeyEvent event) {
                if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
                    chooseActivities.setVisibility(View.VISIBLE);
                }
                return super.onKeyPreIme(keyCode, event);
            }
        };
        whereOptions = (AutoCompleteTextView) layout.findViewById(R.id.autoCompleteTextView);
        myCalendar = Calendar.getInstance();
        selectedEndTime = 24 * 60 - 1;

        scrollView = (ScrollView) layout.findViewById(R.id.scroll_view);
        chooseActivities = (Button) layout.findViewById(R.id.choose_activities);
        startTime = (EditText) layout.findViewById(R.id.start_time);
        endTime = (EditText) layout.findViewById(R.id.end_time);
        goingOutWithOptions = (Spinner) layout.findViewById(R.id.going_out_spinner);
        endTime.setText("End of day");
        int mHour = myCalendar.get(Calendar.HOUR_OF_DAY);
        int mMinute = myCalendar.get(Calendar.MINUTE);
        mHour += 1;
        mHour = mHour % 24;
        mMinute = 0;
        selectedStartTime = mHour * 60 + mMinute;
        startTime.setText(getTimeString(mHour, mMinute));

        String[] whenOptionsList = Utils.getArrayOfWhenOptions();
        ArrayAdapter<String> whenAdapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item, whenOptionsList);
        whenAdapter.setDropDownViewResource(R.layout.custom_drop_down);
        whenOptions.setAdapter(whenAdapter);
        whenOptions.setSelection(0);
        if (getTimeString(mHour, mMinute).equals("0:00 am")) {
            whenOptions.setSelection(1);
        }
        List<String> dropdownOptions = new ArrayList<String>();
        for (Region suggestedArea : Globals.suggestedAreas) {
            dropdownOptions.add(suggestedArea.getArea());
        }
        CustomAutoCompleteAdapter autoCompleteAdapter = new CustomAutoCompleteAdapter(getActivity()
                .getApplicationContext(), R.layout.custom_drop_down, dropdownOptions, Constants.NEARBY_PLACES, Constants.ANYWHERE_IN_CURRENT_STATE + Constants.CITY_MAP.get(AppPreferences.getCityId(getActivity().getApplicationContext())));
        whereOptions.setAdapter(autoCompleteAdapter);
        whereOptions.setThreshold(0);
        whereOptions.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                whereOptions.dismissDropDown();
                InputMethodManager inputMethodManager = (InputMethodManager) getActivity().getSystemService(
                        Activity.INPUT_METHOD_SERVICE);
                inputMethodManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), 0);
                whereOptions.clearFocus();

            }

        });
        whereOptions.setTextColor(getResources().getColor(android.R.color.black));
        //
        // 	goingOutWithOptions.setTextColor(getResources().getColor(android.R.color.black));


        whereOptions.setOnFocusChangeListener(new OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {

                if (hasFocus) {
                    whereOptions.setScrollY(whenOptions.getBottom());
                } else {
                    whereOptions.dismissDropDown();
                }
                layout.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        Rect r = new Rect();
                        layout.getWindowVisibleDisplayFrame(r);
                        int screenHeight = layout.getRootView().getHeight();
                        int keypadHeight = screenHeight - r.bottom;
                        if (keypadHeight > screenHeight * 0.15) {
                            // keyboard is opened
                            whenText.setVisibility(View.GONE);
                            whenOptions.setVisibility(View.GONE);
                            startTime.setVisibility(View.GONE);
                            endTime.setVisibility(View.GONE);
                            separator.setVisibility(View.GONE);
                            chooseActivities.setVisibility(View.GONE);
                            goingOutWithOptions.setVisibility(View.GONE);
                        } else {
                            // keyboard is closed
                            whenText.setVisibility(View.VISIBLE);
                            startTime.setVisibility(View.VISIBLE);
                            endTime.setVisibility(View.VISIBLE);
                            whenOptions.setVisibility(View.VISIBLE);
                            chooseActivities.setVisibility(View.VISIBLE);
                            goingOutWithOptions.setVisibility(View.VISIBLE);
                            separator.setVisibility(View.VISIBLE);
                        }
                    }
                });
            }
        });

        if (Utils.isGpsEnabled(getActivity().getApplicationContext())) {
            setNearByCurrentLocation();
        } else {
            whereOptions.setText(Constants.ANYWHERE_IN_CURRENT_STATE + Constants.CITY_MAP.get(AppPreferences.getCityId(getActivity().getApplicationContext())));
            getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
            whereOptions.clearFocus();
        }
        chooseActivities.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                String dateString = Utils.getProperDateWithYear(whenOptions.getSelectedItemPosition());
                When when = new When();
                when.setWhen(dateString);
                when.setStartTime(selectedStartTime);
                when.setEndTime(selectedEndTime);
                String selectedWhere = whereOptions.getText().toString();
                Region selectedRegion = Region.getRegionObject(selectedWhere);
				List<Region> regions = new ArrayList<Region>();
				if(selectedRegion != null) {
					selectedRegion.setArea(selectedWhere);
					regions.add(selectedRegion);
				} 
				PydOne pydOne = new PydOne();
				pydOne.setWhen(when);
				pydOne.setWhereList(regions);
				pydOne.setGoingWith((String) goingOutWithOptions.getSelectedItem());
				Intent intent = new Intent(getActivity(), PlanMyDayActivities.class);
				Bundle bundle = new Bundle();
                if(isCalledByOutingDiscuss){
                    intent.putExtra("isCalledByOutingDiscuss",true);
                    Log.i("OutingDiscuss","called me");
                }
				intent.putExtra("PydOne", pydOne);
				startActivity(intent);
			}
		});

        autoCompleteAdapter.setOnFooterClickListener(new CustomAutoCompleteAdapter.OnFooterClickListener() {
            @Override
            public void onFooterClicked() {
                InputMethodManager inputMethodManager = (InputMethodManager) getActivity().getSystemService(
                        Activity.INPUT_METHOD_SERVICE);
                inputMethodManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), 0);
                setNearByCurrentLocation();
            }
        });
        autoCompleteAdapter.setOnSecondFooterClickListener(new CustomAutoCompleteAdapter.OnSecondFooterClickListener() {
            @Override
            public void onSecondFooterClicked() {
                whereOptions.setText(Constants.ANYWHERE_IN_CURRENT_STATE + Constants.CITY_MAP.get(AppPreferences.getCityId(getActivity().getApplicationContext())));
                whereOptions.dismissDropDown();
                InputMethodManager inputMethodManager = (InputMethodManager) getActivity().getSystemService(
                        Activity.INPUT_METHOD_SERVICE);
                inputMethodManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), 0);
            }
        });
        ArrayAdapter adapter = ArrayAdapter.createFromResource(getActivity(), R.array.spinner_options_going_out_with,
                android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(R.layout.custom_drop_down);
        goingOutWithOptions.setAdapter(adapter);
        startTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateTime(startTime);
            }
        });
        endTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateTime(endTime);
            }
        });
        whereOptions.dismissDropDown();
        return layout;
    }

    private void setNearByCurrentLocation() {
        if (!Utils.isGpsEnabled(getActivity().getApplicationContext())) {
            Utils.buildAlertMessageNoGps(getActivity());
        }

        new AsyncTask<Void, Region, Region>() {
            Region nearMyLocationArea = null;

            @Override
            protected Region doInBackground(Void... params) {
                return Utils.getNearByRegion(getActivity().getApplicationContext());
            }

            @Override
            protected void onPostExecute(Region result) {
                super.onPostExecute(result);
                nearMyLocationArea = result;
                Globals.suggestedAreas.add(nearMyLocationArea);
                whereOptions.setText(nearMyLocationArea.getArea().replaceAll("%20", " "));
                whereOptions.dismissDropDown();
                getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
            }
        }.execute();
    }

    private void updateTime(final EditText edit) {
        myCalendar = Calendar.getInstance();
        int mHour = myCalendar.get(Calendar.HOUR_OF_DAY);
        int mMinute = myCalendar.get(Calendar.MINUTE);
        TimePickerDialog tpd = new TimePickerDialog(getActivity(), new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                edit.setText(getTimeString(hourOfDay, minute));
                if (edit.getId() == R.id.start_time) {
                    selectedStartTime = hourOfDay * 60 + minute;
                } else if (edit.getId() == R.id.end_time) {
                    selectedEndTime = hourOfDay * 60 + minute;
                }
            }
        }, mHour, mMinute, false);
        tpd.show();
    }

    @Override
    public void onResume() {
        super.onResume();
        GoogleAnalytics analytics = GoogleAnalytics.getInstance(getActivity());
        if (!BuildConfig.DEBUG) {
            Tracker tracker = analytics.newTracker(Constants.GOOGLE_ANALYTICS_URL);
            tracker.setScreenName("PlanMyDay");
            tracker.send(new HitBuilders.ScreenViewBuilder().build());
        }
        if (Utils.isGpsEnabled(getActivity().getApplicationContext())) {
            setNearByCurrentLocation();
        }
    }

    private String getTimeString(int hour, int minute) {
        if (hour >= 13) {
            if (minute < 10)
                return hour - 12 + ":0" + minute + " pm";
            else
                return hour - 12 + ":" + minute + " pm";

        } else if (hour == 12) {
            if (minute < 10)
                return hour + ":0" + minute + " pm";
            else
                return hour + ":" + minute + " pm";
        } else {
            if (minute < 10)
                return hour + ":0" + minute + " am";
            else
                return hour + ":" + minute + " am";
        }
    }
}
