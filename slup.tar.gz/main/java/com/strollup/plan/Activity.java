package com.strollup.plan;

public class Activity {

}
